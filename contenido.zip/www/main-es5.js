(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-controller_8.entry.js",
		"common",
		2
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		3
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		4
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		5
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		6
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		0,
		"common",
		7
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		0,
		"common",
		8
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		9
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		10
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		11
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		12
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		13
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		14
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		15
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		16
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		17
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		18
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		19
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		20
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		21
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		22
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		23
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		24
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		25
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		26
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		27
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-img.entry.js",
		28
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		29
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		30
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		31
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		32
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		33
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		34
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		35
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		36
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		37
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		38
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-ios.entry.js",
		"common",
		39
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-md.entry.js",
		"common",
		40
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		0,
		"common",
		41
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		0,
		"common",
		42
	],
	"./ion-nav_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-nav_5.entry.js",
		0,
		"common",
		43
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		0,
		"common",
		44
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		0,
		"common",
		45
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		46
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		47
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		48
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		49
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		50
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		51
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		52
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		53
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		54
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		55
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		56
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		57
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		58
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		59
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		60
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		61
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		62
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		63
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		64
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		65
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		66
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		67
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		68
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		69
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		70
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		1
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		71
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		72
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		73
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		74
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		75
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		76
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		77
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		78
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/asignar/asignar.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/usuarios/asignar/asignar.page.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"usuarios\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Asignar</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-toolbar>\n    <ion-segment scrollable  color=\"secondary\">\n      <ion-segment-button *ngIf=\"this.pasos.length > 0\">\n        <ion-icon name=\"arrow-back\" style=\"font-size:25px;\"  (click)=\"volver()\"></ion-icon>\n      </ion-segment-button>\n\n      <ion-segment-button value=\"{{nodo.name}}\" *ngFor=\"let nodo of arbol;index as index\" (click)=\"seleccionaNodo(nodo,indice)\" (dblclick)=\"navegaNodo(nodo,index,true)\">\n        <ion-label color=\"blanco\">{{nodo.name}}</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n\n  <h3 style=\"text-align:center\">{{mensaje}}</h3>\n\n  <ion-button [disabled]=\"!nodo\"   (click)=\"asignar()\" size=\"medium\">Asignar</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/importar/importar.page.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/usuarios/importar/importar.page.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"usuarios\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Importar</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-importar\" src=\"https://image.flaticon.com/icons/png/512/1570/1570582.png\">\n  </div>\n  <div class=\"button-wrapper\">\n    <span class=\"label\" *ngIf=\"!file\">\n      Subir archivo\n    </span>\n    <span class=\"label\" *ngIf=\"file\">\n      {{file.name}}\n    </span>\n\n    <input type=\"file\" name=\"upload\" id=\"upload\" (change)=\"incomingfile($event);Upload()\" accept=\".xlsx\" class=\"upload-box\" placeholder=\"Subir archivo\">\n\n  </div>\n\n  <br>\n  <ion-grid *ngIf=\"file\">\n    <ion-row >\n      <ion-col size=\"3\">\n        <b>Nombres</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Apellidos</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Correos</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Claves</b>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngFor=\"let usuario of usuarios\">\n      <ion-col size=\"3\">\n        {{ (usuario.firstName.length < 7 ? usuario.firstName : usuario.firstName.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (usuario.lastName.length < 7 ? usuario.lastName : usuario.lastName.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (usuario.email.length < 7 ? usuario.email : usuario.email.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (usuario.password.length < 7 ? usuario.password : usuario.password.substring(0,7 )+\"..\" )}}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <br>\n\n  <ion-button [disabled]=\"!file\" size=\"medium\" (click)=\"Upload()\">Importar</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/permisos/permisos.page.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/usuarios/permisos/permisos.page.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"usuarios\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Permisos {{usuario.firstName}} {{usuario.lastName}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item *ngFor=\"let menu of menus\">\n      <ion-label>{{menu.title}}</ion-label>\n      <ion-checkbox slot=\"end\" [(ngModel)]=\"menu.isChecked\" color=\"secondary\"></ion-checkbox>\n    </ion-item>\n  </ion-list>\n\n<ion-button  size=\"medium\" (click)=\"guardarPermisos()\">Guardar Permisos</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/productos/productos.page.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/usuarios/productos/productos.page.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"usuarios\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Productos para {{usuario}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n    <b>Lista de productos</b>\n  </ion-item-divider>\n\n  <ion-item-sliding #slidingItem *ngFor=\"let producto of productos\">\n\n\n\n    <ion-item (click)=\"verDesc(producto)\">\n      <ion-label >{{producto.titulo}}</ion-label>\n    </ion-item>\n\n    <ion-item-options side=\"end\" >\n      <ion-item-option color=\"warning\">{{producto.puntos}}</ion-item-option>\n    </ion-item-options>\n  </ion-item-sliding>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-split-pane contentId=\"main-content\" >\n    <ion-menu contentId=\"main-content\" type=\"overlay\" >\n      <ion-header class=\"titulo-menu\">\n        <ion-toolbar class=\"ion-top-toolbar\">\n          <img src=\"assets/icon/LOGO IFORT-03.png\"  width=\"40px\" style=\"display:inline-block\" height=\"40px\"/>\n          <ion-title class=\"titleicon\" style=\"display:inline-block\" >{{empresa.nombre}}</ion-title>\n        </ion-toolbar>\n      </ion-header>\n\n      <ion-content>\n        <ion-list class=\"margin-list\" *ngIf=\"usuario.nombre != ''\">\n          <ion-item clasS=\"item-menu-perfil\" (click)='navegar(\"perfil\")'>\n            <div class=\"contenedor-imagen\">\n              <img class=\"imagen-menu\" src=\"https://s3-eu-west-1.amazonaws.com/eflanguagesblog/wp-content/uploads/2019/04/09093804/Useful-phrases-for-a-job-interview_568x464.jpg\">\n            </div>\n            <div class=\"contenedor-texto\">\n              <h1 class=\"texto-menu\">{{usuario.nombre}} {{usuario.apellido}}</h1>\n            </div>\n          </ion-item>\n          <ion-item class=\"item-menu\">\n            <label>General</label>\n          </ion-item>\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\n            <ion-item class=\"item-menu\" [routerDirection]=\"'root'\" [routerLink]=\"[p.path]\" (click)=\"log(p)\">\n              <ion-icon slot=\"start\" [name]=\"p.icon\" color=\"blanco\"></ion-icon>\n              <ion-label>\n                {{p.title}}\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n\n      <ion-footer>\n        <ion-toolbar (click)=\"logout()\" class=\"ion-bottom-toolbar\" *ngIf=\"usuario.nombre != ''\">\n          <ion-button menuToggle size=\"medium\" (click)=\"logout()\">Cerrar sesión</ion-button>\n        </ion-toolbar>\n      </ion-footer>\n    </ion-menu>\n\n    <ion-router-outlet id=\"main-content\" ></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/encuesta/responder/responder.page.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/encuesta/responder/responder.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header style=\"text-aling:center;\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"encuesta\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{encuesta.titulo}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-encuesta\" src=\"https://image.flaticon.com/icons/svg/1039/1039328.svg\">\n  </div>\n\n  <div class=\"contenedor-encuesta\">\n    <div class=\"contenedor-descripcion\">\n        <ion-label class=\"descripcion\">{{encuesta.descripcion}}</ion-label>\n    </div>\n\n    <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n      <b>Preguntas</b>\n    </ion-item-divider>\n\n    <ion-list *ngFor=\"let pregunta of encuesta.preguntas;index as indice\">\n      <div class=\"seccion-secciones\">\n        <div class=\"seccion-preguntas\">\n          <ion-label class=\"pregunta\">{{pregunta.titulo}}</ion-label>\n        </div>\n        <div class=\"seccion-estrellas\" *ngIf=\"!encuesta.resultados\">\n          <div class=\"badges\">\n            <ion-badge mode=\"ios\" (click)=\"cambiarColor(indice,i)\" *ngFor=\"let estrella of estrellas[indice];index as i\" class=\"{{estrella.class}}\"><ion-icon class=\"icono\" name=\"star\"></ion-icon></ion-badge>\n          </div>\n        </div>\n        <div class=\"seccion-estrellas\" *ngIf=\"encuesta.resultados\">\n          <div class=\"badges\">\n            <ion-badge  mode=\"ios\" *ngFor=\"let estrella of estrellas[indice];index as i\" class=\"{{estrella.class}}\"><ion-icon class=\"icono\" name=\"star\"></ion-icon></ion-badge>\n          </div>\n        </div>\n      </div>\n      <ion-item-divider mode=\"md\">\n      </ion-item-divider>\n    </ion-list>\n\n    <ion-button  class=\"ion-button\" size=\"medium\" [disabled]=\"!complete() || encuesta.resultados\" (click)=\"enviarEncuesta()\">Enviar Encuesta</ion-button>\n\n  </div>\n\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/encuestas/escojer/escojer.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/encuestas/escojer/escojer.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"evaluacion\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Que usuarios asignar encuesta</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item *ngFor=\"let usuario of usuarios\">\n      <ion-label>{{usuario.firstName}} {{usuario.lastName}}</ion-label>\n      <ion-checkbox slot=\"end\" [(ngModel)]=\"usuario.isChecked\" color=\"secondary\"></ion-checkbox>\n    </ion-item>\n  </ion-list>\n\n  <ion-button  size=\"block\"  (click)=\"guardarPermisos()\">Listo!</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"encuestas\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Crear afirmación</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-indicador\" src=\"https://image.flaticon.com/icons/png/512/1790/1790019.png\">\n  </div>\n\n\n\n  <ion-item>\n    <ion-input type=\"text\" [(ngModel)]=\"titulo\" placeholder=\"Ingresa titulo de la Afirmación\"></ion-input>\n  </ion-item>\n\n\n  <ion-footer style=\"margin-top: 20%\" *ngIf=\"!actualizando\">\n      <ion-button   [disabled]=\"pregunta == '' \" size=\"medium\" (click)=\"agregarPregunta()\">Agregar</ion-button>\n  </ion-footer>\n  <ion-footer style=\"margin-top: 20%\" *ngIf=\"actualizando\">\n      <ion-button   [disabled]=\"pregunta == '' \" size=\"medium\" (click)=\"actualizarEncuesta()\">Actualizar</ion-button>\n  </ion-footer>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/encuestas/pregunta/pregunta.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/encuestas/pregunta/pregunta.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"encuestas\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ encuesta.titulo }} - Afirmaciones</ion-title>\n    <ion-buttons slot=\"primary\">\n      <ion-button fill=\"solid\" color=\"secondary\" (click)=\"crearPreguntas();verAgregar = true;\" >\n        <ion-icon name=\"add\" ></ion-icon>\n      </ion-button>\n      <ion-button fill=\"solid\" color=\"secondary\" (click)=\"abrirImportar();verAgregar = false;\" >\n        <ion-icon name=\"document\" ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-content>\n    <div class=\"contenedor-imagen\">\n      <img class=\"imagen-indicador\" src=\"https://image.flaticon.com/icons/png/512/1790/1790019.png\">\n    </div>\n\n  <ion-list>\n    <ion-item-sliding  *ngFor=\"let pregunta of encuesta.preguntas,index as indice\">\n      <ion-item>\n        <ion-label>{{(pregunta.titulo )}}</ion-label>\n      </ion-item>\n      <ion-item-options side=\"end\">\n        <ion-item-option (click)=\"editarPregunta(pregunta,indice)\" class=\"boton-editar\">Editar</ion-item-option>\n        <ion-item-option (click)=\"eliminarPregunta(pregunta,indice)\" class=\"boton-borrar\">Borrar</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n    <ion-item *ngIf=\"encuesta.preguntas.length == 0\">\n      <h2>No existen afirmaciones para esta evaluación</h2>\n    </ion-item>\n  </ion-list>\n  <br><br>\n\n  <ion-button  class=\"ion-button\" size=\"medium\" (click)=\"guardarPreguntas()\" >Guardar</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluacion/escojer/escojer.page.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluacion/escojer/escojer.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"evaluacion\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Que usuarios emitir evaluación</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item *ngFor=\"let usuario of usuarios\">\n      <ion-label>{{usuario.firstName}} {{usuario.lastName}}</ion-label>\n      <ion-checkbox slot=\"end\" [(ngModel)]=\"usuario.isChecked\" color=\"secondary\"></ion-checkbox>\n    </ion-item>\n  </ion-list>\n\n  <ion-button  size=\"block\"  (click)=\"guardarPermisos()\">Listo!</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluacion/importar/importar.page.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluacion/importar/importar.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"evaluacion\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title style=\"padding-left: 30%;\">Importar</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-importar\" src=\"https://image.flaticon.com/icons/png/512/1570/1570582.png\">\n  </div>\n\n  <div class=\"button-wrapper\">\n    <span class=\"label\" *ngIf=\"!file\">\n      Subir archivo\n    </span>\n    <span class=\"label\" *ngIf=\"file\">\n      {{file.name}}\n    </span>\n\n    <input type=\"file\" name=\"upload\" id=\"upload\" (change)=\"incomingfile($event);Upload()\" accept=\".xlsx\" class=\"upload-box\" placeholder=\"Subir archivo\">\n\n  </div>\n  <div *ngIf=\"evaluaciones.length > 0\" style=\"text-align:center\">\n    <p>Sigla : {{this.evaluaciones[0].Sigla}}</p>\n    <p>Titulo : {{this.evaluaciones[0].Titulo}}</p>\n    <p>Categorias : {{tamObjeto(this.categorias)}}</p>\n  </div>\n\n\n  <br>\n  <ion-grid *ngIf=\"file\">\n    <ion-row >\n      <ion-col size=\"3\">\n        <b>Titulo</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Categoria</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Indicador</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Sigla</b>\n      </ion-col>\n    </ion-row>\n\n    <ion-row *ngFor=\"let evaluacion of evaluaciones\">\n      <ion-col size=\"3\">\n        {{ (evaluacion.Titulo.length < 7 ? evaluacion.Titulo : evaluacion.Titulo.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (evaluacion.Categoria.length < 7 ? evaluacion.Categoria : evaluacion.Categoria.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (evaluacion.Indicador.length < 7 ? evaluacion.Indicador : evaluacion.Indicador.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (evaluacion.Sigla.length < 7 ? evaluacion.Sigla : evaluacion.Sigla.substring(0,7 )+\"..\" )}}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <br>\n\n  <ion-button [disabled]=\"!file\" size=\"medium\" (click)=\"importar()\">Importar</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluacion/pregunta/crud/crud.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluacion/pregunta/crud/crud.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"evaluacion\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Crear indicador</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-indicador\" src=\"https://image.flaticon.com/icons/png/512/1790/1790019.png\">\n  </div>\n\n  <ion-item>\n    <ion-label>Tipo de indicador</ion-label>\n    <ion-select value=\"brown\" okText=\"Aceptar\" cancelText=\"Dismiss\" [(ngModel)]=\"tipo\">\n      <ion-select-option value=\"Rango\">Rango</ion-select-option>\n      <ion-select-option value=\"Porcentaje\">Porcentaje</ion-select-option>\n      <ion-select-option value=\"Numero\">Numero</ion-select-option>\n    </ion-select>\n  </ion-item>\n  <ion-list *ngIf=\"tipo != '' \">\n    <ion-item>\n        <ion-input type=\"text\" [(ngModel)]=\"categoria\" placeholder=\"Ingresa Categoria del indicador\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-input type=\"text\" [(ngModel)]=\"indicador\" placeholder=\"Ingresa nombre del indicador\"></ion-input>\n    </ion-item>\n\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo == 'Rango' \">\n    <ion-item>\n      <ion-label>\n        Minimo\n      </ion-label>\n      <ion-input type=\"number\" [(ngModel)]=\"min\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        Máximo\n      </ion-label>\n      <ion-input type=\"number\" [(ngModel)]=\"max\"></ion-input>\n    </ion-item>\n    <ion-item >\n      <ion-label >Ejemplo</ion-label>\n      <ion-range min=\"{{min}}\" max=\"{{max}}\" color=\"secondary\" [(ngModel)]=\"cantidad\" [disabled]=\"!min || !max || !validarValores(min,max) \">\n        <ion-label slot=\"start\">{{(min || \"Minimo\")}} -> {{(max|| \"Maximo\")}}</ion-label>\n        <ion-label slot=\"end\">{{cantidad}}</ion-label>\n      </ion-range>\n    </ion-item>\n\n\n\n  </ion-list>\n\n  <ion-footer style=\"margin-top: 20%\" *ngIf=\"!editando\">\n      <ion-button  *ngIf=\"tipo == 'Rango' \" [disabled]=\" indicador == '' || !min || !max \" size=\"medium\" (click)=\"agregarIndicador()\">Agregar</ion-button>\n      <ion-button *ngIf=\"tipo != 'Rango' && tipo != '' \" [disabled]=\" indicador == '' \" size=\"medium\" (click)=\"agregarIndicador()\">Agregar</ion-button>\n  </ion-footer>\n\n  <ion-footer style=\"margin-top: 20%\" *ngIf=\"editando\">\n      <ion-button   [disabled]=\" indicador == ''\" size=\"medium\" (click)=\"actualizar()\">Actualizar</ion-button>\n\n  </ion-footer>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluacion/pregunta/importar/importar.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluacion/pregunta/importar/importar.page.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"evaluacion\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title style=\"padding-left: 30%;\">Importar indicadores</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-indicador\" src=\"https://image.flaticon.com/icons/png/512/1570/1570582.png\">\n  </div>\n\n  <div class=\"button-wrapper\">\n    <span class=\"label\" *ngIf=\"!file\">\n      Subir archivo\n    </span>\n    <span class=\"label\" *ngIf=\"file\">\n      {{file.name}}\n    </span>\n\n    <input type=\"file\" name=\"upload\" id=\"upload\" (change)=\"incomingfile($event);Upload()\" accept=\".xlsx\" class=\"upload-box\" placeholder=\"Subir archivo\">\n\n  </div>\n\n  <br>\n  <ion-grid *ngIf=\"file\">\n    <ion-row >\n      <ion-col size=\"3\">\n        <b>Nombres</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Apellidos</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Correos</b>\n      </ion-col>\n      <ion-col size=\"3\">\n        <b>Claves</b>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngFor=\"let usuario of usuarios\">\n      <ion-col size=\"3\">\n        {{ (usuario.firstName.length < 7 ? usuario.firstName : usuario.firstName.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (usuario.lastName.length < 7 ? usuario.lastName : usuario.lastName.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (usuario.email.length < 7 ? usuario.email : usuario.email.substring(0,7 )+\"..\" )}}\n      </ion-col>\n      <ion-col size=\"3\">\n\n        {{ (usuario.password.length < 7 ? usuario.password : usuario.password.substring(0,7 )+\"..\" )}}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <br>\n\n  <ion-button [disabled]=\"!file\" (click)=\"Upload()\" size=\"medium\">Importar</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluacion/pregunta/pregunta.page.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluacion/pregunta/pregunta.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"evaluacion\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ evaluacion.nombre }} - Indicadores</ion-title>\n    <ion-buttons slot=\"primary\">\n      <ion-button fill=\"solid\" color=\"secondary\" (click)=\"crearIndicador();verAgregar = true;\" >\n        <ion-icon name=\"add\" ></ion-icon>\n      </ion-button>\n      <ion-button fill=\"solid\" color=\"secondary\" (click)=\"abrirImportar();verAgregar = false;\" >\n        <ion-icon name=\"document\" ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-content>\n    <div class=\"contenedor-imagen\">\n      <img class=\"imagen-indicador\" src=\"https://image.flaticon.com/icons/png/512/1790/1790019.png\">\n    </div>\n\n  <ion-list *ngFor=\"let key of getKeys(categorias)\">\n    <ion-list-header>\n      <ion-label>{{key}}</ion-label>\n    </ion-list-header>\n    <ion-item-sliding *ngFor=\"let indicador of categorias[key];index as indice\">\n      <ion-item>\n        <ion-label>{{(indicador.titulo || indicador.indicador)}}</ion-label>\n        <ion-button slot=\"end\" color=\"secondary\">\n          {{indicador.tipo}}\n        </ion-button>\n      </ion-item>\n      <ion-item-options side=\"end\">\n        <ion-item-option (click)=\"editarIndicador(indicador,key,indice)\" class=\"boton-editar\">Editar</ion-item-option>\n        <ion-item-option (click)=\"eliminarIndicador(indicador,key,indice)\" class=\"boton-borrar\">Borrar</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n    <ion-item *ngIf=\"indicadores.length == 0\">\n      <h2>No existen indicadores para esta evaluación</h2>\n    </ion-item>\n  </ion-list>\n  <br><br>\n\n  <ion-button  class=\"ion-button\" size=\"medium\" (click)=\"guardarindicadores()\" >Guardar</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/historial/historial.page.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluaciones/historial/historial.page.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"home\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      Historial\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list >\n    <ion-item *ngFor=\"let evaluacion of datos\" (click)=\"verGrafico(evaluacion,evaluacion.estado)\">\n\n      <ion-chip>\n        <ion-label>{{ evaluacion.porcentaje +\"% -> \"+evaluacion.puntos+ \" ptos\"}}</ion-label>        \n      </ion-chip>\n      <label>{{evaluacion.instrumento.nombre}}</label>\n\n      <div class=\"item-note\" slot=\"end\">\n        <ion-badge color=\"light\">{{evaluacion.instrumento.sigla}}</ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\"  *ngIf=\"evaluacion.estado == 0\">\n        <ion-badge color=\"light\">\n          <ion-icon style=\"color:red\" name=\"close-circle-outline\"></ion-icon>\n        </ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\" *ngIf=\"evaluacion.estado > 0\">\n          <ion-badge color=\"light\">\n            <ion-icon style=\"color:green\" name=\"checkmark-circle-outline\"></ion-icon>\n          </ion-badge>\n      </div>\n\n\n    </ion-item>\n  </ion-list>\n\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/instrumento/instrumento.page.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluaciones/instrumento/instrumento.page.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" *ngIf=\"noOcultar\">\n      <ion-back-button (click)=\"dismiss()\" defaultHref=\"evaluaciones\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"start\" *ngIf=\"!noOcultar\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"home\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title style=\"text-align:center\">Instrumento</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"contenedor-paginas\">\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-instrumento\" src=\"https://image.flaticon.com/icons/png/512/1786/1786595.png\">\n  </div>\n\n  <h3 style=\"text-align:center\">{{instrumento.nombre}}</h3>\n  <br>\n  <ion-list>\n    <ion-item-sliding *ngFor=\"let indicador of indicadores\">\n      <ion-item (click)=\"responder(indicador)\">\n        <ion-label>{{indicador.titulo}} <input type=\"checkbox\" id=\"modal\" /></ion-label>\n        <ion-button slot=\"end\" color=\"secondary\">\n          {{(indicador.valor||indicador.tipo)}}\n        </ion-button>\n      </ion-item>\n      <ion-item-options side=\"end\" >\n        <ion-item-option (click)=\"editarIndicador(prgunta)\" color=\"warning\">Editar</ion-item-option>\n        <ion-item-option (click)=\"eliminarIndicador(prgunta)\" color=\"danger\">Borrar</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n    <ion-item *ngIf=\"indicadores.length == 0\">\n      <h2>No existen indicadores para esta evaluación</h2>\n    </ion-item>\n  </ion-list>\n\n  <ion-button  class=\"ion-button\" *ngIf=\"noOcultar\" (click)=\"guardarEvaluacion()\" [disabled]=\"sinResponder(indicadores)\"  style=\"color:white\">Guardar Evaluación</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/instrumento/respuesta/respuesta.page.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluaciones/instrumento/respuesta/respuesta.page.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" >\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Respuesta</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-respuesta\" src=\"https://image.flaticon.com/icons/png/512/1786/1786640.png\">\n  </div>\n\n  <h3 style=\"text-align:center\">{{titulo}}</h3>\n  <h4 style=\"text-align:center\">{{descripcion}}</h4>\n  <br>\n\n  <ion-list *ngIf=\"noOcultar\">\n    <ion-item *ngIf=\"tipo == 'Numero'\">\n      <ion-input [(ngModel)]=\"valor\" type=\"number\" placeholder=\"pon tu respuesta\"></ion-input>\n    </ion-item>\n    <ion-item *ngIf=\"tipo == 'Porcentaje'\">\n      <ion-input [(ngModel)]=\"valor\" min=\"1\" max=\"100\" type=\"number\" placeholder=\"pon tu respuesta en rango de 1 a 100\"></ion-input>\n    </ion-item>\n    <ion-item *ngIf=\"tipo == 'Rango'\">\n      <ion-range color=\"danger\" pin=\"true\" [disabled]=\"!noOcultar\" min=\"{{min}}\" max=\"{{max}}\" step=\"1\" [(ngModel)]=\"valor\" snaps=\"true\"></ion-range>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"noOcultar\">\n    <ion-label>Observaciones </ion-label>\n    <ion-textarea [(ngModel)]=\"obs\" type=\"number\" ></ion-textarea>\n  </ion-list>\n\n  <ion-item *ngIf=\"!noOcultar\">\n    <p>{{(obs|| \"Sin observaciones\")}}</p>\n  </ion-item>\n\n  <p *ngIf=\"!noOcultar\" style=\"text-align:center\">{{valor}}</p>\n\n  <br>\n  <ion-button class=\"ion-button\" *ngIf=\"noOcultar\" (click)=\"guardar()\" [disabled]=\"!valor\">Guardar respuesta</ion-button>\n  <br>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/list/grafico/grafico.page.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/list/grafico/grafico.page.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>grafico</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card >\n      <ion-card-header class=\"header-card\">\n        <ion-item>\n          <div class=\"contenedor-card\">\n            <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/425/425067.png\">\n          </div>\n          <ion-label>{{navParams.get(\"tipo\")}}</ion-label>\n         <ion-buttons>\n           <ion-label>Tipo grafico</ion-label>\n           <ion-select okText=\"Aceptar\" cancelText=\"Cancelar\" (ionChange)=\"ngAfterViewInit()\" [(ngModel)]=\"tipoActual\">\n             <ion-select-option value=\"{{tipo}}\" *ngFor=\"let tipo of tipos;index as i\">{{tipo.toUpperCase()}}</ion-select-option>\n           </ion-select>\n          </ion-buttons>\n          <ion-buttons>\n            <ion-button slot=\"end\" (click)=\"exportar('rendimiento-por-persona')\">\n              <ion-icon name=\"cloud-download\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n        </ion-item>\n      </ion-card-header>\n\n    <ion-card-content>\n      <canvas #graficoCanvas id=\"rendimiento-por-persona\"></canvas>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/list/list.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/list/list.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"home\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      {{tipo}}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list *ngIf=\"tipo == 'Evaluaciones' && usuario.permissionLevel > 4\">\n    <ion-item *ngFor=\"let evaluacion of datos\" (click)=\"verGrafico(evaluacion,evaluacion.estado)\">\n\n      <ion-chip>\n        <ion-label>{{ evaluacion.createdAt | date:'d - M - yyy'}}</ion-label>\n      </ion-chip>\n      <label>{{evaluacion.nombre}}</label>\n\n      <div class=\"item-note\" slot=\"end\">\n        <ion-badge color=\"light\">{{evaluacion.sigla}}</ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\"  *ngIf=\"evaluacion.estado == 0\">\n        <ion-badge color=\"light\">\n          <ion-icon style=\"color:red\" name=\"close-circle-outline\"></ion-icon>\n        </ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\" *ngIf=\"evaluacion.estado > 0\">\n          <ion-badge color=\"light\">\n            <ion-icon style=\"color:green\" name=\"checkmark-circle-outline\"></ion-icon>\n          </ion-badge>\n      </div>\n\n\n    </ion-item>\n  </ion-list>\n  <ion-list *ngIf=\"tipo == 'Evaluaciones' && usuario.permissionLevel <= 4\">\n    <ion-item *ngFor=\"let evaluacion of datos\" (click)=\"verGrafico(evaluacion,evaluacion.estado)\">\n\n      <ion-chip>\n        <ion-label>{{ evaluacion.createdAt | date:'d - M - yyy'}}</ion-label>\n      </ion-chip>\n      <label>{{evaluacion.instrumento.nombre}}</label>\n\n      <div class=\"item-note\" slot=\"end\">\n        <ion-badge color=\"light\">{{evaluacion.instrumento.sigla}}</ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\"  *ngIf=\"evaluacion.estado == 0\">\n        <ion-badge color=\"light\">\n          <ion-icon style=\"color:red\" name=\"close-circle-outline\"></ion-icon>\n        </ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\" *ngIf=\"evaluacion.estado > 0\">\n          <ion-badge color=\"light\">\n            <ion-icon style=\"color:green\" name=\"checkmark-circle-outline\"></ion-icon>\n          </ion-badge>\n      </div>\n\n\n    </ion-item>\n  </ion-list>\n  <ion-list *ngIf=\"tipo == 'Encuestas'\">\n    <ion-item *ngFor=\"let evaluacion of datos\" (click)=\"verGrafico(evaluacion,evaluacion.estado)\">\n\n      <ion-chip>\n        <ion-label>{{ evaluacion.createdAt | date:'d - M - yyy'}}</ion-label>\n      </ion-chip>\n      <label>{{evaluacion.titulo}}</label>\n\n      <div class=\"item-note\" slot=\"end\">\n        <ion-badge color=\"light\">{{evaluacion.preguntas.length}}</ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\"  *ngIf=\"!evaluacion.revisado\">\n        <ion-badge color=\"light\">\n          <ion-icon style=\"color:red\" name=\"close-circle-outline\"></ion-icon>\n        </ion-badge>\n      </div>\n      <div class=\"item-note\" slot=\"end\" *ngIf=\"evaluacion.estado\">\n          <ion-badge color=\"light\">\n            <ion-icon style=\"color:green\" name=\"checkmark-circle-outline\"></ion-icon>\n          </ion-badge>\n      </div>\n\n\n    </ion-item>\n  </ion-list>\n  <!--\n    <div *ngIf=\"selectedItem\" padding>\n      You navigated here from <b>{{selectedItem.title }}</b>\n    </div>\n  -->\n</ion-content>\n"

/***/ }),

/***/ "./src/app/_servicios/auth.service.ts":
/*!********************************************!*\
  !*** ./src/app/_servicios/auth.service.ts ***!
  \********************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var AuthService = /** @class */ (function () {
    function AuthService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    AuthService.prototype.listar = function () {
        return this.http.get(this.url + "/menus/", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    AuthService.prototype.insertar = function (Menu) {
        return this.http.post(this.url + "/menus/", Menu, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    AuthService.prototype.actualizar = function (id, Menu) {
        return this.http.put(this.url + "/menus/" + id, Menu, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    AuthService.prototype.borrar = function (id) {
        return this.http.delete(this.url + "/menus/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    AuthService.prototype.login = function (usuario) {
        return this.http.post(this.url + "/auth/", usuario, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    AuthService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/_servicios/correos.service.ts":
/*!***********************************************!*\
  !*** ./src/app/_servicios/correos.service.ts ***!
  \***********************************************/
/*! exports provided: CorreosService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CorreosService", function() { return CorreosService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var CorreosService = /** @class */ (function () {
    function CorreosService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    CorreosService.prototype.insertar = function (to, subject, message) {
        var correo = { to: to, subject: subject, message: message };
        var id = sessionStorage.getItem('empresaId');
        return this.http.post(this.url + "/email/", correo, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    CorreosService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    CorreosService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], CorreosService);
    return CorreosService;
}());



/***/ }),

/***/ "./src/app/_servicios/empresas.service.ts":
/*!************************************************!*\
  !*** ./src/app/_servicios/empresas.service.ts ***!
  \************************************************/
/*! exports provided: EmpresaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmpresaService", function() { return EmpresaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var EmpresaService = /** @class */ (function () {
    function EmpresaService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    EmpresaService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        var id = sessionStorage.getItem('empresaId');
        return this.http.get(this.url + "/users/empresa/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EmpresaService.prototype.insertar = function (User) {
        console.log(User);
        User.permissionLevel = 1;
        User.menus = [];
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.post(this.url + "/users/", User, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EmpresaService.prototype.actualizar = function (id, Empresa) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.patch(this.url + "/empresas/" + id, Empresa, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EmpresaService.prototype.borrar = function (id) {
        return this.http.delete(this.url + "/users/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    EmpresaService.prototype.gathering = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.get(this.url + "/users/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EmpresaService.prototype.listarById = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.get(this.url + "/empresas/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EmpresaService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    EmpresaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], EmpresaService);
    return EmpresaService;
}());



/***/ }),

/***/ "./src/app/_servicios/encuestas.service.ts":
/*!*************************************************!*\
  !*** ./src/app/_servicios/encuestas.service.ts ***!
  \*************************************************/
/*! exports provided: EncuestaService, ProductoService, NotificacionesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EncuestaService", function() { return EncuestaService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductoService", function() { return ProductoService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacionesService", function() { return NotificacionesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var EncuestaService = /** @class */ (function () {
    function EncuestaService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    EncuestaService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        var id = sessionStorage.getItem('empresaId');
        return this.http.get(this.url + "/encuestas/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EncuestaService.prototype.insertar = function (Encuesta) {
        var id = sessionStorage.getItem('empresaId');
        Encuesta.empresaId = id;
        console.log("al enviar", Encuesta);
        return this.http.post(this.url + "/encuestas/", Encuesta, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    EncuestaService.prototype.actualizar = function (id, Evaluacion) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.patch(this.url + "/encuestas/" + id, Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EncuestaService.prototype.borrar = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.delete(this.url + "/encuestas/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EncuestaService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    EncuestaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], EncuestaService);
    return EncuestaService;
}());

var ProductoService = /** @class */ (function () {
    function ProductoService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    ProductoService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        var id = sessionStorage.getItem('empresaId');
        return this.http.get(this.url + "/productos/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    ProductoService.prototype.insertar = function (Evaluacion) {
        var id = sessionStorage.getItem('empresaId');
        Evaluacion.empresaId = id;
        console.log("al enviar", Evaluacion);
        return this.http.post(this.url + "/productos/", Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    ProductoService.prototype.actualizar = function (id, Evaluacion) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.patch(this.url + "/productos/" + id, Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    ProductoService.prototype.borrar = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.delete(this.url + "/productos/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    ProductoService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    return ProductoService;
}());

var NotificacionesService = /** @class */ (function () {
    function NotificacionesService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    NotificacionesService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        var id = sessionStorage.getItem('empresaId');
        return this.http.get(this.url + "/notificaciones/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    NotificacionesService.prototype.insertar = function (Evaluacion) {
        var id = sessionStorage.getItem('empresaId');
        Evaluacion.empresaId = id;
        console.log("al enviar", Evaluacion);
        return this.http.post(this.url + "/notificaciones/", Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    NotificacionesService.prototype.actualizar = function (id, Evaluacion) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.patch(this.url + "/notificaciones/" + id, Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    NotificacionesService.prototype.borrar = function (id) {
        return this.http.delete(this.url + "/notificaciones/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    NotificacionesService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    return NotificacionesService;
}());



/***/ }),

/***/ "./src/app/_servicios/evaluaciones.service.ts":
/*!****************************************************!*\
  !*** ./src/app/_servicios/evaluaciones.service.ts ***!
  \****************************************************/
/*! exports provided: EvaluacionesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionesService", function() { return EvaluacionesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var EvaluacionesService = /** @class */ (function () {
    function EvaluacionesService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    EvaluacionesService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        var id = sessionStorage.getItem('empresaId');
        return this.http.get(this.url + "/evaluaciones/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EvaluacionesService.prototype.insertar = function (Evaluacion) {
        var id = sessionStorage.getItem('empresaId');
        Evaluacion.empresaId = id;
        console.log("al enviar", Evaluacion);
        return this.http.post(this.url + "/evaluaciones/", Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    EvaluacionesService.prototype.actualizar = function (id, Evaluacion) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.patch(this.url + "/evaluaciones/" + id, Evaluacion, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EvaluacionesService.prototype.borrar = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.delete(this.url + "/evaluaciones/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    EvaluacionesService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    EvaluacionesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], EvaluacionesService);
    return EvaluacionesService;
}());



/***/ }),

/***/ "./src/app/_servicios/menu.service.ts":
/*!********************************************!*\
  !*** ./src/app/_servicios/menu.service.ts ***!
  \********************************************/
/*! exports provided: MenusService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenusService", function() { return MenusService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var MenusService = /** @class */ (function () {
    function MenusService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    MenusService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.get(this.url + "/menus/", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    MenusService.prototype.insertar = function (Menu) {
        return this.http.post(this.url + "/menus/", Menu, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    MenusService.prototype.actualizar = function (id, Menu) {
        return this.http.put(this.url + "/menus/" + id, Menu, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    MenusService.prototype.borrar = function (id) {
        return this.http.delete(this.url + "/menus/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Content-Type', 'application/json')
        });
    };
    MenusService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    MenusService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], MenusService);
    return MenusService;
}());



/***/ }),

/***/ "./src/app/_servicios/user.service.ts":
/*!********************************************!*\
  !*** ./src/app/_servicios/user.service.ts ***!
  \********************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var UserService = /** @class */ (function () {
    function UserService(http) {
        this.http = http;
        this.url = "http://178.128.71.20:4120";
    }
    UserService.prototype.listar = function () {
        var accessToken = sessionStorage.getItem('accessToken');
        var id = sessionStorage.getItem('empresaId');
        return this.http.get(this.url + "/users/empresa/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    UserService.prototype.insertar = function (User) {
        console.log(User);
        var id = sessionStorage.getItem('empresaId');
        User.permissionLevel = 1;
        User.menus = [];
        User.empresaId = id;
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.post(this.url + "/users/", User, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    UserService.prototype.actualizar = function (id, User) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.patch(this.url + "/users/" + id, User, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    UserService.prototype.borrar = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.delete(this.url + "/users/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    UserService.prototype.gathering = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.get(this.url + "/users/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    UserService.prototype.listarByEmpresa = function (id) {
        var accessToken = sessionStorage.getItem('accessToken');
        return this.http.get(this.url + "/users/empresa/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]()
                .set('Content-Type', 'application/json')
                .set('Authorization', "Bearer " + accessToken)
        });
    };
    UserService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/app/administrador/usuarios/asignar/asignar.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/administrador/usuarios/asignar/asignar.page.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #20d1c2;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: #20d1c2;\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: #20d1c2;\n  --background-activated: #20d1c2;\n  --background-hover: #20d1c2;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\nion-label {\n  color: white !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYWRtaW5pc3RyYWRvci91c3Vhcmlvcy9hc2lnbmFyL2FzaWduYXIucGFnZS5zY3NzIiwic3JjL2FwcC9hZG1pbmlzdHJhZG9yL3VzdWFyaW9zL2FzaWduYXIvYXNpZ25hci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRTs7O0dBQUE7RUFLQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7RUFDQTs7OztHQUFBO0FDS0Y7O0FERUE7RUFDRSxtQkFBQTtBQ0NGOztBREVBO0VBQ0UscUJBQUE7QUNDRjs7QURBRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDRUY7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlHQUFBO0VBQ0EscUdBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDQ0Y7O0FERUE7RUFDRSx1QkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvYWRtaW5pc3RyYWRvci91c3Vhcmlvcy9hc2lnbmFyL2FzaWduYXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24taXRlbXsvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogIzIwZDFjMjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzIwZDFjMjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMjBkMWMyO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVse1xuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cbiIsImlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzIwZDFjMjtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/administrador/usuarios/asignar/asignar.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/administrador/usuarios/asignar/asignar.page.ts ***!
  \****************************************************************/
/*! exports provided: AsignarPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AsignarPage", function() { return AsignarPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var AsignarPage = /** @class */ (function () {
    function AsignarPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.jerarquia = [];
        this.arbol = [];
        this.indice = 0;
        this.pasos = [];
        this.mensaje = "";
        this.sucursal = 0;
        this.count = 0;
        this.usuario = navParams.get('usuario');
        this.jerarquia = JSON.parse(sessionStorage.getItem('jerarquia'));
        this.arbol = JSON.parse(sessionStorage.getItem('jerarquia'));
        if (typeof (this.arbol) != 'object') {
            this.arbol = JSON.parse(this.arbol);
        }
        console.log(this.jerarquia);
    }
    AsignarPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    AsignarPage.prototype.ngOnInit = function () {
        this.nodo = undefined;
    };
    AsignarPage.prototype.volver = function () {
        console.log(this.pasos);
        this.pasos.pop();
        console.log(this.pasos);
        this.arbol = JSON.parse(sessionStorage.getItem('jerarquia'));
        if (typeof (this.arbol) != 'object') {
            this.arbol = JSON.parse(this.arbol);
        }
        for (var i = 0; i < this.pasos.length; i++) {
            this.navegaNodo(this.arbol[this.pasos[i]], this.pasos[i], false);
        }
        this.nodo = undefined;
        this.mensaje = "Seleciona ";
    };
    AsignarPage.prototype.asignar = function () {
        this.modalCtrl.dismiss(this.nodo);
    };
    AsignarPage.prototype.seleccionaNodo = function (nodo, indice) {
        var _this = this;
        this.count++;
        setTimeout(function () {
            if (_this.count == 1) {
                _this.count = 0;
                console.log("hice click en selecciona", nodo);
                _this.mensaje = "Seleccionado " + nodo.name;
                _this.nodo = nodo;
                _this.sucursal = nodo.id;
            }
            if (_this.count > 1) {
                _this.count = 0;
                _this.navegaNodo(nodo, indice, true);
            }
        }, 250);
    };
    AsignarPage.prototype.navegaNodo = function (nodo, indice, aumentaConteo) {
        console.log(this.arbol);
        if (this.arbol[indice].childrens.length > 0) {
            console.log("navegado");
            this.indice++;
            this.arbol = this.arbol[indice].childrens;
            if (aumentaConteo) {
                this.pasos.push(indice);
            }
            console.log("indice", this.pasos);
        }
        else {
            this.seleccionaNodo(nodo, indice);
        }
    };
    AsignarPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    AsignarPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-asignar',
            template: __webpack_require__(/*! raw-loader!./asignar.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/asignar/asignar.page.html"),
            styles: [__webpack_require__(/*! ./asignar.page.scss */ "./src/app/administrador/usuarios/asignar/asignar.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], AsignarPage);
    return AsignarPage;
}());



/***/ }),

/***/ "./src/app/administrador/usuarios/importar/importar.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/administrador/usuarios/importar/importar.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);\nbody {\n  font-family: \"Open Sans\", sans-serif;\n  height: 100%;\n  text-align: center;\n  position: relative;\n}\n.button-wrapper {\n  position: relative;\n  width: 150px;\n  text-align: center;\n  margin: 20% auto;\n}\n.button-wrapper span.label {\n  position: relative;\n  z-index: 0;\n  display: inline-block;\n  width: 100%;\n  background: #20d1c2;\n  cursor: pointer;\n  color: #fff;\n  padding: 10px 0;\n  text-transform: uppercase;\n  font-size: 12px;\n}\n#upload {\n  display: inline-block;\n  position: absolute;\n  z-index: 1;\n  width: 100%;\n  height: 50px;\n  top: 0;\n  left: 0;\n  opacity: 0;\n  cursor: pointer;\n}\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #20d1c2;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n.contenedor-imagen {\n  background: #20d1c2;\n  margin-bottom: 5%;\n}\n.imagen-importar {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\nion-card {\n  --background: white;\n}\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\nion-fab-button {\n  --background: #20d1c2;\n  --background-activated: #20d1c2;\n  --background-hover: #20d1c2;\n  --color: white;\n}\nion-button {\n  --background: #20d1c2;\n  --background-activated: #20d1c2;\n  --background-hover: #20d1c2;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYWRtaW5pc3RyYWRvci91c3Vhcmlvcy9pbXBvcnRhci9pbXBvcnRhci5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkbWluaXN0cmFkb3IvdXN1YXJpb3MvaW1wb3J0YXIvaW1wb3J0YXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHNFQUFBO0FBRVI7RUFDRSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDQUY7QURHQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNBRjtBREdBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLGVBQUE7QUNBRjtBREdBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUNBSjtBREdBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNERjtBRElBO0VBQ0UsbUJBQUE7RUFDRCxpQkFBQTtBQ0REO0FESUE7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNERjtBRElBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0FGO0FER0E7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNJRjtBREdBO0VBQ0UsbUJBQUE7QUNBRjtBREdBO0VBQ0Usb0ZBQUE7QUNBRjtBRENFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNDRjtBREdBO0VBQ0UsK0ZBQUE7RUFDQSx5QkFBQTtBQ0FGO0FER0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxjQUFBO0FDQUY7QURHQTtFQUNFLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNBRiIsImZpbGUiOiJzcmMvYXBwL2FkbWluaXN0cmFkb3IvdXN1YXJpb3MvaW1wb3J0YXIvaW1wb3J0YXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU9wZW4rU2Fuczo0MDAsNjAwKTtcblxuYm9keXtcbiAgZm9udC1mYW1pbHk6ICdPcGVuIFNhbnMnLCBzYW5zLXNlcmlmO1xuICBoZWlnaHQ6MTAwJTtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xufVxuXG4uYnV0dG9uLXdyYXBwZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxNTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDIwJSBhdXRvO1xufVxuXG4uYnV0dG9uLXdyYXBwZXIgc3Bhbi5sYWJlbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogIzIwZDFjMjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMTBweCAwO1xuICB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7XG4gIGZvbnQtc2l6ZToxMnB4O1xufVxuXG4jdXBsb2FkIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHotaW5kZXg6IDE7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIG9wYWNpdHk6IDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG5pb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogIzIwZDFjMjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgYmFja2dyb3VuZDogIzIwZDFjMjtcblx0bWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4taW1wb3J0YXJ7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICMyMGQxYzI7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzIwZDFjMjtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG4iLCJAaW1wb3J0IHVybChodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zOjQwMCw2MDApO1xuYm9keSB7XG4gIGZvbnQtZmFtaWx5OiBcIk9wZW4gU2Fuc1wiLCBzYW5zLXNlcmlmO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4uYnV0dG9uLXdyYXBwZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxNTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDIwJSBhdXRvO1xufVxuXG4uYnV0dG9uLXdyYXBwZXIgc3Bhbi5sYWJlbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogIzIwZDFjMjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMTBweCAwO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBmb250LXNpemU6IDEycHg7XG59XG5cbiN1cGxvYWQge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogMTtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNTBweDtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICBvcGFjaXR5OiAwO1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWltcG9ydGFyIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xufVxuLmhlYWRlci1jYXJkIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNhcmQtZ3JhZGllbnRlIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICMyMGQxYzI7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICMyMGQxYzI7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/administrador/usuarios/importar/importar.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/administrador/usuarios/importar/importar.page.ts ***!
  \******************************************************************/
/*! exports provided: ImportarPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportarPage", function() { return ImportarPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






var ImportarPage = /** @class */ (function () {
    function ImportarPage(toastController, userService, modalCtrl, location) {
        this.toastController = toastController;
        this.userService = userService;
        this.modalCtrl = modalCtrl;
        this.location = location;
        this.file = null;
        this.usuarios = [];
    }
    ImportarPage.prototype.ngOnInit = function () {
    };
    ImportarPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    ImportarPage.prototype.handleFileInput = function (files) {
        console.log(files);
        this.file = files.item(0);
    };
    ImportarPage.prototype.incomingfile = function (event) {
        this.file = event.target.files[0];
    };
    ImportarPage.prototype.importar = function () {
        console.log(this.usuarios);
    };
    ImportarPage.prototype.mandarCorreo = function (usuario) {
        var _this = this;
        this.userService.insertar(usuario).subscribe(function (usuario) {
            _this.presentToast("Usuario creado satisfactoriamente");
        });
    };
    ImportarPage.prototype.presentToast = function (Mensaje) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: Mensaje,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ImportarPage.prototype.Upload = function () {
        var _this = this;
        var self = this;
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            _this.arrayBuffer = fileReader.result;
            var data = new Uint8Array(_this.arrayBuffer);
            var arr = new Array();
            for (var i = 0; i != data.length; ++i)
                arr[i] = String.fromCharCode(data[i]);
            var bstr = arr.join("");
            var workbook = xlsx__WEBPACK_IMPORTED_MODULE_2__["read"](bstr, { type: "binary" });
            var first_sheet_name = workbook.SheetNames[0];
            var worksheet = workbook.Sheets[first_sheet_name];
            var datos = xlsx__WEBPACK_IMPORTED_MODULE_2__["utils"].sheet_to_json(worksheet, { raw: true });
            for (var i_1 = 0; i_1 < datos.length; i_1++) {
                var dato = datos[i_1];
                var user = { Nombre: dato.Nombre, Apellido: dato.Apellido, Rut: dato.Rut, Telefono: dato.Telefono, Correo: dato.Correo, Cargo: dato.Cargo, Clave: (dato.Clave || "clavetemporal") };
                var data_1 = user;
                if (!data_1.Nombre || !data_1.Apellido || !data_1.Correo) {
                    alert("TIENE DATOS CORRUPTOS");
                    return false;
                }
            }
            for (var i_2 = 0; i_2 < datos.length; i_2++) {
                var data_2 = datos[i_2];
                var password = (data_2.Clave || "claveTemporal");
                var usuario = { firstName: data_2.Nombre, lastName: data_2.Apellido, rut: data_2.Rut, phone: data_2.Telefono, email: data_2.Correo, cargo: data_2.Cargo, password: password };
                self.usuarios.push(usuario);
                self.mandarCorreo(usuario);
            }
            console.log(self.usuarios);
        };
        fileReader.readAsArrayBuffer(this.file);
    };
    ImportarPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"] }
    ]; };
    ImportarPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-importar',
            template: __webpack_require__(/*! raw-loader!./importar.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/importar/importar.page.html"),
            styles: [__webpack_require__(/*! ./importar.page.scss */ "./src/app/administrador/usuarios/importar/importar.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"]])
    ], ImportarPage);
    return ImportarPage;
}());

//inside export class


/***/ }),

/***/ "./src/app/administrador/usuarios/permisos/permisos.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/administrador/usuarios/permisos/permisos.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  /*--background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);*/\n  --background: #20d1c2;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: #20d1c2;\n  --background-activated: #20d1c2;\n  --background-hover: #20d1c2;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYWRtaW5pc3RyYWRvci91c3Vhcmlvcy9wZXJtaXNvcy9wZXJtaXNvcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkbWluaXN0cmFkb3IvdXN1YXJpb3MvcGVybWlzb3MvcGVybWlzb3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0Esd0ZBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7RUFDQTs7OztHQUFBO0FDS0Y7O0FERUE7RUFDRSxtQkFBQTtBQ0NGOztBREVBO0VBQ0Usb0ZBQUE7QUNDRjs7QURBRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDRUY7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlHQUFBO0VBQ0EscUdBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9hZG1pbmlzdHJhZG9yL3VzdWFyaW9zL3Blcm1pc29zL3Blcm1pc29zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLyotLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7Ki9cbiAgLS1iYWNrZ3JvdW5kOiAjMjBkMWMyO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzIwZDFjMjtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG4iLCJpb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLyotLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7Ki9cbiAgLS1iYWNrZ3JvdW5kOiAjMjBkMWMyO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xufVxuLmhlYWRlci1jYXJkIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNhcmQtZ3JhZGllbnRlIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMjBkMWMyO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICMyMGQxYzI7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/administrador/usuarios/permisos/permisos.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/administrador/usuarios/permisos/permisos.page.ts ***!
  \******************************************************************/
/*! exports provided: PermisosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermisosPage", function() { return PermisosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _servicios_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../_servicios/menu.service */ "./src/app/_servicios/menu.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var PermisosPage = /** @class */ (function () {
    function PermisosPage(modalCtrl, navParams, menusService) {
        this.modalCtrl = modalCtrl;
        this.navParams = navParams;
        this.menusService = menusService;
        this.menus = [];
        this.usuario = navParams.get('usuario');
    }
    PermisosPage.prototype.ngOnInit = function () {
        var _this = this;
        this.menusService.listar().subscribe(function (data) {
            console.log(data);
            for (var i = 0; i < data.length; i++) {
                for (var j = 0; j < _this.usuario.menus.length; j++) {
                    console.log(_this.usuario.menus[j]._id);
                    console.log(data[i]._id);
                    if (data[i]._id == _this.usuario.menus[j]._id) {
                        console.log("ES TRUE");
                        data[i].isChecked = true;
                    }
                }
                _this.menus.push(data[i]);
            }
        });
    };
    PermisosPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    PermisosPage.prototype.guardarPermisos = function () {
        var menu = [];
        for (var i = 0; i < this.menus.length; i++) {
            if (this.menus[i].isChecked) {
                menu.push(this.menus[i]);
            }
        }
        this.modalCtrl.dismiss(menu);
    };
    PermisosPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"] },
        { type: _servicios_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenusService"] }
    ]; };
    PermisosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-permisos',
            template: __webpack_require__(/*! raw-loader!./permisos.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/permisos/permisos.page.html"),
            styles: [__webpack_require__(/*! ./permisos.page.scss */ "./src/app/administrador/usuarios/permisos/permisos.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"], _servicios_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenusService"]])
    ], PermisosPage);
    return PermisosPage;
}());



/***/ }),

/***/ "./src/app/administrador/usuarios/productos/productos.page.scss":
/*!**********************************************************************!*\
  !*** ./src/app/administrador/usuarios/productos/productos.page.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluaXN0cmFkb3IvdXN1YXJpb3MvcHJvZHVjdG9zL3Byb2R1Y3Rvcy5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/administrador/usuarios/productos/productos.page.ts":
/*!********************************************************************!*\
  !*** ./src/app/administrador/usuarios/productos/productos.page.ts ***!
  \********************************************************************/
/*! exports provided: ProductosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductosPage", function() { return ProductosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ProductosPage = /** @class */ (function () {
    function ProductosPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.productos = [];
        this.usuario = "";
        this.usuario = navParams.get('usuario');
        this.productos = navParams.get('productos');
        console.log(this.productos);
    }
    ProductosPage.prototype.ngOnInit = function () {
    };
    ProductosPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    ProductosPage.prototype.verDesc = function (prod) {
        alert(prod.descripcion);
    };
    ProductosPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    ProductosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-productos',
            template: __webpack_require__(/*! raw-loader!./productos.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/productos/productos.page.html"),
            styles: [__webpack_require__(/*! ./productos.page.scss */ "./src/app/administrador/usuarios/productos/productos.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], ProductosPage);
    return ProductosPage;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: function () { return __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ./home/home.module */ "./src/app/home/home.module.ts")).then(function (m) { return m.HomePageModule; }); }
    },
    {
        path: 'list',
        loadChildren: function () { return __webpack_require__.e(/*! import() | list-list-module */ "list-list-module").then(__webpack_require__.bind(null, /*! ./list/list.module */ "./src/app/list/list.module.ts")).then(function (m) { return m.ListPageModule; }); }
    },
    {
        path: 'evaluacion',
        loadChildren: function () { return __webpack_require__.e(/*! import() | evaluacion-evaluacion-module */ "evaluacion-evaluacion-module").then(__webpack_require__.bind(null, /*! ./evaluacion/evaluacion.module */ "./src/app/evaluacion/evaluacion.module.ts")).then(function (m) { return m.EvaluacionPageModule; }); }
    },
    {
        path: 'usuarios',
        loadChildren: function () { return __webpack_require__.e(/*! import() | administrador-usuarios-usuarios-module */ "administrador-usuarios-usuarios-module").then(__webpack_require__.bind(null, /*! ./administrador/usuarios/usuarios.module */ "./src/app/administrador/usuarios/usuarios.module.ts")).then(function (m) { return m.UsuariosPageModule; }); }
    },
    {
        path: 'menus',
        loadChildren: function () { return __webpack_require__.e(/*! import() | administrador-menus-menus-module */ "administrador-menus-menus-module").then(__webpack_require__.bind(null, /*! ./administrador/menus/menus.module */ "./src/app/administrador/menus/menus.module.ts")).then(function (m) { return m.MenusPageModule; }); }
    },
    {
        path: 'administrador',
        loadChildren: function () { return __webpack_require__.e(/*! import() | administrador-administrador-module */ "administrador-administrador-module").then(__webpack_require__.bind(null, /*! ./administrador/administrador.module */ "./src/app/administrador/administrador.module.ts")).then(function (m) { return m.AdministradorPageModule; }); }
    },
    {
        path: 'login',
        loadChildren: function () { return __webpack_require__.e(/*! import() | login-login-module */ "login-login-module").then(__webpack_require__.bind(null, /*! ./login/login.module */ "./src/app/login/login.module.ts")).then(function (m) { return m.LoginPageModule; }); }
    },
    {
        path: 'registro',
        loadChildren: function () { return __webpack_require__.e(/*! import() | registro-registro-module */ "registro-registro-module").then(__webpack_require__.bind(null, /*! ./registro/registro.module */ "./src/app/registro/registro.module.ts")).then(function (m) { return m.RegistroPageModule; }); }
    },
    {
        path: 'drag',
        loadChildren: function () { return __webpack_require__.e(/*! import() | drag-drag-module */ "drag-drag-module").then(__webpack_require__.bind(null, /*! ./drag/drag.module */ "./src/app/drag/drag.module.ts")).then(function (m) { return m.DragPageModule; }); }
    },
    {
        path: 'canjeables',
        loadChildren: function () { return __webpack_require__.e(/*! import() | canjeables-canjeables-module */ "canjeables-canjeables-module").then(__webpack_require__.bind(null, /*! ./canjeables/canjeables.module */ "./src/app/canjeables/canjeables.module.ts")).then(function (m) { return m.CanjeablesPageModule; }); }
    },
    {
        path: 'evaluaciones',
        loadChildren: function () { return __webpack_require__.e(/*! import() | evaluaciones-evaluaciones-module */ "evaluaciones-evaluaciones-module").then(__webpack_require__.bind(null, /*! ./evaluaciones/evaluaciones.module */ "./src/app/evaluaciones/evaluaciones.module.ts")).then(function (m) { return m.EvaluacionesPageModule; }); }
    },
    {
        path: 'perfil',
        loadChildren: function () { return __webpack_require__.e(/*! import() | perfil-perfil-module */ "perfil-perfil-module").then(__webpack_require__.bind(null, /*! ./perfil/perfil.module */ "./src/app/perfil/perfil.module.ts")).then(function (m) { return m.PerfilPageModule; }); }
    },
    {
        path: 'encuesta',
        loadChildren: function () { return __webpack_require__.e(/*! import() | encuesta-encuesta-module */ "encuesta-encuesta-module").then(__webpack_require__.bind(null, /*! ./encuesta/encuesta.module */ "./src/app/encuesta/encuesta.module.ts")).then(function (m) { return m.EncuestaPageModule; }); }
    },
    {
        path: 'encuestas',
        loadChildren: function () { return __webpack_require__.e(/*! import() | encuestas-encuestas-module */ "encuestas-encuestas-module").then(__webpack_require__.bind(null, /*! ./encuestas/encuestas.module */ "./src/app/encuestas/encuestas.module.ts")).then(function (m) { return m.EncuestasPageModule; }); }
    },
    {
        path: 'productos',
        loadChildren: function () { return __webpack_require__.e(/*! import() | productos-productos-module */ "productos-productos-module").then(__webpack_require__.bind(null, /*! ./productos/productos.module */ "./src/app/productos/productos.module.ts")).then(function (m) { return m.ProductosPageModule; }); }
    },
    {
        path: 'grafico',
        loadChildren: function () { return __webpack_require__.e(/*! import() | list-grafico-grafico-module */ "list-grafico-grafico-module").then(__webpack_require__.bind(null, /*! ./list/grafico/grafico.module */ "./src/app/list/grafico/grafico.module.ts")).then(function (m) { return m.GraficoPageModule; }); }
    },
    {
        path: 'notificaciones',
        loadChildren: function () { return __webpack_require__.e(/*! import() | notificaciones-notificaciones-module */ "notificaciones-notificaciones-module").then(__webpack_require__.bind(null, /*! ./notificaciones/notificaciones.module */ "./src/app/notificaciones/notificaciones.module.ts")).then(function (m) { return m.NotificacionesPageModule; }); }
    },
    {
        path: 'notificacion',
        loadChildren: function () { return __webpack_require__.e(/*! import() | notificacion-notificacion-module */ "notificacion-notificacion-module").then(__webpack_require__.bind(null, /*! ./notificacion/notificacion.module */ "./src/app/notificacion/notificacion.module.ts")).then(function (m) { return m.NotificacionPageModule; }); }
    },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ion-top-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #262f3d !important;\n  --color: white !important;\n}\n\n.ion-bottom-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #262f3d !important;\n  --color: white !important;\n}\n\n.header-md::after {\n  width: 0% !important;\n}\n\n.ion-title {\n  text-align: center;\n  margin-top: 3.5%;\n  margin-bottom: 3.5%;\n  font-size: 15px;\n}\n\nion-icon {\n  width: 27px !important;\n  height: 30px !important;\n  margin-left: 25px !important;\n}\n\nion-content {\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n  --background: #262f3d;\n}\n\nion-item {\n  --color:white!important;\n  /*\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n  --background: #262f3d;\n}\n\n.list-md {\n  padding-top: 0 !important;\n  padding-bottom: 0 !important;\n  margin-top: 0 !important;\n}\n\n.item-menu {\n  /** background **/\n  --background-focused:#262f3d;\n  --background-hover:#262f3d;\n  --background: #262f3d;\n  /** objetos del item **/\n  /** color del item (dentro objetos,letras) **/\n  --color:#fff;\n  --color-activated:#97C2E8;\n  /** color de lo de dentro cuando se le apreta tab encima **/\n  --color-focused:#97C2E8;\n  /** color de lo de dentro cuando se le pasa el mouse encima **/\n  --color-hover:#97C2E8;\n  --border-color: transparent;\n}\n\n.item-perfil {\n  --border-color: transparent;\n}\n\nion-button {\n  --background: #3949ab;\n  --background-activated: #3949ab;\n  --background-hover: #3949ab;\n  width: 70% !important;\n  margin-left: 15% !important;\n  font-size: 10px !important;\n}\n\nion-avatar img {\n  width: 100px !important;\n  height: 100px !important;\n  --border-radius: 50px;\n  margin-left: -20%;\n}\n\n.split-pane-md.split-pane-visible > .split-pane-side {\n  min-width: 19vw;\n  max-width: 0%;\n  margin: 0%;\n  border: none;\n}\n\n.imagen-menu {\n  width: 40px;\n  height: 40px;\n  border-radius: 80px;\n}\n\n.contenedor-texto {\n  margin-top: 2% !important;\n  margin-left: 15% !important;\n}\n\n.texto-menu {\n  font-size: 16px;\n  text-align: center;\n}\n\n.item-menu-perfil {\n  padding-top: 0% !important;\n  --background-focused:#262f3d;\n  --background-hover:#262f3d;\n  --background: #262f3d;\n  background: !important;\n  --border-color: transparent;\n}\n\n@media (min-width: 900px) {\n  .ion-top-toolbar {\n    /*\n    --background: rgb(2,0,36);\n    background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n    */\n    --background: #262f3d;\n    --color: white !important;\n    border-top-right-radius: 25px !important;\n  }\n\n  .ion-bottom-toolbar {\n    /*\n    --background: rgb(2,0,36);\n    background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n    */\n    --background: #262f3d;\n    --color: white !important;\n    border-bottom-right-radius: 25px !important;\n  }\n\n  ion-header {\n    background: #262f3d;\n    border: none;\n  }\n\n  ion-footer {\n    border: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRTs7O0dBQUE7RUFJRixnQ0FBQTtFQUNBLHlCQUFBO0FDQUE7O0FER0E7RUFDQTs7O0dBQUE7RUFJQSxnQ0FBQTtFQUNBLHlCQUFBO0FDQUE7O0FER0E7RUFDQSxvQkFBQTtBQ0FBOztBREdBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQ0FBOztBRElBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLDRCQUFBO0FDREE7O0FESUE7RUFDQTs7OztHQUFBO0VBS0UscUJBQUE7QUNERjs7QURJQTtFQUNBLHVCQUFBO0VBQ0E7OztHQUFBO0VBSUEscUJBQUE7QUNEQTs7QURJQTtFQUNBLHlCQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtBQ0RBOztBRElBO0VBQ0ksaUJBQUE7RUFDSiw0QkFBQTtFQUNBLDBCQUFBO0VBQ0EscUJBQUE7RUFDRSx1QkFBQTtFQUNBLDZDQUFBO0VBQ0YsWUFBQTtFQUVBLHlCQUFBO0VBQ0UsMkRBQUE7RUFDRix1QkFBQTtFQUNFLDhEQUFBO0VBQ0YscUJBQUE7RUFFQSwyQkFBQTtBQ0hBOztBRE1BO0VBQ0EsMkJBQUE7QUNIQTs7QURNQTtFQUNBLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSwwQkFBQTtBQ0hBOztBRE1BO0VBRUEsdUJBQUE7RUFDQSx3QkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7QUNKQTs7QURlQTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUNaRjs7QURlQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUNaQTs7QURlQTtFQUNBLHlCQUFBO0VBQ0EsMkJBQUE7QUNaQTs7QURlQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ1pBOztBRGVBO0VBQ0EsMEJBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNDLDJCQUFBO0FDWkQ7O0FEZUE7RUFDQTtJQUNFOzs7S0FBQTtJQUlBLHFCQUFBO0lBQ0EseUJBQUE7SUFDQSx3Q0FBQTtFQ1pBOztFRGVGO0lBQ0U7OztLQUFBO0lBSUEscUJBQUE7SUFDQSx5QkFBQTtJQUNBLDJDQUFBO0VDWkE7O0VEZUY7SUFDRSxtQkFBQTtJQUNBLFlBQUE7RUNaQTs7RURlRjtJQUNFLFlBQUE7RUNaQTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4uaW9uLXRvcC10b29sYmFye1xuICAvKlxuLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbmJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiovXG4tLWJhY2tncm91bmQ6ICMyNjJmM2QgIWltcG9ydGFudDtcbi0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi5pb24tYm90dG9tLXRvb2xiYXJ7XG4vKlxuLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbmJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiovXG4tLWJhY2tncm91bmQ6ICMyNjJmM2QgIWltcG9ydGFudDtcbi0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVye1xud2lkdGg6IDAlICFpbXBvcnRhbnQ7XG59XG5cbi5pb24tdGl0bGV7XG50ZXh0LWFsaWduOiBjZW50ZXI7XG5tYXJnaW4tdG9wOiAzLjUlO1xubWFyZ2luLWJvdHRvbTogMy41JTtcbmZvbnQtc2l6ZTogMTVweDtcbn1cblxuXG5pb24taWNvbntcbndpZHRoOiAyN3B4ICFpbXBvcnRhbnQ7XG5oZWlnaHQ6IDMwcHggIWltcG9ydGFudDtcbm1hcmdpbi1sZWZ0OiAyNXB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jb250ZW50IHtcbi8qXG4tLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbi0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4tLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMjYyZjNkO1xufVxuXG5pb24taXRlbXtcbi0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuLypcbi0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4tLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuKi9cbi0tYmFja2dyb3VuZDogIzI2MmYzZDtcbn1cblxuLmxpc3QtbWR7XG5wYWRkaW5nLXRvcDowIWltcG9ydGFudDtcbnBhZGRpbmctYm90dG9tOjAhaW1wb3J0YW50O1xubWFyZ2luLXRvcDogMCFpbXBvcnRhbnQ7XG59XG5cbi5pdGVtLW1lbnV7XG4gICAgLyoqIGJhY2tncm91bmQgKiovXG4tLWJhY2tncm91bmQtZm9jdXNlZDojMjYyZjNkO1xuLS1iYWNrZ3JvdW5kLWhvdmVyOiMyNjJmM2Q7XG4tLWJhY2tncm91bmQ6ICMyNjJmM2Q7XG4gIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovXG4tLWNvbG9yOiNmZmY7XG5cbi0tY29sb3ItYWN0aXZhdGVkOiM5N0MyRTg7XG4gIC8qKiBjb2xvciBkZSBsbyBkZSBkZW50cm8gY3VhbmRvIHNlIGxlIGFwcmV0YSB0YWIgZW5jaW1hICoqL1xuLS1jb2xvci1mb2N1c2VkOiM5N0MyRTg7XG4gIC8qKiBjb2xvciBkZSBsbyBkZSBkZW50cm8gY3VhbmRvIHNlIGxlIHBhc2EgZWwgbW91c2UgZW5jaW1hICoqL1xuLS1jb2xvci1ob3ZlcjojOTdDMkU4O1xuXG4tLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5pdGVtLXBlcmZpbHtcbi0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuaW9uLWJ1dHRvbntcbi0tYmFja2dyb3VuZDogIzM5NDlhYjtcbi0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMzOTQ5YWI7XG4tLWJhY2tncm91bmQtaG92ZXI6ICMzOTQ5YWI7XG53aWR0aDogNzAlICFpbXBvcnRhbnQ7XG5tYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG5mb250LXNpemU6IDEwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWF2YXRhciBpbWd7XG5cbndpZHRoOiAxMDBweCAhaW1wb3J0YW50O1xuaGVpZ2h0OiAxMDBweCAhaW1wb3J0YW50O1xuLS1ib3JkZXItcmFkaXVzOiA1MHB4O1xubWFyZ2luLWxlZnQ6IC0yMCU7XG59XG5cbmlvbi1zcGxpdC1wYW5le1xuXG59XG5cbmlvbi1jb250ZW50e1xuXG59XG5cbi5zcGxpdC1wYW5lLW1kLnNwbGl0LXBhbmUtdmlzaWJsZT4uc3BsaXQtcGFuZS1zaWRlIHtcbiAgbWluLXdpZHRoOiAxOXZ3O1xuICBtYXgtd2lkdGg6IDAlO1xuICBtYXJnaW46IDAlO1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5pbWFnZW4tbWVudXtcbndpZHRoOiA0MHB4O1xuaGVpZ2h0OiA0MHB4O1xuYm9yZGVyLXJhZGl1czogODBweDtcbn1cblxuLmNvbnRlbmVkb3ItdGV4dG97XG5tYXJnaW4tdG9wOiAyJSAhaW1wb3J0YW50O1xubWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufVxuXG4udGV4dG8tbWVudXtcbmZvbnQtc2l6ZTogMTZweDtcbnRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLml0ZW0tbWVudS1wZXJmaWx7XG5wYWRkaW5nLXRvcDogMCUgIWltcG9ydGFudDtcbi0tYmFja2dyb3VuZC1mb2N1c2VkOiMyNjJmM2Q7XG4tLWJhY2tncm91bmQtaG92ZXI6IzI2MmYzZDtcbi0tYmFja2dyb3VuZDogIzI2MmYzZDtcbmJhY2tncm91bmQ6ICFpbXBvcnRhbnQ7XG4gLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcbi5pb24tdG9wLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMjYyZjNkO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjVweCAhaW1wb3J0YW50O1xufVxuXG4uaW9uLWJvdHRvbS10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogIzI2MmYzZDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDI1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWhlYWRlcntcbiAgYmFja2dyb3VuZDogIzI2MmYzZDtcbiAgYm9yZGVyOiBub25lO1xufVxuXG5pb24tZm9vdGVye1xuICBib3JkZXI6IG5vbmU7XG59XG59XG4iLCIuaW9uLXRvcC10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICMyNjJmM2QgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1ib3R0b20tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMjYyZjNkICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgd2lkdGg6IDAlICFpbXBvcnRhbnQ7XG59XG5cbi5pb24tdGl0bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDMuNSU7XG4gIG1hcmdpbi1ib3R0b206IDMuNSU7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuaW9uLWljb24ge1xuICB3aWR0aDogMjdweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDMwcHggIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDI1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMjYyZjNkO1xufVxuXG5pb24taXRlbSB7XG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICMyNjJmM2Q7XG59XG5cbi5saXN0LW1kIHtcbiAgcGFkZGluZy10b3A6IDAgIWltcG9ydGFudDtcbiAgcGFkZGluZy1ib3R0b206IDAgIWltcG9ydGFudDtcbiAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xufVxuXG4uaXRlbS1tZW51IHtcbiAgLyoqIGJhY2tncm91bmQgKiovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiMyNjJmM2Q7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojMjYyZjNkO1xuICAtLWJhY2tncm91bmQ6ICMyNjJmM2Q7XG4gIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovXG4gIC0tY29sb3I6I2ZmZjtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6Izk3QzJFODtcbiAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgYXByZXRhIHRhYiBlbmNpbWEgKiovXG4gIC0tY29sb3ItZm9jdXNlZDojOTdDMkU4O1xuICAvKiogY29sb3IgZGUgbG8gZGUgZGVudHJvIGN1YW5kbyBzZSBsZSBwYXNhIGVsIG1vdXNlIGVuY2ltYSAqKi9cbiAgLS1jb2xvci1ob3ZlcjojOTdDMkU4O1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5pdGVtLXBlcmZpbCB7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzM5NDlhYjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzM5NDlhYjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMzk0OWFiO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1hdmF0YXIgaW1nIHtcbiAgd2lkdGg6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMTAwcHggIWltcG9ydGFudDtcbiAgLS1ib3JkZXItcmFkaXVzOiA1MHB4O1xuICBtYXJnaW4tbGVmdDogLTIwJTtcbn1cblxuLnNwbGl0LXBhbmUtbWQuc3BsaXQtcGFuZS12aXNpYmxlID4gLnNwbGl0LXBhbmUtc2lkZSB7XG4gIG1pbi13aWR0aDogMTl2dztcbiAgbWF4LXdpZHRoOiAwJTtcbiAgbWFyZ2luOiAwJTtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4uaW1hZ2VuLW1lbnUge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiA4MHB4O1xufVxuXG4uY29udGVuZWRvci10ZXh0byB7XG4gIG1hcmdpbi10b3A6IDIlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLnRleHRvLW1lbnUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLml0ZW0tbWVudS1wZXJmaWwge1xuICBwYWRkaW5nLXRvcDogMCUgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IzI2MmYzZDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiMyNjJmM2Q7XG4gIC0tYmFja2dyb3VuZDogIzI2MmYzZDtcbiAgYmFja2dyb3VuZDogIWltcG9ydGFudDtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcbiAgLmlvbi10b3AtdG9vbGJhciB7XG4gICAgLypcbiAgICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgICAqL1xuICAgIC0tYmFja2dyb3VuZDogIzI2MmYzZDtcbiAgICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyNXB4ICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuaW9uLWJvdHRvbS10b29sYmFyIHtcbiAgICAvKlxuICAgIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAgICovXG4gICAgLS1iYWNrZ3JvdW5kOiAjMjYyZjNkO1xuICAgIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDI1cHggIWltcG9ydGFudDtcbiAgfVxuXG4gIGlvbi1oZWFkZXIge1xuICAgIGJhY2tncm91bmQ6ICMyNjJmM2Q7XG4gICAgYm9yZGVyOiBub25lO1xuICB9XG5cbiAgaW9uLWZvb3RlciB7XG4gICAgYm9yZGVyOiBub25lO1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./_servicios/empresas.service */ "./src/app/_servicios/empresas.service.ts");





//import { Push, PushObject, PushOptions } from '@ionic-native/push/ngx';





var AppComponent = /** @class */ (function () {
    function AppComponent(empresaService, userService, menuController, router, events, platform, splashScreen, statusBar) {
        var _this = this;
        this.empresaService = empresaService;
        this.userService = userService;
        this.menuController = menuController;
        this.router = router;
        this.events = events;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.appPages = [];
        this.usuario = { nombre: '', apellido: '' };
        this.empresa = { nombre: 'Ifort' };
        this.initializeApp();
        //this.pushNotifications();
        events.subscribe('user:login', function (res) {
            console.log("Esta dentro del evento login", res);
            _this.appPages = res;
        });
    }
    AppComponent.prototype.log = function (p) {
        console.log(p);
    };
    AppComponent.prototype.navegar = function (ruta) {
        this.router.navigate([ruta]);
    };
    AppComponent.prototype.logout = function () {
        this.menuController.toggle();
        sessionStorage.clear();
        this.usuario = { nombre: '', apellido: '' };
        this.router.navigate(['login']);
    };
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        console.log("inicializo");
        var menus = JSON.parse(sessionStorage.getItem('menus'));
        var usuario = JSON.parse(sessionStorage.getItem('usuario'));
        if (usuario) {
            this.empresa = JSON.parse(sessionStorage.getItem('empresa'));
            console.log("empresa", this.empresa);
            console.log("traigo al user");
            this.userService.gathering(usuario.id).subscribe(function (datos) {
                sessionStorage.setItem('usuario', JSON.stringify(datos));
                console.log("user", datos);
                usuario = datos;
                _this.usuario.nombre = usuario.firstName;
                _this.usuario.apellido = usuario.lastName;
                var empresaId = usuario.empresaId;
                _this.empresaService.listarById(empresaId).subscribe(function (empresa) {
                    console.log(empresa);
                    var jerarquia = JSON.stringify(empresa['jerarquia']);
                    sessionStorage.setItem('jerarquia', JSON.stringify(jerarquia));
                    sessionStorage.setItem('empresa', JSON.stringify(empresa));
                });
            });
        }
        if (menus) {
            console.log(menus);
            this.appPages = menus;
        }
        else {
            this.logout();
        }
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent.ctorParameters = function () { return [
        { type: _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_7__["EmpresaService"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Events"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] }
    ]; };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_servicios_empresas_service__WEBPACK_IMPORTED_MODULE_7__["EmpresaService"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Events"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var angular_tree_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-tree-component */ "./node_modules/angular-tree-component/dist/angular-tree-component.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ng_circle_progress__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ng-circle-progress */ "./node_modules/ng-circle-progress/fesm5/ng-circle-progress.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _evaluacion_pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./evaluacion/pregunta/pregunta.page */ "./src/app/evaluacion/pregunta/pregunta.page.ts");
/* harmony import */ var _encuestas_pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./encuestas/pregunta/pregunta.page */ "./src/app/encuestas/pregunta/pregunta.page.ts");
/* harmony import */ var _evaluacion_pregunta_crud_crud_page__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./evaluacion/pregunta/crud/crud.page */ "./src/app/evaluacion/pregunta/crud/crud.page.ts");
/* harmony import */ var _encuestas_pregunta_crud_encuesta_crud_encuesta_page__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./encuestas/pregunta/crud-encuesta/crud-encuesta.page */ "./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.ts");
/* harmony import */ var _encuestas_escojer_escojer_page__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./encuestas/escojer/escojer.page */ "./src/app/encuestas/escojer/escojer.page.ts");
/* harmony import */ var _servicios_auth_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./_servicios/auth.service */ "./src/app/_servicios/auth.service.ts");
/* harmony import */ var _servicios_menu_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./_servicios/menu.service */ "./src/app/_servicios/menu.service.ts");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./_servicios/empresas.service */ "./src/app/_servicios/empresas.service.ts");
/* harmony import */ var _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./_servicios/evaluaciones.service */ "./src/app/_servicios/evaluaciones.service.ts");
/* harmony import */ var _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./_servicios/encuestas.service */ "./src/app/_servicios/encuestas.service.ts");
/* harmony import */ var _servicios_correos_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./_servicios/correos.service */ "./src/app/_servicios/correos.service.ts");
/* harmony import */ var _evaluaciones_historial_historial_page__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./evaluaciones/historial/historial.page */ "./src/app/evaluaciones/historial/historial.page.ts");
/* harmony import */ var _administrador_usuarios_permisos_permisos_page__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./administrador/usuarios/permisos/permisos.page */ "./src/app/administrador/usuarios/permisos/permisos.page.ts");
/* harmony import */ var _administrador_usuarios_asignar_asignar_page__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./administrador/usuarios/asignar/asignar.page */ "./src/app/administrador/usuarios/asignar/asignar.page.ts");
/* harmony import */ var _administrador_usuarios_productos_productos_page__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./administrador/usuarios/productos/productos.page */ "./src/app/administrador/usuarios/productos/productos.page.ts");
/* harmony import */ var _administrador_usuarios_importar_importar_page__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./administrador/usuarios/importar/importar.page */ "./src/app/administrador/usuarios/importar/importar.page.ts");
/* harmony import */ var _evaluacion_importar_importar_page__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./evaluacion/importar/importar.page */ "./src/app/evaluacion/importar/importar.page.ts");
/* harmony import */ var _evaluacion_pregunta_importar_importar_page__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./evaluacion/pregunta/importar/importar.page */ "./src/app/evaluacion/pregunta/importar/importar.page.ts");
/* harmony import */ var _evaluaciones_instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./evaluaciones/instrumento/instrumento.page */ "./src/app/evaluaciones/instrumento/instrumento.page.ts");
/* harmony import */ var _evaluacion_escojer_escojer_page__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./evaluacion/escojer/escojer.page */ "./src/app/evaluacion/escojer/escojer.page.ts");
/* harmony import */ var _evaluaciones_instrumento_respuesta_respuesta_page__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./evaluaciones/instrumento/respuesta/respuesta.page */ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.ts");
/* harmony import */ var _encuesta_responder_responder_page__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./encuesta/responder/responder.page */ "./src/app/encuesta/responder/responder.page.ts");
/* harmony import */ var _list_list_page__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./list/list.page */ "./src/app/list/list.page.ts");
/* harmony import */ var _list_grafico_grafico_page__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./list/grafico/grafico.page */ "./src/app/list/grafico/grafico.page.ts");










//import { Push } from '@ionic-native/push/ngx';































var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"], _encuestas_escojer_escojer_page__WEBPACK_IMPORTED_MODULE_18__["EscojerEncuestasPage"], _encuesta_responder_responder_page__WEBPACK_IMPORTED_MODULE_36__["ResponderPage"], _administrador_usuarios_productos_productos_page__WEBPACK_IMPORTED_MODULE_29__["ProductosPage"], _evaluacion_escojer_escojer_page__WEBPACK_IMPORTED_MODULE_34__["EscojerPage"], _list_grafico_grafico_page__WEBPACK_IMPORTED_MODULE_38__["GraficoPage"], _evaluaciones_historial_historial_page__WEBPACK_IMPORTED_MODULE_26__["HistorialPage"], _list_list_page__WEBPACK_IMPORTED_MODULE_37__["ListPage"], _encuestas_pregunta_crud_encuesta_crud_encuesta_page__WEBPACK_IMPORTED_MODULE_17__["CrudEncuestaPage"], _evaluaciones_instrumento_respuesta_respuesta_page__WEBPACK_IMPORTED_MODULE_35__["RespuestaPage"], _evaluaciones_instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_33__["InstrumentoPage"], _evaluacion_importar_importar_page__WEBPACK_IMPORTED_MODULE_31__["ImportarPageEvaluacion"], _evaluacion_pregunta_importar_importar_page__WEBPACK_IMPORTED_MODULE_32__["ImportarPagePregunta"], _administrador_usuarios_importar_importar_page__WEBPACK_IMPORTED_MODULE_30__["ImportarPage"], _encuestas_pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_15__["PreguntaEncuestaPage"], _evaluacion_pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_14__["PreguntaPage"], _administrador_usuarios_asignar_asignar_page__WEBPACK_IMPORTED_MODULE_28__["AsignarPage"], _administrador_usuarios_permisos_permisos_page__WEBPACK_IMPORTED_MODULE_27__["PermisosPage"], _evaluacion_pregunta_crud_crud_page__WEBPACK_IMPORTED_MODULE_16__["CrudPage"]],
            entryComponents: [_encuestas_pregunta_crud_encuesta_crud_encuesta_page__WEBPACK_IMPORTED_MODULE_17__["CrudEncuestaPage"], _encuestas_escojer_escojer_page__WEBPACK_IMPORTED_MODULE_18__["EscojerEncuestasPage"], _list_list_page__WEBPACK_IMPORTED_MODULE_37__["ListPage"], _list_grafico_grafico_page__WEBPACK_IMPORTED_MODULE_38__["GraficoPage"], _administrador_usuarios_productos_productos_page__WEBPACK_IMPORTED_MODULE_29__["ProductosPage"], _evaluacion_escojer_escojer_page__WEBPACK_IMPORTED_MODULE_34__["EscojerPage"], _evaluaciones_historial_historial_page__WEBPACK_IMPORTED_MODULE_26__["HistorialPage"], _encuestas_pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_15__["PreguntaEncuestaPage"], _evaluacion_pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_14__["PreguntaPage"], _encuesta_responder_responder_page__WEBPACK_IMPORTED_MODULE_36__["ResponderPage"], _evaluaciones_instrumento_respuesta_respuesta_page__WEBPACK_IMPORTED_MODULE_35__["RespuestaPage"], _evaluaciones_instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_33__["InstrumentoPage"], _evaluacion_importar_importar_page__WEBPACK_IMPORTED_MODULE_31__["ImportarPageEvaluacion"], _evaluacion_pregunta_importar_importar_page__WEBPACK_IMPORTED_MODULE_32__["ImportarPagePregunta"], _administrador_usuarios_importar_importar_page__WEBPACK_IMPORTED_MODULE_30__["ImportarPage"], _administrador_usuarios_asignar_asignar_page__WEBPACK_IMPORTED_MODULE_28__["AsignarPage"], _administrador_usuarios_permisos_permisos_page__WEBPACK_IMPORTED_MODULE_27__["PermisosPage"], _evaluacion_pregunta_crud_crud_page__WEBPACK_IMPORTED_MODULE_16__["CrudPage"]],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                ng_circle_progress__WEBPACK_IMPORTED_MODULE_11__["NgCircleProgressModule"].forRoot(),
                angular_tree_component__WEBPACK_IMPORTED_MODULE_5__["TreeModule"].forRoot(),
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_13__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"]
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__["StatusBar"],
                _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_9__["LocalNotifications"],
                _servicios_auth_service__WEBPACK_IMPORTED_MODULE_19__["AuthService"],
                //Push,
                _servicios_menu_service__WEBPACK_IMPORTED_MODULE_20__["MenusService"],
                _servicios_correos_service__WEBPACK_IMPORTED_MODULE_25__["CorreosService"],
                _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_24__["EncuestaService"],
                _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_24__["NotificacionesService"],
                _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_24__["ProductoService"],
                _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_23__["EvaluacionesService"],
                _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_22__["EmpresaService"],
                _servicios_user_service__WEBPACK_IMPORTED_MODULE_21__["UserService"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_7__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/encuesta/responder/responder.page.scss":
/*!********************************************************!*\
  !*** ./src/app/encuesta/responder/responder.page.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  text-align: center;\n  --background: #7A9FCC;\n  --color:white;\n}\n\n.contenedor-imagen {\n  background: #7A9FCC;\n  margin-bottom: 5%;\n}\n\n.imagen-encuesta {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.contenedor-descripcion {\n  text-align: center;\n  width: 90%;\n  margin-top: 5%;\n  margin-left: 5%;\n  margin-bottom: 5%;\n}\n\n.seccion-secciones {\n  display: -webkit-box;\n  display: flex;\n  margin-top: 2.5%;\n}\n\n.seccion-preguntas {\n  width: 70%;\n}\n\n.pregunta {\n  margin-left: 5% !important;\n}\n\n.seccion-estrellas {\n  width: 50%;\n}\n\n.seccion-estrellas ion-badge {\n  margin-left: 1.5%;\n  --background: transparent;\n  --color: #424242;\n}\n\n.seccion-estrellas .icono {\n  width: 25px;\n  height: 25px;\n}\n\n.seccion-estrellas .cambiador {\n  color: #ffd600;\n}\n\n.ion-item {\n  --border-color: transparent;\n}\n\n.ion-button {\n  --background: #7A9FCC;\n  --background-activated: #7A9FCC;\n  --background-hover: #7A9FCC;\n  width: 70% !important;\n  margin-left: 15% !important;\n  margin-top: 10%;\n  margin-bottom: 10%;\n}\n\n@media (max-width: 550px) {\n  .seccion-secciones {\n    display: inline !important;\n    margin-top: 2.5%;\n  }\n\n  .seccion-preguntas {\n    margin-top: 5%;\n    margin-left: 0% !important;\n    width: 100%;\n    text-align: center !important;\n  }\n\n  .pregunta {\n    margin-top: 10% !important;\n    margin-left: 0% !important;\n  }\n\n  .seccion-estrellas {\n    margin-top: 5%;\n    width: 100% !important;\n  }\n  .seccion-estrellas .badges {\n    width: 100%;\n    margin-left: 0%;\n  }\n  .seccion-estrellas .badges ion-badge {\n    width: 10%;\n    margin-left: 2.5%;\n    margin-right: 2.5%;\n    --background: transparent;\n    --color: #424242;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZW5jdWVzdGEvcmVzcG9uZGVyL3Jlc3BvbmRlci5wYWdlLnNjc3MiLCJzcmMvYXBwL2VuY3Vlc3RhL3Jlc3BvbmRlci9yZXNwb25kZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7QUNDSjs7QURDRTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNFSDs7QURDRTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0VKOztBRENFO0VBRUUsa0JBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0NKOztBRE1FO0VBQ0Usb0JBQUE7RUFBQSxhQUFBO0VBQ0EsZ0JBQUE7QUNISjs7QURLRTtFQUNFLFVBQUE7QUNGSjs7QURLRTtFQUNFLDBCQUFBO0FDRko7O0FES0U7RUFDRSxVQUFBO0FDRko7O0FER0k7RUFDRSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7QUNETjs7QURJSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDRk47O0FES0k7RUFDRSxjQUFBO0FDSE47O0FEUUU7RUFDRSwyQkFBQTtBQ0xKOztBRFFFO0VBQ0UscUJBQUE7RUFDQSwrQkFBQTtFQUNBLDJCQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0xKOztBRFFFO0VBRUU7SUFDRSwwQkFBQTtJQUNBLGdCQUFBO0VDTko7O0VEU0U7SUFDRSxjQUFBO0lBQ0EsMEJBQUE7SUFDQSxXQUFBO0lBQ0EsNkJBQUE7RUNOSjs7RURTRTtJQUNFLDBCQUFBO0lBQ0EsMEJBQUE7RUNOSjs7RURTRTtJQUNFLGNBQUE7SUFDQSxzQkFBQTtFQ05KO0VEUUk7SUFDRSxXQUFBO0lBQ0EsZUFBQTtFQ05OO0VET007SUFDRSxVQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLHlCQUFBO0lBQ0EsZ0JBQUE7RUNMUjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvZW5jdWVzdGEvcmVzcG9uZGVyL3Jlc3BvbmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAgIC0tY29sb3I6d2hpdGU7XG4gIH1cbiAgLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICAgIGJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIFx0bWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cblxuICAuaW1hZ2VuLWVuY3Vlc3Rhe1xuICAgIHdpZHRoOiAyMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBtYXJnaW4tYm90dG9tOiA1JTtcbiAgfVxuXG4gIC5jb250ZW5lZG9yLWRlc2NyaXBjaW9uXG4gIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBtYXJnaW4tbGVmdDogNSU7XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cblxuICAuZGVzY3JpcGNpb257XG5cbiAgfVxuXG4gIC5zZWNjaW9uLXNlY2Npb25lc3tcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIG1hcmdpbi10b3A6IDIuNSU7XG4gIH1cbiAgLnNlY2Npb24tcHJlZ3VudGFze1xuICAgIHdpZHRoOiA3MCU7XG4gIH1cblxuICAucHJlZ3VudGF7XG4gICAgbWFyZ2luLWxlZnQ6IDUlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuc2VjY2lvbi1lc3RyZWxsYXN7XG4gICAgd2lkdGg6IDUwJTtcbiAgICBpb24tYmFkZ2V7XG4gICAgICBtYXJnaW4tbGVmdDogMS41JTtcbiAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAtLWNvbG9yOiAjNDI0MjQyO1xuICAgIH1cblxuICAgIC5pY29ub3tcbiAgICAgIHdpZHRoOiAyNXB4O1xuICAgICAgaGVpZ2h0OiAyNXB4O1xuICAgIH1cblxuICAgIC5jYW1iaWFkb3J7XG4gICAgICBjb2xvcjogI2ZmZDYwMDtcbiAgICB9XG5cbiAgfVxuXG4gIC5pb24taXRlbXtcbiAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIH1cblxuICAuaW9uLWJ1dHRvbntcbiAgICAtLWJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzdBOUZDQztcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6ICM3QTlGQ0M7XG4gICAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tdG9wOiAxMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogMTAlO1xuICB9XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU1MHB4KSB7XG5cbiAgICAuc2VjY2lvbi1zZWNjaW9uZXN7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUgIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi10b3A6IDIuNSU7XG4gICAgfVxuXG4gICAgLnNlY2Npb24tcHJlZ3VudGFze1xuICAgICAgbWFyZ2luLXRvcDogNSU7XG4gICAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgLnByZWd1bnRhe1xuICAgICAgbWFyZ2luLXRvcDogMTAlICFpbXBvcnRhbnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuc2VjY2lvbi1lc3RyZWxsYXN7XG4gICAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG5cbiAgICAgIC5iYWRnZXN7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICAgIGlvbi1iYWRnZXtcbiAgICAgICAgICB3aWR0aDogMTAlO1xuICAgICAgICAgIG1hcmdpbi1sZWZ0OiAyLjUlO1xuICAgICAgICAgIG1hcmdpbi1yaWdodDogMi41JTtcbiAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAgIC0tY29sb3I6ICM0MjQyNDI7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiIsImlvbi10b29sYmFyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtLWJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIC0tY29sb3I6d2hpdGU7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWVuY3Vlc3RhIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uY29udGVuZWRvci1kZXNjcmlwY2lvbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDkwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5zZWNjaW9uLXNlY2Npb25lcyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi10b3A6IDIuNSU7XG59XG5cbi5zZWNjaW9uLXByZWd1bnRhcyB7XG4gIHdpZHRoOiA3MCU7XG59XG5cbi5wcmVndW50YSB7XG4gIG1hcmdpbi1sZWZ0OiA1JSAhaW1wb3J0YW50O1xufVxuXG4uc2VjY2lvbi1lc3RyZWxsYXMge1xuICB3aWR0aDogNTAlO1xufVxuLnNlY2Npb24tZXN0cmVsbGFzIGlvbi1iYWRnZSB7XG4gIG1hcmdpbi1sZWZ0OiAxLjUlO1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiAjNDI0MjQyO1xufVxuLnNlY2Npb24tZXN0cmVsbGFzIC5pY29ubyB7XG4gIHdpZHRoOiAyNXB4O1xuICBoZWlnaHQ6IDI1cHg7XG59XG4uc2VjY2lvbi1lc3RyZWxsYXMgLmNhbWJpYWRvciB7XG4gIGNvbG9yOiAjZmZkNjAwO1xufVxuXG4uaW9uLWl0ZW0ge1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjN0E5RkNDO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM3QTlGQ0M7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiAxMCU7XG4gIG1hcmdpbi1ib3R0b206IDEwJTtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDU1MHB4KSB7XG4gIC5zZWNjaW9uLXNlY2Npb25lcyB7XG4gICAgZGlzcGxheTogaW5saW5lICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLXRvcDogMi41JTtcbiAgfVxuXG4gIC5zZWNjaW9uLXByZWd1bnRhcyB7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgbWFyZ2luLWxlZnQ6IDAlICFpbXBvcnRhbnQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gIH1cblxuICAucHJlZ3VudGEge1xuICAgIG1hcmdpbi10b3A6IDEwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1sZWZ0OiAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnNlY2Npb24tZXN0cmVsbGFzIHtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG4gIC5zZWNjaW9uLWVzdHJlbGxhcyAuYmFkZ2VzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gIH1cbiAgLnNlY2Npb24tZXN0cmVsbGFzIC5iYWRnZXMgaW9uLWJhZGdlIHtcbiAgICB3aWR0aDogMTAlO1xuICAgIG1hcmdpbi1sZWZ0OiAyLjUlO1xuICAgIG1hcmdpbi1yaWdodDogMi41JTtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIC0tY29sb3I6ICM0MjQyNDI7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/encuesta/responder/responder.page.ts":
/*!******************************************************!*\
  !*** ./src/app/encuesta/responder/responder.page.ts ***!
  \******************************************************/
/*! exports provided: ResponderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResponderPage", function() { return ResponderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ResponderPage = /** @class */ (function () {
    function ResponderPage(modalCtrl, navParams) {
        this.modalCtrl = modalCtrl;
        this.navParams = navParams;
        this.encuesta = { titulo: '', descripcion: '', preguntas: [], resultados: [], revisado: false };
        this.estrellas = [];
        this.revisados = [];
        this.encuesta = navParams.get('encuesta');
        this.estrellas = this.loqueobtengodebd();
        if (this.encuesta.resultados) {
            for (var i = 0; i < this.estrellas.length; i++) {
                var estrellas = this.estrellas[i];
                var cantidad = this.encuesta.resultados[i];
                for (var j = 0; j < estrellas.length; j++) {
                    if (j < cantidad) {
                        estrellas[j].class = "md hydrated cambiador";
                    }
                }
            }
        }
    }
    ResponderPage.prototype.ngOnInit = function () {
    };
    ResponderPage.prototype.loqueobtengodebd = function () {
        var arr = [];
        for (var i = 0; i < this.encuesta.preguntas.length; i++) {
            var estrellas = [{ "id": "1", "class": "" }, { "id": "2", "class": "" }, { "id": "3", "class": "" }, { "id": "4", "class": "" }, { "id": "5", "class": "" }];
            arr.push(estrellas);
        }
        return arr;
    };
    ResponderPage.prototype.complete = function () {
        if (this.revisados.length == this.encuesta.preguntas.length) {
            return true;
        }
        return false;
    };
    ResponderPage.prototype.cambiarColor = function (indice, i) {
        if (this.revisados.indexOf(indice) == -1) {
            this.revisados.push(indice);
        }
        this.porDefecto(indice);
        var estrellasActuales = this.estrellas[indice];
        for (var e = 0; e < (i + 1); e++) {
            estrellasActuales[e].class = "md hydrated cambiador";
        }
        this.estrellas[indice] = estrellasActuales;
    };
    ResponderPage.prototype.porDefecto = function (indice) {
        for (var i = 0; i < this.estrellas[indice].length; i++) {
            var estrella = this.estrellas[indice][i];
            estrella.class = "md hydrated";
            this.estrellas[indice][i] = estrella;
        }
    };
    ResponderPage.prototype.enviarEncuesta = function () {
        console.log(this.estrellas);
        var cantidades = [];
        var i = 0;
        var indice = 0;
        for (var _i = 0, _a = this.estrellas; _i < _a.length; _i++) {
            var estrellas = _a[_i];
            for (var _b = 0, estrellas_1 = estrellas; _b < estrellas_1.length; _b++) {
                var e = estrellas_1[_b];
                if (e.class.includes("cambiador")) {
                    i++;
                }
            }
            cantidades.push(i);
            i = 0;
        }
        console.log(cantidades);
        this.encuesta.revisado = true;
        this.encuesta.resultados = cantidades;
        this.modalCtrl.dismiss(this.encuesta);
    };
    ResponderPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    ResponderPage.prototype.easteregg = function () {
        console.log('Ricardo Mendez: lower camel case es muy importante para las funciones, no sabes hacer un ni un for, porfavor sigueme en linkedin, principios solid, principio de unica responsabilidad y sustitucion de liskov');
    };
    ResponderPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] }
    ]; };
    ResponderPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-responder',
            template: __webpack_require__(/*! raw-loader!./responder.page.html */ "./node_modules/raw-loader/index.js!./src/app/encuesta/responder/responder.page.html"),
            styles: [__webpack_require__(/*! ./responder.page.scss */ "./src/app/encuesta/responder/responder.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
    ], ResponderPage);
    return ResponderPage;
}());



/***/ }),

/***/ "./src/app/encuestas/escojer/escojer.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/encuestas/escojer/escojer.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VuY3Vlc3Rhcy9lc2NvamVyL2VzY29qZXIucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/encuestas/escojer/escojer.page.ts":
/*!***************************************************!*\
  !*** ./src/app/encuestas/escojer/escojer.page.ts ***!
  \***************************************************/
/*! exports provided: EscojerEncuestasPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EscojerEncuestasPage", function() { return EscojerEncuestasPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var EscojerEncuestasPage = /** @class */ (function () {
    function EscojerEncuestasPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.usuarios = [];
        this.usuarios = navParams.get('usuarios');
    }
    EscojerEncuestasPage.prototype.ngOnInit = function () {
    };
    EscojerEncuestasPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    EscojerEncuestasPage.prototype.guardarPermisos = function () {
        var users = [];
        for (var i = 0; i < this.usuarios.length; i++) {
            if (this.usuarios[i].isChecked) {
                users.push(this.usuarios[i]);
            }
        }
        this.modalCtrl.dismiss(users);
    };
    EscojerEncuestasPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    EscojerEncuestasPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-escojer',
            template: __webpack_require__(/*! raw-loader!./escojer.page.html */ "./node_modules/raw-loader/index.js!./src/app/encuestas/escojer/escojer.page.html"),
            styles: [__webpack_require__(/*! ./escojer.page.scss */ "./src/app/encuestas/escojer/escojer.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], EscojerEncuestasPage);
    return EscojerEncuestasPage;
}());



/***/ }),

/***/ "./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.scss":
/*!**************************************************************************!*\
  !*** ./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #80deea;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #80deea;\n  margin-bottom: 5%;\n}\n\n.imagen-indicador {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: #80deea!important;\n  --background-activated: #80deea !important;\n  --background-hover: #80deea !important;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZW5jdWVzdGFzL3ByZWd1bnRhL2NydWQtZW5jdWVzdGEvY3J1ZC1lbmN1ZXN0YS5wYWdlLnNjc3MiLCJzcmMvYXBwL2VuY3Vlc3Rhcy9wcmVndW50YS9jcnVkLWVuY3Vlc3RhL2NydWQtZW5jdWVzdGEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNBRjs7QURHQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNBRDs7QURHQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7RUFDQTs7OztHQUFBO0FDS0Y7O0FERUE7RUFDRSxtQkFBQTtBQ0NGOztBREVBO0VBQ0Usb0ZBQUE7QUNDRjs7QURBRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDRUY7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlHQUFBO0VBQ0EscUdBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSwrQkFBQTtFQUNBLDBDQUFBO0VBQ0Esc0NBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9lbmN1ZXN0YXMvcHJlZ3VudGEvY3J1ZC1lbmN1ZXN0YS9jcnVkLWVuY3Vlc3RhLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjODBkZWVhO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICBiYWNrZ3JvdW5kOiAjODBkZWVhO1xuXHRtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1pbmRpY2Fkb3J7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICM4MGRlZWEhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjODBkZWVhICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzgwZGVlYSAhaW1wb3J0YW50O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cbiIsImlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICM4MGRlZWE7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICM4MGRlZWE7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluZGljYWRvciB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzgwZGVlYSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICM4MGRlZWEgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjODBkZWVhICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.ts":
/*!************************************************************************!*\
  !*** ./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.ts ***!
  \************************************************************************/
/*! exports provided: CrudEncuestaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CrudEncuestaPage", function() { return CrudEncuestaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var CrudEncuestaPage = /** @class */ (function () {
    function CrudEncuestaPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.titulo = "";
        this.actualizando = false;
        var pregunta = navParams.get('pregunta');
        if (pregunta) {
            this.actualizando = true;
            console.log(pregunta);
            this.titulo = pregunta.titulo;
        }
    }
    CrudEncuestaPage.prototype.ngOnInit = function () {
    };
    CrudEncuestaPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    CrudEncuestaPage.prototype.actualizarEncuesta = function () {
        this.modalCtrl.dismiss({ titulo: this.titulo });
    };
    CrudEncuestaPage.prototype.agregarPregunta = function () {
        this.modalCtrl.dismiss({ titulo: this.titulo });
    };
    CrudEncuestaPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    CrudEncuestaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-crud-encuesta',
            template: __webpack_require__(/*! raw-loader!./crud-encuesta.page.html */ "./node_modules/raw-loader/index.js!./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.html"),
            styles: [__webpack_require__(/*! ./crud-encuesta.page.scss */ "./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], CrudEncuestaPage);
    return CrudEncuestaPage;
}());



/***/ }),

/***/ "./src/app/encuestas/pregunta/pregunta.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/encuestas/pregunta/pregunta.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #80deea;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #80deea;\n  margin-bottom: 5%;\n}\n\n.imagen-indicador {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\n.ion-button {\n  --background: #80deea !important;\n  --background-activated: #80deea !important;\n  --background-hover: #80deea !important;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n.boton-borrar {\n  --background:rgba(3,169,244,1) !important;\n}\n\n.boton-editar {\n  --background:rgba(128,222,234,1) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZW5jdWVzdGFzL3ByZWd1bnRhL3ByZWd1bnRhLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZW5jdWVzdGFzL3ByZWd1bnRhL3ByZWd1bnRhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFOzs7R0FBQTtFQUtBLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FDQUY7O0FER0E7RUFDRSxtQkFBQTtFQUNELGlCQUFBO0FDQUQ7O0FER0E7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNBRjs7QURHQTtFQUFTOzs7R0FBQTtFQUlQLDRCQUFBO0VBQ0EsMEJBQUE7QUNDRjs7QURFQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQ0tGOztBREVBO0VBQ0UsbUJBQUE7QUNDRjs7QURFQTtFQUNFLG9GQUFBO0FDQ0Y7O0FEQUU7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtBQ0VGOztBREVBO0VBQ0UsK0ZBQUE7RUFDQSx5QkFBQTtBQ0NGOztBREVBO0VBQ0UsK0ZBQUE7RUFDQSx5R0FBQTtFQUNBLHFHQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UsZ0NBQUE7RUFDQSwwQ0FBQTtFQUNBLHNDQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtBQ0NGOztBREVBO0VBQ0EseUNBQUE7QUNDQTs7QURFQTtFQUNDLDJDQUFBO0FDQ0QiLCJmaWxlIjoic3JjL2FwcC9lbmN1ZXN0YXMvcHJlZ3VudGEvcHJlZ3VudGEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICM4MGRlZWE7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICM4MGRlZWE7XG5cdG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluZGljYWRvcntcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbXsvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbi5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICM4MGRlZWEgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzgwZGVlYSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM4MGRlZWEgIWltcG9ydGFudDtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG5cbi5ib3Rvbi1ib3JyYXJ7XG4tLWJhY2tncm91bmQ6cmdiYSgzLDE2OSwyNDQsMSkgIWltcG9ydGFudDtcbn1cblxuLmJvdG9uLWVkaXRhcntcbiAtLWJhY2tncm91bmQ6cmdiYSgxMjgsMjIyLDIzNCwxKSAhaW1wb3J0YW50O1xufVxuIiwiaW9uLXRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogIzgwZGVlYTtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogIzgwZGVlYTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4taW5kaWNhZG9yIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xufVxuLmhlYWRlci1jYXJkIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNhcmQtZ3JhZGllbnRlIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG4uaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzgwZGVlYSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjODBkZWVhICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzgwZGVlYSAhaW1wb3J0YW50O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmJvdG9uLWJvcnJhciB7XG4gIC0tYmFja2dyb3VuZDpyZ2JhKDMsMTY5LDI0NCwxKSAhaW1wb3J0YW50O1xufVxuXG4uYm90b24tZWRpdGFyIHtcbiAgLS1iYWNrZ3JvdW5kOnJnYmEoMTI4LDIyMiwyMzQsMSkgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/encuestas/pregunta/pregunta.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/encuestas/pregunta/pregunta.page.ts ***!
  \*****************************************************/
/*! exports provided: PreguntaEncuestaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreguntaEncuestaPage", function() { return PreguntaEncuestaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _crud_encuesta_crud_encuesta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./crud-encuesta/crud-encuesta.page */ "./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.page.ts");




var PreguntaEncuestaPage = /** @class */ (function () {
    function PreguntaEncuestaPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.preguntas = [];
        this.encuesta = navParams.get('encuesta');
    }
    PreguntaEncuestaPage.prototype.ngOnInit = function () {
    };
    PreguntaEncuestaPage.prototype.crearPreguntas = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _crud_encuesta_crud_encuesta_page__WEBPACK_IMPORTED_MODULE_3__["CrudEncuestaPage"],
                            cssClass: 'modals',
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log(modal.data);
                                _this.encuesta.preguntas.push(modal.data);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    PreguntaEncuestaPage.prototype.editarPregunta = function (pregunta, indice) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _crud_encuesta_crud_encuesta_page__WEBPACK_IMPORTED_MODULE_3__["CrudEncuestaPage"],
                            cssClass: 'modals',
                            componentProps: {
                                'pregunta': pregunta,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                _this.encuesta.preguntas[indice] = modal.data;
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    PreguntaEncuestaPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    PreguntaEncuestaPage.prototype.eliminarPregunta = function (indicador, indice) {
        this.encuesta.preguntas.splice(indice, 1);
        console.log(this.encuesta.preguntas);
    };
    PreguntaEncuestaPage.prototype.guardarPreguntas = function () {
        console.log(this.encuesta);
        this.modalCtrl.dismiss(this.encuesta);
    };
    PreguntaEncuestaPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    PreguntaEncuestaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-pregunta',
            template: __webpack_require__(/*! raw-loader!./pregunta.page.html */ "./node_modules/raw-loader/index.js!./src/app/encuestas/pregunta/pregunta.page.html"),
            styles: [__webpack_require__(/*! ./pregunta.page.scss */ "./src/app/encuestas/pregunta/pregunta.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], PreguntaEncuestaPage);
    return PreguntaEncuestaPage;
}());



/***/ }),

/***/ "./src/app/evaluacion/escojer/escojer.page.scss":
/*!******************************************************!*\
  !*** ./src/app/evaluacion/escojer/escojer.page.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWx1YWNpb24vZXNjb2plci9lc2NvamVyLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/evaluacion/escojer/escojer.page.ts":
/*!****************************************************!*\
  !*** ./src/app/evaluacion/escojer/escojer.page.ts ***!
  \****************************************************/
/*! exports provided: EscojerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EscojerPage", function() { return EscojerPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var EscojerPage = /** @class */ (function () {
    function EscojerPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.usuarios = [];
        this.usuarios = navParams.get('usuarios');
    }
    EscojerPage.prototype.ngOnInit = function () {
    };
    EscojerPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    EscojerPage.prototype.guardarPermisos = function () {
        var users = [];
        for (var i = 0; i < this.usuarios.length; i++) {
            if (this.usuarios[i].isChecked) {
                users.push(this.usuarios[i]);
            }
        }
        this.modalCtrl.dismiss(users);
    };
    EscojerPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    EscojerPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-escojer',
            template: __webpack_require__(/*! raw-loader!./escojer.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluacion/escojer/escojer.page.html"),
            styles: [__webpack_require__(/*! ./escojer.page.scss */ "./src/app/evaluacion/escojer/escojer.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], EscojerPage);
    return EscojerPage;
}());



/***/ }),

/***/ "./src/app/evaluacion/importar/importar.page.scss":
/*!********************************************************!*\
  !*** ./src/app/evaluacion/importar/importar.page.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);\nbody {\n  font-family: \"Open Sans\", sans-serif;\n  height: 100%;\n  text-align: center;\n  position: relative;\n}\n.button-wrapper {\n  position: relative;\n  width: 150px;\n  text-align: center;\n  margin: 20% auto;\n}\n.button-wrapper span.label {\n  position: relative;\n  z-index: 0;\n  display: inline-block;\n  width: 100%;\n  background: #b5f7cf;\n  cursor: pointer;\n  color: #fff;\n  padding: 10px 0;\n  text-transform: uppercase;\n  font-size: 12px;\n}\n#upload {\n  display: inline-block;\n  position: absolute;\n  z-index: 1;\n  width: 100%;\n  height: 50px;\n  top: 0;\n  left: 0;\n  opacity: 0;\n  cursor: pointer;\n  border-radius: 10px;\n  background-color: #b5f7cf !important;\n}\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #b5f7cf;\n  --color: white !important;\n}\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n.imagen-importar {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\nion-card {\n  --background: white;\n}\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\nion-button {\n  --background: #b5f7cf;\n  --background-activated: #b5f7cf;\n  --background-hover: #b5f7cf;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbi9pbXBvcnRhci9pbXBvcnRhci5wYWdlLnNjc3MiLCJzcmMvYXBwL2V2YWx1YWNpb24vaW1wb3J0YXIvaW1wb3J0YXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHNFQUFBO0FBRVI7RUFDRSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDQUY7QURHQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNBRjtBREdBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLGVBQUE7QUNBRjtBREdBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLG9DQUFBO0FDQUo7QURHQTtFQUNFOzs7R0FBQTtFQUtBLHFCQUFBO0VBQ0EseUJBQUE7QUNERjtBRElBO0VBQ0UsbUJBQUE7RUFDRCxpQkFBQTtBQ0REO0FESUE7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNERjtBRElBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0FGO0FER0E7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNJRjtBREdBO0VBQ0UsbUJBQUE7QUNBRjtBREdBO0VBQ0Usb0ZBQUE7QUNBRjtBRENFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNDRjtBREdBO0VBQ0UsK0ZBQUE7RUFDQSx5QkFBQTtBQ0FGO0FER0E7RUFDRSwrRkFBQTtFQUNBLHlHQUFBO0VBQ0EscUdBQUE7RUFDQSxjQUFBO0FDQUY7QURHQTtFQUNFLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNBRiIsImZpbGUiOiJzcmMvYXBwL2V2YWx1YWNpb24vaW1wb3J0YXIvaW1wb3J0YXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU9wZW4rU2Fuczo0MDAsNjAwKTtcblxuYm9keXtcbiAgZm9udC1mYW1pbHk6ICdPcGVuIFNhbnMnLCBzYW5zLXNlcmlmO1xuICBoZWlnaHQ6MTAwJTtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xufVxuXG4uYnV0dG9uLXdyYXBwZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxNTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDIwJSBhdXRvO1xufVxuXG4uYnV0dG9uLXdyYXBwZXIgc3Bhbi5sYWJlbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMTBweCAwO1xuICB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7XG4gIGZvbnQtc2l6ZToxMnB4O1xufVxuXG4jdXBsb2FkIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHotaW5kZXg6IDE7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIG9wYWNpdHk6IDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2I1ZjdjZiAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICBiYWNrZ3JvdW5kOiAjYjVmN2NmO1xuXHRtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1pbXBvcnRhcntcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbXsvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cbiIsIkBpbXBvcnQgdXJsKGh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1PcGVuK1NhbnM6NDAwLDYwMCk7XG5ib2R5IHtcbiAgZm9udC1mYW1pbHk6IFwiT3BlbiBTYW5zXCIsIHNhbnMtc2VyaWY7XG4gIGhlaWdodDogMTAwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5idXR0b24td3JhcHBlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDE1MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogMjAlIGF1dG87XG59XG5cbi5idXR0b24td3JhcHBlciBzcGFuLmxhYmVsIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAwO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nOiAxMHB4IDA7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuI3VwbG9hZCB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAxO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA1MHB4O1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIG9wYWNpdHk6IDA7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2I1ZjdjZiAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICBiYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1pbXBvcnRhciB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/evaluacion/importar/importar.page.ts":
/*!******************************************************!*\
  !*** ./src/app/evaluacion/importar/importar.page.ts ***!
  \******************************************************/
/*! exports provided: ImportarPageEvaluacion */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportarPageEvaluacion", function() { return ImportarPageEvaluacion; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var ImportarPageEvaluacion = /** @class */ (function () {
    function ImportarPageEvaluacion(modalCtrl, location) {
        this.modalCtrl = modalCtrl;
        this.location = location;
        this.file = null;
        this.categorias = [];
        this.evaluaciones = [];
    }
    ImportarPageEvaluacion.prototype.ngOnInit = function () {
    };
    ImportarPageEvaluacion.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    ImportarPageEvaluacion.prototype.handleFileInput = function (files) {
        console.log(files);
        this.file = files.item(0);
    };
    ImportarPageEvaluacion.prototype.incomingfile = function (event) {
        this.file = event.target.files[0];
    };
    ImportarPageEvaluacion.prototype.mandarCorreo = function (correo, clave) {
        console.log("correo mandado a " + correo + " tu clave es " + clave);
    };
    ImportarPageEvaluacion.prototype.importar = function () {
        var data = { nombre: this.evaluaciones[0].Titulo, sigla: this.evaluaciones[0].Sigla, categorias: this.categorias };
        this.modalCtrl.dismiss(data);
    };
    ImportarPageEvaluacion.prototype.Upload = function () {
        var _this = this;
        var self = this;
        this.categorias = [];
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            _this.arrayBuffer = fileReader.result;
            var data = new Uint8Array(_this.arrayBuffer);
            var arr = new Array();
            for (var i = 0; i != data.length; ++i)
                arr[i] = String.fromCharCode(data[i]);
            var bstr = arr.join("");
            var workbook = xlsx__WEBPACK_IMPORTED_MODULE_2__["read"](bstr, { type: "binary" });
            var first_sheet_name = workbook.SheetNames[0];
            var worksheet = workbook.Sheets[first_sheet_name];
            var datos = xlsx__WEBPACK_IMPORTED_MODULE_2__["utils"].sheet_to_json(worksheet, { raw: true });
            console.log(datos);
            for (var i_1 = 0; i_1 < datos.length; i_1++) {
                var data_1 = datos[i_1];
                if (!data_1.Sigla || !data_1.Titulo || !data_1.Categoria || !data_1.Indicador) {
                    alert("TIENE DATOS CORRUPTOS");
                    return false;
                }
            }
            for (var i_2 = 0; i_2 < datos.length; i_2++) {
                var data_2 = datos[i_2];
                var indicador = { titulo: data_2.Indicador, tipo: (data_2.Tipo || 'Porcentaje') };
                if (self.categorias[data_2.Categoria]) {
                    self.categorias[data_2.Categoria].push(indicador);
                }
                else {
                    self.categorias[data_2.Categoria] = [];
                    self.categorias[data_2.Categoria].push(indicador);
                }
                //let usuario = {firstName:data.Nombre,lastName:data.Apellido,rut:data.Rut,phone:data.Telefono,email:data.Correo,cargo:data.Cargo,password:password};
                self.evaluaciones.push(data_2);
                //self.mandarCorreo(usuario);
            }
            console.log(self.evaluaciones);
            console.log(self.categorias);
        };
        fileReader.readAsArrayBuffer(this.file);
    };
    ImportarPageEvaluacion.prototype.tamObjeto = function (objeto) {
        var i = 0;
        for (var obj in objeto) {
            i += 1;
        }
        return i;
    };
    ImportarPageEvaluacion.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"] }
    ]; };
    ImportarPageEvaluacion = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-importar',
            template: __webpack_require__(/*! raw-loader!./importar.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluacion/importar/importar.page.html"),
            styles: [__webpack_require__(/*! ./importar.page.scss */ "./src/app/evaluacion/importar/importar.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"]])
    ], ImportarPageEvaluacion);
    return ImportarPageEvaluacion;
}());

//inside export class


/***/ }),

/***/ "./src/app/evaluacion/pregunta/crud/crud.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/evaluacion/pregunta/crud/crud.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #b5f7cf;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n\n.imagen-indicador {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: #b5f7cf!important;\n  --background-activated: #b5f7cf !important;\n  --background-hover: #b5f7cf !important;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbi9wcmVndW50YS9jcnVkL2NydWQucGFnZS5zY3NzIiwic3JjL2FwcC9ldmFsdWFjaW9uL3ByZWd1bnRhL2NydWQvY3J1ZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRTs7O0dBQUE7RUFLQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQ0UsbUJBQUE7RUFDRCxpQkFBQTtBQ0FEOztBREdBO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FDQUY7O0FER0E7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNLRjs7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxvRkFBQTtBQ0NGOztBREFFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNFRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUJBQUE7QUNDRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLCtCQUFBO0VBQ0EsMENBQUE7RUFDQSxzQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL2V2YWx1YWNpb24vcHJlZ3VudGEvY3J1ZC9jcnVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICBiYWNrZ3JvdW5kOiAjYjVmN2NmO1xuXHRtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1pbmRpY2Fkb3J7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2YhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjYjVmN2NmICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogI2I1ZjdjZiAhaW1wb3J0YW50O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cbiIsImlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluZGljYWRvciB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZiFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICNiNWY3Y2YgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/evaluacion/pregunta/crud/crud.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/evaluacion/pregunta/crud/crud.page.ts ***!
  \*******************************************************/
/*! exports provided: CrudPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CrudPage", function() { return CrudPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var CrudPage = /** @class */ (function () {
    function CrudPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.indicador = "";
        this.categoria = "";
        this.tipo = "";
        this.editando = false;
        var indicador = navParams.get('pregunta');
        var key = navParams.get('key');
        if (indicador) {
            this.editando = true;
            this.tipo = indicador.tipo;
            this.indicador = indicador.titulo;
            this.categoria = key;
        }
    }
    CrudPage.prototype.ngOnInit = function () {
    };
    CrudPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    CrudPage.prototype.actualizar = function () {
        var indicador = { tipo: this.tipo, titulo: this.indicador };
        this.modalCtrl.dismiss(indicador);
    };
    CrudPage.prototype.validarValores = function (min, max) {
        if (min < 0) {
            return false;
        }
        if (min < max) {
            return true;
        }
        return false;
    };
    CrudPage.prototype.agregarIndicador = function () {
        var tipoPregunta = {};
        if (this.tipo == 'Rango') {
            tipoPregunta = { min: this.min, max: this.max, titulo: this.indicador, tipo: this.tipo, categoria: this.categoria };
        }
        else {
            tipoPregunta = { titulo: this.indicador, tipo: this.tipo, categoria: this.categoria };
        }
        this.modalCtrl.dismiss(tipoPregunta);
    };
    CrudPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    CrudPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-crud',
            template: __webpack_require__(/*! raw-loader!./crud.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluacion/pregunta/crud/crud.page.html"),
            styles: [__webpack_require__(/*! ./crud.page.scss */ "./src/app/evaluacion/pregunta/crud/crud.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], CrudPage);
    return CrudPage;
}());



/***/ }),

/***/ "./src/app/evaluacion/pregunta/importar/importar.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/evaluacion/pregunta/importar/importar.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);\nbody {\n  font-family: \"Open Sans\", sans-serif;\n  height: 100%;\n  text-align: center;\n  position: relative;\n}\n.button-wrapper {\n  position: relative;\n  width: 150px;\n  text-align: center;\n  margin: 20% auto;\n}\n.button-wrapper span.label {\n  position: relative;\n  z-index: 0;\n  display: inline-block;\n  width: 100%;\n  background: #00bfff;\n  cursor: pointer;\n  color: #fff;\n  padding: 10px 0;\n  text-transform: uppercase;\n  font-size: 12px;\n}\n#upload {\n  display: inline-block;\n  position: absolute;\n  z-index: 1;\n  width: 100%;\n  height: 50px;\n  top: 0;\n  left: 0;\n  opacity: 0;\n  cursor: pointer;\n}\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #b5f7cf;\n  --color: white !important;\n}\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n.imagen-indicador {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\nion-card {\n  --background: white;\n}\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\nion-button {\n  --background: #b5f7cf !important;\n  --background-activated: #b5f7cf !important;\n  --background-hover: #b5f7cf !important;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbi9wcmVndW50YS9pbXBvcnRhci9pbXBvcnRhci5wYWdlLnNjc3MiLCJzcmMvYXBwL2V2YWx1YWNpb24vcHJlZ3VudGEvaW1wb3J0YXIvaW1wb3J0YXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHNFQUFBO0FBRVI7RUFDRSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDQUY7QURHQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNBRjtBREdBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLGVBQUE7QUNBRjtBREdBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUNBSjtBREdBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtBQ0RGO0FESUE7RUFDRSxtQkFBQTtFQUNELGlCQUFBO0FDREQ7QURJQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0RGO0FES0E7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDREY7QURJQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQ0dGO0FESUE7RUFDRSxtQkFBQTtBQ0RGO0FESUE7RUFDRSxvRkFBQTtBQ0RGO0FERUU7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtBQ0FGO0FESUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDREY7QURJQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNERjtBRElBO0VBQ0UsZ0NBQUE7RUFDQSwwQ0FBQTtFQUNBLHNDQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtBQ0RGIiwiZmlsZSI6InNyYy9hcHAvZXZhbHVhY2lvbi9wcmVndW50YS9pbXBvcnRhci9pbXBvcnRhci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybChodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zOjQwMCw2MDApO1xuXG5ib2R5e1xuICBmb250LWZhbWlseTogJ09wZW4gU2FucycsIHNhbnMtc2VyaWY7XG4gIGhlaWdodDoxMDAlO1xuICB0ZXh0LWFsaWduOmNlbnRlcjtcbiAgcG9zaXRpb246cmVsYXRpdmU7XG59XG5cbi5idXR0b24td3JhcHBlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDE1MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogMjAlIGF1dG87XG59XG5cbi5idXR0b24td3JhcHBlciBzcGFuLmxhYmVsIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAwO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiAjMDBiZmZmO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nOiAxMHB4IDA7XG4gIHRleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTtcbiAgZm9udC1zaXplOjEycHg7XG59XG5cbiN1cGxvYWQge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgei1pbmRleDogMTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDUwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3BhY2l0eTogMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbmlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICNiNWY3Y2Y7XG5cdG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluZGljYWRvcntcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5cbmlvbi1pdGVtey8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJke1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbiAgaW9uLWl0ZW17XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIH1cbn1cblxuLmNhcmQtZ3JhZGllbnRle1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICNiNWY3Y2YgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufVxuIiwiQGltcG9ydCB1cmwoaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PU9wZW4rU2Fuczo0MDAsNjAwKTtcbmJvZHkge1xuICBmb250LWZhbWlseTogXCJPcGVuIFNhbnNcIiwgc2Fucy1zZXJpZjtcbiAgaGVpZ2h0OiAxMDAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmJ1dHRvbi13cmFwcGVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTUwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAyMCUgYXV0bztcbn1cblxuLmJ1dHRvbi13cmFwcGVyIHNwYW4ubGFiZWwge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHotaW5kZXg6IDA7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6ICMwMGJmZmY7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIHBhZGRpbmc6IDEwcHggMDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1zaXplOiAxMnB4O1xufVxuXG4jdXBsb2FkIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IDE7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwcHg7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgb3BhY2l0eTogMDtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICBiYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1pbmRpY2Fkb3Ige1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2YgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZiAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICNiNWY3Y2YgIWltcG9ydGFudDtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/evaluacion/pregunta/importar/importar.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/evaluacion/pregunta/importar/importar.page.ts ***!
  \***************************************************************/
/*! exports provided: ImportarPagePregunta */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportarPagePregunta", function() { return ImportarPagePregunta; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var ImportarPagePregunta = /** @class */ (function () {
    function ImportarPagePregunta(modalCtrl, location) {
        this.modalCtrl = modalCtrl;
        this.location = location;
        this.file = null;
        this.usuarios = [];
    }
    ImportarPagePregunta.prototype.ngOnInit = function () {
    };
    ImportarPagePregunta.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    ImportarPagePregunta.prototype.handleFileInput = function (files) {
        console.log(files);
        this.file = files.item(0);
    };
    ImportarPagePregunta.prototype.incomingfile = function (event) {
        this.file = event.target.files[0];
    };
    ImportarPagePregunta.prototype.mandarCorreo = function (correo, clave) {
        console.log("correo mandado a " + correo + " tu clave es " + clave);
    };
    ImportarPagePregunta.prototype.Upload = function () {
        var _this = this;
        var self = this;
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            _this.arrayBuffer = fileReader.result;
            var data = new Uint8Array(_this.arrayBuffer);
            var arr = new Array();
            for (var i = 0; i != data.length; ++i)
                arr[i] = String.fromCharCode(data[i]);
            var bstr = arr.join("");
            var workbook = xlsx__WEBPACK_IMPORTED_MODULE_2__["read"](bstr, { type: "binary" });
            var first_sheet_name = workbook.SheetNames[0];
            var worksheet = workbook.Sheets[first_sheet_name];
            var datos = xlsx__WEBPACK_IMPORTED_MODULE_2__["utils"].sheet_to_json(worksheet, { raw: true });
            for (var i_1 = 0; i_1 < datos.length; i_1++) {
                console.log(datos[i_1]);
            }
            console.log(self.usuarios);
        };
        fileReader.readAsArrayBuffer(this.file);
    };
    ImportarPagePregunta.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"] }
    ]; };
    ImportarPagePregunta = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-importar',
            template: __webpack_require__(/*! raw-loader!./importar.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluacion/pregunta/importar/importar.page.html"),
            styles: [__webpack_require__(/*! ./importar.page.scss */ "./src/app/evaluacion/pregunta/importar/importar.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"]])
    ], ImportarPagePregunta);
    return ImportarPagePregunta;
}());

//inside export class


/***/ }),

/***/ "./src/app/evaluacion/pregunta/pregunta.page.scss":
/*!********************************************************!*\
  !*** ./src/app/evaluacion/pregunta/pregunta.page.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #b5f7cf;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n\n.imagen-indicador {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\n.ion-button {\n  --background: #b5f7cf !important;\n  --background-activated: #b5f7cf !important;\n  --background-hover: #b5f7cf !important;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n.boton-borrar {\n  --background:rgba(3,169,244,1) !important;\n}\n\n.boton-editar {\n  --background:rgba(128,222,234,1) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbi9wcmVndW50YS9wcmVndW50YS5wYWdlLnNjc3MiLCJzcmMvYXBwL2V2YWx1YWNpb24vcHJlZ3VudGEvcHJlZ3VudGEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNBRjs7QURHQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNBRDs7QURHQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7RUFDQTs7OztHQUFBO0FDS0Y7O0FERUE7RUFDRSxtQkFBQTtBQ0NGOztBREVBO0VBQ0Usb0ZBQUE7QUNDRjs7QURBRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDRUY7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlHQUFBO0VBQ0EscUdBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQ0FBQTtFQUNBLDBDQUFBO0VBQ0Esc0NBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDQ0Y7O0FERUE7RUFDQSx5Q0FBQTtBQ0NBOztBREVBO0VBQ0MsMkNBQUE7QUNDRCIsImZpbGUiOiJzcmMvYXBwL2V2YWx1YWNpb24vcHJlZ3VudGEvcHJlZ3VudGEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICNiNWY3Y2Y7XG5cdG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluZGljYWRvcntcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbXsvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbi5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2YgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZiAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICNiNWY3Y2YgIWltcG9ydGFudDtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG5cbi5ib3Rvbi1ib3JyYXJ7XG4tLWJhY2tncm91bmQ6cmdiYSgzLDE2OSwyNDQsMSkgIWltcG9ydGFudDtcbn1cblxuLmJvdG9uLWVkaXRhcntcbiAtLWJhY2tncm91bmQ6cmdiYSgxMjgsMjIyLDIzNCwxKSAhaW1wb3J0YW50O1xufVxuIiwiaW9uLXRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4taW5kaWNhZG9yIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xufVxuLmhlYWRlci1jYXJkIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNhcmQtZ3JhZGllbnRlIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG4uaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZiAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjYjVmN2NmICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogI2I1ZjdjZiAhaW1wb3J0YW50O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmJvdG9uLWJvcnJhciB7XG4gIC0tYmFja2dyb3VuZDpyZ2JhKDMsMTY5LDI0NCwxKSAhaW1wb3J0YW50O1xufVxuXG4uYm90b24tZWRpdGFyIHtcbiAgLS1iYWNrZ3JvdW5kOnJnYmEoMTI4LDIyMiwyMzQsMSkgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/evaluacion/pregunta/pregunta.page.ts":
/*!******************************************************!*\
  !*** ./src/app/evaluacion/pregunta/pregunta.page.ts ***!
  \******************************************************/
/*! exports provided: PreguntaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreguntaPage", function() { return PreguntaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _importar_importar_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./importar/importar.page */ "./src/app/evaluacion/pregunta/importar/importar.page.ts");
/* harmony import */ var _crud_crud_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./crud/crud.page */ "./src/app/evaluacion/pregunta/crud/crud.page.ts");





var PreguntaPage = /** @class */ (function () {
    function PreguntaPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.indicadores = [];
        this.categorias = [];
        this.tipos = ["porcentaje", "numerico", "rango"];
        this.evaluacion = navParams.get('evaluacion');
        console.log("evaluacion en modal pregunta", this.evaluacion);
        var categorias = this.evaluacion.indicadores;
        if (categorias.length > 0) {
            this.indicadores = categorias;
            for (var i = 0; i < this.indicadores.length; i++) {
                var data = this.indicadores[i];
                var indicador = { titulo: data.titulo, tipo: data.tipo };
                if (this.categorias[data.categoria]) {
                    this.categorias[data.categoria].push(indicador);
                }
                else {
                    this.categorias[data.categoria] = [];
                    this.categorias[data.categoria].push(indicador);
                }
            }
        }
        else {
            for (var key in categorias) {
                var categoria = categorias[key];
                for (var i = 0; i < categoria.length; i++) {
                    var indicador = categoria[i];
                    indicador.categoria = key;
                    this.indicadores.push(indicador);
                }
            }
        }
        console.log(this.indicadores);
        console.log(this.evaluacion.indicadores);
        this.agrupar();
    }
    PreguntaPage.prototype.editarIndicador = function (indicador, key, indice) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _crud_crud_page__WEBPACK_IMPORTED_MODULE_4__["CrudPage"],
                            cssClass: 'modals',
                            componentProps: {
                                'pregunta': indicador,
                                'key': key
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                _this.categorias[key][indice] = modal.data;
                                console.log(_this.categorias[key][indice]);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    PreguntaPage.prototype.eliminarIndicador = function (indicador, key, indice) {
        console.log(indicador);
        this.categorias[key].splice(indice, 1);
        console.log(this.categorias);
    };
    PreguntaPage.prototype.ngOnInit = function () {
    };
    PreguntaPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    PreguntaPage.prototype.crearIndicador = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _crud_crud_page__WEBPACK_IMPORTED_MODULE_4__["CrudPage"],
                            cssClass: 'modals'
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log(modal);
                                _this.indicadores.push(modal.data);
                                _this.agrupar();
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    PreguntaPage.prototype.abrirImportar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _importar_importar_page__WEBPACK_IMPORTED_MODULE_3__["ImportarPagePregunta"],
                            cssClass: 'modals',
                            componentProps: {
                                'evaluacion': this.evaluacion,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            console.log("datos", modal);
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    PreguntaPage.prototype.editarPregunta = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _crud_crud_page__WEBPACK_IMPORTED_MODULE_4__["CrudPage"],
                            cssClass: 'modals',
                            componentProps: {
                                'evaluacion': ev,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            console.log("en indicadores", modal);
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    PreguntaPage.prototype.guardarindicadores = function () {
        //this.agrupar();
        console.log("categorias", this.categorias);
        this.modalCtrl.dismiss(this.categorias);
    };
    PreguntaPage.prototype.getKeys = function (obj) {
        return Object.keys(obj);
    };
    PreguntaPage.prototype.verIndicadores = function () {
        console.log(this.categorias);
        console.log(this.indicadores);
    };
    PreguntaPage.prototype.agrupar = function () {
        this.categorias = [];
        for (var i = 0; i < this.indicadores.length; i++) {
            var data = this.indicadores[i];
            var indicador = { titulo: data.titulo, tipo: data.tipo };
            if (this.categorias[data.categoria]) {
                this.categorias[data.categoria].push(indicador);
            }
            else {
                this.categorias[data.categoria] = [];
                this.categorias[data.categoria].push(indicador);
            }
        }
    };
    PreguntaPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    PreguntaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-pregunta',
            template: __webpack_require__(/*! raw-loader!./pregunta.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluacion/pregunta/pregunta.page.html"),
            styles: [__webpack_require__(/*! ./pregunta.page.scss */ "./src/app/evaluacion/pregunta/pregunta.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], PreguntaPage);
    return PreguntaPage;
}());



/***/ }),

/***/ "./src/app/evaluaciones/historial/historial.page.scss":
/*!************************************************************!*\
  !*** ./src/app/evaluaciones/historial/historial.page.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWx1YWNpb25lcy9oaXN0b3JpYWwvaGlzdG9yaWFsLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/evaluaciones/historial/historial.page.ts":
/*!**********************************************************!*\
  !*** ./src/app/evaluaciones/historial/historial.page.ts ***!
  \**********************************************************/
/*! exports provided: HistorialPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HistorialPage", function() { return HistorialPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



//import { GraficoPage } from './grafico/grafico.page';
var HistorialPage = /** @class */ (function () {
    function HistorialPage(modalCtrl, navParams) {
        this.modalCtrl = modalCtrl;
        this.navParams = navParams;
        this.tipo = "";
        this.datos = [];
        this.items = [];
        this.datos = navParams.get('evaluaciones');
    }
    HistorialPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    HistorialPage.prototype.ngOnInit = function () {
    };
    HistorialPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] }
    ]; };
    HistorialPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-historial',
            template: __webpack_require__(/*! raw-loader!./historial.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/historial/historial.page.html"),
            styles: [__webpack_require__(/*! ./historial.page.scss */ "./src/app/evaluaciones/historial/historial.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
    ], HistorialPage);
    return HistorialPage;
}());



/***/ }),

/***/ "./src/app/evaluaciones/instrumento/instrumento.page.scss":
/*!****************************************************************!*\
  !*** ./src/app/evaluaciones/instrumento/instrumento.page.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "*, *:before, *:after {\n  box-sizing: border-box;\n  outline: none;\n}\n\nbody {\n  position: relative;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n  width: 100%;\n  height: 100vh;\n  background-color: whitesmoke;\n  font-family: \"Source Sans Pro\", sans-serif;\n  font-size: 16px;\n  font-smooth: auto;\n  font-weight: 300;\n  line-height: 1.5;\n  color: #444;\n  background-image: url(\"http://dakotarumors.com/assets/img/header-bg.jpg\");\n  background-position: center center;\n  background-size: cover;\n}\n\nbody:before {\n  position: absolute;\n  content: \"\";\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background-color: rgba(255, 255, 255, 0.7);\n  z-index: -1;\n}\n\np {\n  font-weight: 400;\n}\n\na {\n  text-decoration: none;\n}\n\nlabel {\n  cursor: pointer;\n}\n\n.modal-btn {\n  position: relative;\n  display: table-cell;\n  width: 100px;\n  height: 100px;\n  background-color: #2c3e50;\n  box-shadow: 0 0 40px rgba(0, 0, 0, 0.3);\n  border-radius: 50%;\n  font-size: 36px;\n  color: white;\n  text-align: center;\n  line-height: 2.75;\n  -webkit-transition: box-shadow 250ms ease;\n  transition: box-shadow 250ms ease;\n}\n\n.modal-btn:hover {\n  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);\n}\n\n.modal-bg {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  opacity: 0;\n  z-index: 10;\n  visibility: hidden;\n  -webkit-transition: background-color 250ms linear;\n  transition: background-color 250ms linear;\n}\n\n.modal-content {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  width: 50%;\n  height: auto;\n  margin-top: -18%;\n  margin-left: -25%;\n  padding: 30px;\n  background-color: white;\n  border-radius: 4px;\n  box-shadow: 0 0 50px rgba(0, 0, 0, 0.5);\n  -webkit-transform: scale(0);\n          transform: scale(0);\n  -webkit-transition: -webkit-transform 250ms ease;\n  transition: -webkit-transform 250ms ease;\n  transition: transform 250ms ease;\n  transition: transform 250ms ease, -webkit-transform 250ms ease;\n  visibility: hidden;\n  z-index: 20;\n}\n\n.modal-content .close {\n  position: relative;\n  float: right;\n  font-size: 18px;\n  -webkit-transition: -webkit-transform 500ms ease;\n  transition: -webkit-transform 500ms ease;\n  transition: transform 500ms ease;\n  transition: transform 500ms ease, -webkit-transform 500ms ease;\n  z-index: 11;\n}\n\n.modal-content .close:hover {\n  color: #3498db;\n  -webkit-transform: rotate(540deg);\n          transform: rotate(540deg);\n}\n\n.modal-content header {\n  position: relative;\n  display: block;\n  border-bottom: 1px solid #eee;\n}\n\n.modal-content header h2 {\n  margin: 0 0 10px;\n  padding: 0;\n  font-size: 28px;\n}\n\n.modal-content article {\n  position: relative;\n  display: block;\n  margin: 0;\n  padding: 0;\n  font-size: 16px;\n  line-height: 1.75;\n}\n\n.modal-content footer {\n  position: relative;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: end;\n          justify-content: flex-end;\n  width: 100%;\n  margin: 0;\n  padding: 10px 0 0;\n}\n\n.modal-content footer .button {\n  position: relative;\n  padding: 10px 30px;\n  border-radius: 3px;\n  font-size: 14px;\n  font-weight: 400;\n  color: white;\n  text-transform: uppercase;\n  overflow: hidden;\n}\n\n.modal-content footer .button:before {\n  position: absolute;\n  content: \"\";\n  top: 0;\n  left: 0;\n  width: 0;\n  height: 100%;\n  background-color: rgba(255, 255, 255, 0.2);\n  -webkit-transition: width 250ms ease;\n  transition: width 250ms ease;\n  z-index: 0;\n}\n\n.modal-content footer .button:hover:before {\n  width: 100%;\n}\n\n.modal-content footer .button.success {\n  margin-right: 5px;\n  background-color: #2ecc71;\n}\n\n.modal-content footer .button.danger {\n  background-color: #e74c3c;\n}\n\n#modal {\n  display: none;\n}\n\n#modal:checked ~ .modal-bg {\n  visibility: visible;\n  background-color: black;\n  opacity: 0.7;\n  -webkit-transition: background-color 250ms linear;\n  transition: background-color 250ms linear;\n}\n\n#modal:checked ~ .modal-content {\n  visibility: visible;\n  -webkit-transform: scale(1);\n          transform: scale(1);\n  -webkit-transition: -webkit-transform 250ms ease;\n  transition: -webkit-transform 250ms ease;\n  transition: transform 250ms ease;\n  transition: transform 250ms ease, -webkit-transform 250ms ease;\n  z-index: 111;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #e91e63;\n  --color: white !important;\n}\n\n.contenedor-imagen {\n  background: #e91e63;\n  margin-bottom: 5%;\n}\n\n.imagen-instrumento {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\n.ion-button {\n  color: white;\n  --background: #e91e63;\n  --background-activated: #e91e63;\n  --background-hover: #e91e63;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbmVzL2luc3RydW1lbnRvL2luc3RydW1lbnRvLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZXZhbHVhY2lvbmVzL2luc3RydW1lbnRvL2luc3RydW1lbnRvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFlQTtFQUNDLHNCQUFBO0VBQ0EsYUFBQTtBQ2REOztBRGlCQTtFQUNDLGtCQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0VBQ0EsNEJBQUE7RUFBQSw2QkFBQTtVQUFBLHNCQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDRCQUFBO0VBQ0EsMENBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLHlFQUFBO0VBQ0Esa0NBQUE7RUFDQSxzQkFBQTtBQ2REOztBRGdCQztFQUNDLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSwwQ0FBQTtFQUNBLFdBQUE7QUNkRjs7QURrQkE7RUFBSSxnQkFBQTtBQ2RKOztBRGdCQTtFQUFJLHFCQUFBO0FDWko7O0FEY0E7RUFDQyxlQUFBO0FDWEQ7O0FEY0E7RUFDQyxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx5QkEzRFM7RUE0RFQsdUNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLHlDQUFBO0VBQUEsaUNBQUE7QUNYRDs7QURhQztFQUNDLHNDQUFBO0FDWEY7O0FEZUE7RUFDQyxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaURBQUE7RUFBQSx5Q0FBQTtBQ1pEOztBRGVBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUNBQUE7RUFDQSwyQkFBQTtVQUFBLG1CQUFBO0VBQ0EsZ0RBQUE7RUFBQSx3Q0FBQTtFQUFBLGdDQUFBO0VBQUEsOERBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNaRDs7QURjQztFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnREFBQTtFQUFBLHdDQUFBO0VBQUEsZ0NBQUE7RUFBQSw4REFBQTtFQUNBLFdBQUE7QUNaRjs7QURjRTtFQUNDLGNBN0dPO0VBOEdQLGlDQUFBO1VBQUEseUJBQUE7QUNaSDs7QURnQkM7RUFDQyxrQkFBQTtFQUNBLGNBQUE7RUFDQSw2QkFBQTtBQ2RGOztBRGlCRTtFQUNDLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUNmSDs7QURtQkM7RUFDQyxrQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ2pCRjs7QUR3QkM7RUFDQyxrQkFBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHlCQUFBO1VBQUEsbUJBQUE7RUFDQSxxQkFBQTtVQUFBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtBQ3RCRjs7QUR3QkU7RUFDQyxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtBQ3RCSDs7QUR3Qkc7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsMENBQUE7RUFDQSxvQ0FBQTtFQUFBLDRCQUFBO0VBQ0EsVUFBQTtBQ3RCSjs7QUQyQkk7RUFDQyxXQUFBO0FDekJMOztBRDZCRztFQUNDLGlCQUFBO0VBQ0EseUJBbkxNO0FDd0pWOztBRDhCRztFQUNDLHlCQXRMTTtBQzBKVjs7QURrQ0E7RUFDQyxhQUFBO0FDL0JEOztBRGlDQztFQUNDLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsaURBQUE7RUFBQSx5Q0FBQTtBQy9CRjs7QURrQ0M7RUFDQyxtQkFBQTtFQUNBLDJCQUFBO1VBQUEsbUJBQUE7RUFDQSxnREFBQTtFQUFBLHdDQUFBO0VBQUEsZ0NBQUE7RUFBQSw4REFBQTtFQUNBLFlBQUE7QUNoQ0Y7O0FEb0NBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtBQ2xDRjs7QURxQ0E7RUFDRSxtQkFBQTtFQUNELGlCQUFBO0FDbENEOztBRHFDQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ2xDRjs7QURxQ0E7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDakNGOztBRG9DQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQzdCRjs7QURvQ0E7RUFDRSxtQkFBQTtBQ2pDRjs7QURvQ0E7RUFDRSxvRkFBQTtBQ2pDRjs7QURrQ0U7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtBQ2hDRjs7QURvQ0E7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDakNGOztBRG9DQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNqQ0Y7O0FEb0NBO0VBQ0MsWUFBQTtFQUNDLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNqQ0YiLCJmaWxlIjoic3JjL2FwcC9ldmFsdWFjaW9uZXMvaW5zdHJ1bWVudG8vaW5zdHJ1bWVudG8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbiRiYXNlLWR1cmF0aW9uOiA1MDBtcztcblxuLy8gQ29sb3JzXG4kY29sb3ItMTogIzJjM2U1MDtcbiRjb2xvci0yOiAjMzQ5OGRiO1xuJGNvbG9yLTM6ICMyZWNjNzE7XG4kY29sb3ItNDogI2U3NGMzYztcblxuLy8gQnJlYWtwb2ludHNcbiRzbTogbmV3LWJyZWFrcG9pbnQobWluLXdpZHRoIDMyMHB4KTtcbiRtZWQ6IG5ldy1icmVha3BvaW50KG1pbi13aWR0aCA3NjhweCk7XG4kbGc6IG5ldy1icmVha3BvaW50KG1pbi13aWR0aCAxMDI0cHgpO1xuXG4qLCAqOmJlZm9yZSwgKjphZnRlciB7XG5cdGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cdG91dGxpbmU6IG5vbmU7XG59XG5cbmJvZHkge1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXHR3aWR0aDogMTAwJTtcblx0aGVpZ2h0OiAxMDB2aDtcblx0YmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcblx0Zm9udC1mYW1pbHk6ICdTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmO1xuXHRmb250LXNpemU6IDE2cHg7XG5cdGZvbnQtc21vb3RoOiBhdXRvO1xuXHRmb250LXdlaWdodDogMzAwO1xuXHRsaW5lLWhlaWdodDogMS41O1xuXHRjb2xvcjogIzQ0NDtcblx0YmFja2dyb3VuZC1pbWFnZTogdXJsKCdodHRwOi8vZGFrb3RhcnVtb3JzLmNvbS9hc3NldHMvaW1nL2hlYWRlci1iZy5qcGcnKTtcblx0YmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcblx0YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcblxuXHQmOmJlZm9yZSB7XG5cdFx0cG9zaXRpb246IGFic29sdXRlO1xuXHRcdGNvbnRlbnQ6ICcnO1xuXHRcdHRvcDogMDtcblx0XHRsZWZ0OiAwO1xuXHRcdHdpZHRoOiAxMDAlO1xuXHRcdGhlaWdodDogMTAwJTtcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKHdoaXRlLDAuNyk7XG5cdFx0ei1pbmRleDogLTE7XG5cdH1cbn1cblxucCB7IGZvbnQtd2VpZ2h0OiA0MDA7IH1cblxuYSB7IHRleHQtZGVjb3JhdGlvbjogbm9uZTsgfVxuXG5sYWJlbCB7XG5cdGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLm1vZGFsLWJ0biB7XG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0ZGlzcGxheTogdGFibGUtY2VsbDtcblx0d2lkdGg6IDEwMHB4O1xuXHRoZWlnaHQ6IDEwMHB4O1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItMTtcblx0Ym94LXNoYWRvdzogMCAwIDQwcHggcmdiYShibGFjaywwLjMpO1xuXHRib3JkZXItcmFkaXVzOiA1MCU7XG5cdGZvbnQtc2l6ZTogMzZweDtcblx0Y29sb3I6IHdoaXRlO1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdGxpbmUtaGVpZ2h0OiAyLjc1O1xuXHR0cmFuc2l0aW9uOiBib3gtc2hhZG93IDI1MG1zIGVhc2U7XG5cblx0Jjpob3ZlciB7XG5cdFx0Ym94LXNoYWRvdzogMCAwIDVweCByZ2JhKGJsYWNrLDAuMyk7XG5cdH1cbn1cblxuLm1vZGFsLWJnIHtcblx0cG9zaXRpb246IGFic29sdXRlO1xuXHR0b3A6IDA7XG5cdGxlZnQ6IDA7XG5cdHdpZHRoOiAxMDAlO1xuXHRoZWlnaHQ6IDEwMCU7XG5cdG9wYWNpdHk6IDA7XG5cdHotaW5kZXg6IDEwO1xuXHR2aXNpYmlsaXR5OiBoaWRkZW47XG5cdHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgJGJhc2UtZHVyYXRpb24vMiBsaW5lYXI7XG59XG5cbi5tb2RhbC1jb250ZW50IHtcblx0cG9zaXRpb246IGFic29sdXRlO1xuXHR0b3A6IDUwJTtcblx0bGVmdDogNTAlO1xuXHR3aWR0aDogNTAlO1xuXHRoZWlnaHQ6IGF1dG87XG5cdG1hcmdpbi10b3A6IC0xOCU7XG5cdG1hcmdpbi1sZWZ0OiAtMjUlO1xuXHRwYWRkaW5nOiAzMHB4O1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcblx0Ym9yZGVyLXJhZGl1czogNHB4O1xuXHRib3gtc2hhZG93OiAwIDAgNTBweCByZ2JhKGJsYWNrLDAuNSk7XG5cdHRyYW5zZm9ybTogc2NhbGUoMCk7XG5cdHRyYW5zaXRpb246IHRyYW5zZm9ybSAkYmFzZS1kdXJhdGlvbi8yIGVhc2U7XG5cdHZpc2liaWxpdHk6IGhpZGRlbjtcblx0ei1pbmRleDogMjA7XG5cblx0LmNsb3NlIHtcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdFx0ZmxvYXQ6IHJpZ2h0O1xuXHRcdGZvbnQtc2l6ZTogMThweDtcblx0XHR0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gJGJhc2UtZHVyYXRpb24gZWFzZTtcblx0XHR6LWluZGV4OiAxMTtcblxuXHRcdCY6aG92ZXIge1xuXHRcdFx0Y29sb3I6ICRjb2xvci0yO1xuXHRcdFx0dHJhbnNmb3JtOiByb3RhdGUoNTQwZGVnKTtcblx0XHR9XG5cdH1cblxuXHRoZWFkZXIge1xuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0XHRkaXNwbGF5OiBibG9jaztcblx0XHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcblx0XHQvL2JhY2tncm91bmQtY29sb3I6IGdyYXk7XG5cblx0XHRoMiB7XG5cdFx0XHRtYXJnaW46IDAgMCAxMHB4O1xuXHRcdFx0cGFkZGluZzogMDtcblx0XHRcdGZvbnQtc2l6ZTogMjhweDtcblx0XHR9XG5cdH1cblxuXHRhcnRpY2xlIHtcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdFx0ZGlzcGxheTogYmxvY2s7XG5cdFx0bWFyZ2luOiAwO1xuXHRcdHBhZGRpbmc6IDA7XG5cdFx0Zm9udC1zaXplOiAxNnB4O1xuXHRcdGxpbmUtaGVpZ2h0OiAxLjc1O1xuXG5cdFx0cCB7XG5cdFx0XHQvL21hcmdpbi1ib3R0b206IDMwcHg7XG5cdFx0fVxuXHR9XG5cblx0Zm9vdGVyIHtcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdFx0ZGlzcGxheTogZmxleDtcblx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xuXHRcdGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG5cdFx0d2lkdGg6IDEwMCU7XG5cdFx0bWFyZ2luOiAwO1xuXHRcdHBhZGRpbmc6IDEwcHggMCAwO1xuXG5cdFx0LmJ1dHRvbiB7XG5cdFx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdFx0XHRwYWRkaW5nOiAxMHB4IDMwcHg7XG5cdFx0XHRib3JkZXItcmFkaXVzOiAzcHg7XG5cdFx0XHRmb250LXNpemU6IDE0cHg7XG5cdFx0XHRmb250LXdlaWdodDogNDAwO1xuXHRcdFx0Y29sb3I6IHdoaXRlO1xuXHRcdFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcblx0XHRcdG92ZXJmbG93OiBoaWRkZW47XG5cblx0XHRcdCY6YmVmb3JlIHtcblx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xuXHRcdFx0XHRjb250ZW50OiAnJztcblx0XHRcdFx0dG9wOiAwO1xuXHRcdFx0XHRsZWZ0OiAwO1xuXHRcdFx0XHR3aWR0aDogMDtcblx0XHRcdFx0aGVpZ2h0OiAxMDAlO1xuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKHdoaXRlLDAuMik7XG5cdFx0XHRcdHRyYW5zaXRpb246IHdpZHRoIDI1MG1zIGVhc2U7XG5cdFx0XHRcdHotaW5kZXg6IDA7XG5cdFx0XHR9XG5cblx0XHRcdCY6aG92ZXIge1xuXG5cdFx0XHRcdCY6YmVmb3JlIHtcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQmLnN1Y2Nlc3Mge1xuXHRcdFx0XHRtYXJnaW4tcmlnaHQ6IDVweDtcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLTM7XG5cdFx0XHR9XG5cblx0XHRcdCYuZGFuZ2VyIHtcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLTQ7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59XG5cbiNtb2RhbCB7XG5cdGRpc3BsYXk6IG5vbmU7XG5cblx0JjpjaGVja2VkIH4gLm1vZGFsLWJnIHtcblx0XHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xuXHRcdGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuXHRcdG9wYWNpdHk6IDAuNztcblx0XHR0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yICRiYXNlLWR1cmF0aW9uLzIgbGluZWFyO1xuXHR9XG5cblx0JjpjaGVja2VkIH4gLm1vZGFsLWNvbnRlbnQge1xuXHRcdHZpc2liaWxpdHk6IHZpc2libGU7XG5cdFx0dHJhbnNmb3JtOiBzY2FsZSgxLjApO1xuXHRcdHRyYW5zaXRpb246IHRyYW5zZm9ybSAkYmFzZS1kdXJhdGlvbi8yIGVhc2U7XG5cdFx0ei1pbmRleDogMTExO1xuXHR9XG59XG5cbmlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjZTkxZTYzO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICNlOTFlNjM7XG5cdG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluc3RydW1lbnRve1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbmlvbi1pdGVtey8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJke1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbiAgaW9uLWl0ZW17XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIH1cbn1cblxuLmNhcmQtZ3JhZGllbnRle1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1idXR0b257XG5cdGNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kOiAjZTkxZTYzO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjZTkxZTYzO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICNlOTFlNjM7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufVxuIiwiKiwgKjpiZWZvcmUsICo6YWZ0ZXIge1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBvdXRsaW5lOiBub25lO1xufVxuXG5ib2R5IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwdmg7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlc21va2U7XG4gIGZvbnQtZmFtaWx5OiBcIlNvdXJjZSBTYW5zIFByb1wiLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtc21vb3RoOiBhdXRvO1xuICBmb250LXdlaWdodDogMzAwO1xuICBsaW5lLWhlaWdodDogMS41O1xuICBjb2xvcjogIzQ0NDtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiaHR0cDovL2Rha290YXJ1bW9ycy5jb20vYXNzZXRzL2ltZy9oZWFkZXItYmcuanBnXCIpO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuYm9keTpiZWZvcmUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjcpO1xuICB6LWluZGV4OiAtMTtcbn1cblxucCB7XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG59XG5cbmEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbmxhYmVsIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4ubW9kYWwtYnRuIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiB0YWJsZS1jZWxsO1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyYzNlNTA7XG4gIGJveC1zaGFkb3c6IDAgMCA0MHB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBmb250LXNpemU6IDM2cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsaW5lLWhlaWdodDogMi43NTtcbiAgdHJhbnNpdGlvbjogYm94LXNoYWRvdyAyNTBtcyBlYXNlO1xufVxuLm1vZGFsLWJ0bjpob3ZlciB7XG4gIGJveC1zaGFkb3c6IDAgMCA1cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xufVxuXG4ubW9kYWwtYmcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb3BhY2l0eTogMDtcbiAgei1pbmRleDogMTA7XG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAyNTBtcyBsaW5lYXI7XG59XG5cbi5tb2RhbC1jb250ZW50IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB3aWR0aDogNTAlO1xuICBoZWlnaHQ6IGF1dG87XG4gIG1hcmdpbi10b3A6IC0xOCU7XG4gIG1hcmdpbi1sZWZ0OiAtMjUlO1xuICBwYWRkaW5nOiAzMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDAgNTBweCByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIHRyYW5zZm9ybTogc2NhbGUoMCk7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBlYXNlO1xuICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gIHotaW5kZXg6IDIwO1xufVxuLm1vZGFsLWNvbnRlbnQgLmNsb3NlIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDUwMG1zIGVhc2U7XG4gIHotaW5kZXg6IDExO1xufVxuLm1vZGFsLWNvbnRlbnQgLmNsb3NlOmhvdmVyIHtcbiAgY29sb3I6ICMzNDk4ZGI7XG4gIHRyYW5zZm9ybTogcm90YXRlKDU0MGRlZyk7XG59XG4ubW9kYWwtY29udGVudCBoZWFkZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcbn1cbi5tb2RhbC1jb250ZW50IGhlYWRlciBoMiB7XG4gIG1hcmdpbjogMCAwIDEwcHg7XG4gIHBhZGRpbmc6IDA7XG4gIGZvbnQtc2l6ZTogMjhweDtcbn1cbi5tb2RhbC1jb250ZW50IGFydGljbGUge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDEuNzU7XG59XG4ubW9kYWwtY29udGVudCBmb290ZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDEwcHggMCAwO1xufVxuLm1vZGFsLWNvbnRlbnQgZm9vdGVyIC5idXR0b24ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHBhZGRpbmc6IDEwcHggMzBweDtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5tb2RhbC1jb250ZW50IGZvb3RlciAuYnV0dG9uOmJlZm9yZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29udGVudDogXCJcIjtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMDtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMik7XG4gIHRyYW5zaXRpb246IHdpZHRoIDI1MG1zIGVhc2U7XG4gIHotaW5kZXg6IDA7XG59XG4ubW9kYWwtY29udGVudCBmb290ZXIgLmJ1dHRvbjpob3ZlcjpiZWZvcmUge1xuICB3aWR0aDogMTAwJTtcbn1cbi5tb2RhbC1jb250ZW50IGZvb3RlciAuYnV0dG9uLnN1Y2Nlc3Mge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJlY2M3MTtcbn1cbi5tb2RhbC1jb250ZW50IGZvb3RlciAuYnV0dG9uLmRhbmdlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlNzRjM2M7XG59XG5cbiNtb2RhbCB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG4jbW9kYWw6Y2hlY2tlZCB+IC5tb2RhbC1iZyB7XG4gIHZpc2liaWxpdHk6IHZpc2libGU7XG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICBvcGFjaXR5OiAwLjc7XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgMjUwbXMgbGluZWFyO1xufVxuI21vZGFsOmNoZWNrZWQgfiAubW9kYWwtY29udGVudCB7XG4gIHZpc2liaWxpdHk6IHZpc2libGU7XG4gIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBlYXNlO1xuICB6LWluZGV4OiAxMTE7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICNlOTFlNjM7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICNlOTFlNjM7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWluc3RydW1lbnRvIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xufVxuLmhlYWRlci1jYXJkIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNhcmQtZ3JhZGllbnRlIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG4uaW9uLWJ1dHRvbiB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kOiAjZTkxZTYzO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjZTkxZTYzO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICNlOTFlNjM7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/evaluaciones/instrumento/instrumento.page.ts":
/*!**************************************************************!*\
  !*** ./src/app/evaluaciones/instrumento/instrumento.page.ts ***!
  \**************************************************************/
/*! exports provided: InstrumentoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InstrumentoPage", function() { return InstrumentoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _respuesta_respuesta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./respuesta/respuesta.page */ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.ts");




var InstrumentoPage = /** @class */ (function () {
    function InstrumentoPage(popoverController, alertController, navParams, modalCtrl) {
        this.popoverController = popoverController;
        this.alertController = alertController;
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.indicadores = [];
        this.noOcultar = true;
        console.log(navParams.get('evaluacion'));
        this.instrumento = navParams.get('evaluacion');
        this.indicadores = this.instrumento.indicadores;
        this.noOcultar = (navParams.get('noOcultar') || true);
        console.log(this.noOcultar);
    }
    InstrumentoPage.prototype.ngOnInit = function () {
    };
    InstrumentoPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    InstrumentoPage.prototype.responderConAlerta = function (indicador) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Evaluar indicador!',
                            subHeader: indicador.titulo,
                            message: indicador.descripcion,
                            inputs: [
                                {
                                    name: 'name1',
                                    type: 'text',
                                    placeholder: 'Placeholder 1'
                                }
                            ],
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        console.log('Confirm Cancel');
                                    }
                                }, {
                                    text: 'Ok',
                                    handler: function () {
                                        console.log('Confirm Ok');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    InstrumentoPage.prototype.guardarEvaluacion = function () {
        this.modalCtrl.dismiss({ indicadores: this.indicadores, usuario: this.navParams.get('usuario') });
    };
    InstrumentoPage.prototype.sinResponder = function (indicadores) {
        for (var i = 0; i < indicadores.length; i++) {
            if (!indicadores[i].valor) {
                return true;
            }
        }
        return false;
    };
    InstrumentoPage.prototype.responder = function (indicador) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(indicador);
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _respuesta_respuesta_page__WEBPACK_IMPORTED_MODULE_3__["RespuestaPage"],
                                cssClass: 'modals',
                                componentProps: { titulo: indicador.titulo, obs: indicador.obs, descripcion: indicador.descripcion, tipo: indicador.tipo, valor: indicador.valor, min: indicador.min, max: indicador.max, noOcultar: this.noOcultar },
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (datos) {
                            if (datos.data) {
                                indicador.valor = datos.data.valor;
                                indicador.obs = datos.data.obs;
                                console.log(indicador);
                                console.log(datos);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    InstrumentoPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    InstrumentoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-instrumento',
            template: __webpack_require__(/*! raw-loader!./instrumento.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/instrumento/instrumento.page.html"),
            styles: [__webpack_require__(/*! ./instrumento.page.scss */ "./src/app/evaluaciones/instrumento/instrumento.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], InstrumentoPage);
    return InstrumentoPage;
}());



/***/ }),

/***/ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.scss":
/*!************************************************************************!*\
  !*** ./src/app/evaluaciones/instrumento/respuesta/respuesta.page.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #03a9f4;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #03a9f4;\n  margin-bottom: 5%;\n}\n\n.imagen-respuesta {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\n.ion-button {\n  --background: #03a9f4 !important;\n  --background-activated: #03a9f4 !important;\n  --background-hover: #03a9f4 !important;\n  width: 70% !important;\n  margin-left: 15% !important;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbmVzL2luc3RydW1lbnRvL3Jlc3B1ZXN0YS9yZXNwdWVzdGEucGFnZS5zY3NzIiwic3JjL2FwcC9ldmFsdWFjaW9uZXMvaW5zdHJ1bWVudG8vcmVzcHVlc3RhL3Jlc3B1ZXN0YS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRTs7O0dBQUE7RUFLQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQ0UsbUJBQUE7RUFDRCxpQkFBQTtBQ0FEOztBREdBO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FDQUY7O0FER0E7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNLRjs7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxvRkFBQTtBQ0NGOztBREFFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNFRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUJBQUE7QUNDRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGdDQUFBO0VBQ0EsMENBQUE7RUFDQSxzQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSxZQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9ldmFsdWFjaW9uZXMvaW5zdHJ1bWVudG8vcmVzcHVlc3RhL3Jlc3B1ZXN0YS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogIzAzYTlmNDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgYmFja2dyb3VuZDogIzAzYTlmNDtcblx0bWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tcmVzcHVlc3Rhe1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbmlvbi1pdGVtey8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJke1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbiAgaW9uLWl0ZW17XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIH1cbn1cblxuLmNhcmQtZ3JhZGllbnRle1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogICMwM2E5ZjQgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogICMwM2E5ZjQgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAgIzAzYTlmNCAhaW1wb3J0YW50O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufVxuIiwiaW9uLXRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogIzAzYTlmNDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogIzAzYTlmNDtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tcmVzcHVlc3RhIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xufVxuLmhlYWRlci1jYXJkIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNhcmQtZ3JhZGllbnRlIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG4uaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzAzYTlmNCAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMDNhOWY0ICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzAzYTlmNCAhaW1wb3J0YW50O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.ts":
/*!**********************************************************************!*\
  !*** ./src/app/evaluaciones/instrumento/respuesta/respuesta.page.ts ***!
  \**********************************************************************/
/*! exports provided: RespuestaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RespuestaPage", function() { return RespuestaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var RespuestaPage = /** @class */ (function () {
    function RespuestaPage(modalCtrl, navParams) {
        this.modalCtrl = modalCtrl;
        this.navParams = navParams;
        this.noOcultar = false;
        this.titulo = navParams.get('titulo');
        this.tipo = navParams.get('tipo');
        if (navParams.get('descripcion')) {
            this.descripcion = navParams.get('descripcion');
        }
        if (navParams.get('descripcion')) {
            this.valor = navParams.get('descripcion');
        }
        if (navParams.get('obs')) {
            this.obs = navParams.get('obs');
        }
        if (navParams.get('min')) {
            this.min = navParams.get('min');
        }
        if (navParams.get('max')) {
            this.max = navParams.get('max');
        }
        if (navParams.get('noOcultar')) {
            this.noOcultar = navParams.get('noOcultar');
        }
    }
    RespuestaPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    RespuestaPage.prototype.guardar = function () {
        this.modalCtrl.dismiss({ valor: this.valor, obs: this.obs });
    };
    RespuestaPage.prototype.ngOnInit = function () {
    };
    RespuestaPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] }
    ]; };
    RespuestaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-respuesta',
            template: __webpack_require__(/*! raw-loader!./respuesta.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/instrumento/respuesta/respuesta.page.html"),
            styles: [__webpack_require__(/*! ./respuesta.page.scss */ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
    ], RespuestaPage);
    return RespuestaPage;
}());



/***/ }),

/***/ "./src/app/list/grafico/grafico.page.scss":
/*!************************************************!*\
  !*** ./src/app/list/grafico/grafico.page.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".modal-wrapper.sc-ion-modal-md {\n  width: 7500px !important;\n}\n\nion-content {\n  --background: #f5f5f5;\n}\n\n.background-degradadohome {\n  --background: linear-gradient(to right,#2e86c5, #9b5eb7);\n}\n\n.background-degradadohome2 {\n  --background: linear-gradient(to right, #f36523, #feea00);\n}\n\n.background-degradadohome3 {\n  --background: linear-gradient(#ffa16b, #ff538b ,#6a329d);\n}\n\n.background-degradadohome4 {\n  --background: linear-gradient(#f83e9f, #b340a5, #6542aa);\n}\n\n.item-trn {\n  --color:#f5f5f5;\n}\n\n.item-no-background {\n  background-color: transparent !important;\n  background: transparent !important;\n  --background: #0000;\n  --border-color: #0000;\n}\n\n.icono-grande {\n  max-width: 35px;\n  max-height: 35px;\n  min-width: 35px;\n  min-height: 35px;\n}\n\n.item-fondo {\n  /** background **/\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n  --background:#f5f5f5\n     /** objetos del item **/\n  /** color del item (dentro objetos,letras) **/ ;\n}\n\n.margin-card {\n  margin-top: 4%;\n}\n\n.iconopx {\n  min-width: 30px;\n  min-height: 30px;\n}\n\nion-chip {\n  margin-left: 4%;\n  margin-right: 2%;\n  margin-bottom: 3%;\n  margin-top: 3%;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #1B1F3C;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #1B1F3C;\n}\n\n.imagen-home {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n\n.grilla {\n  background: #1B1F3C;\n  height: 40%;\n  margin-bottom: 13%;\n}\n\n.fila {\n  height: 80%;\n}\n\n.contenedor-azul {\n  background: #1f3e7d;\n}\n\n.card-azul {\n  --background: #1f3e7d;\n  --color: white !important;\n  border-radius: 30px;\n  height: 100%;\n}\n\n.contenedor-naranjo {\n  background: #5785c4;\n}\n\n.card-naranjo {\n  --background: #5785c4;\n  --color: white !important;\n  border-radius: 30px;\n  height: 100%;\n}\n\n.contenedor-celeste {\n  background: #97c2e8;\n}\n\n.card-celeste {\n  --background: #97c2e8;\n  --color: white !important;\n  border-radius: 30px;\n  height: 100%;\n}\n\n.contenedor-card {\n  --background: #3949ab;\n  --color: white !important;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\nion-item ion-label {\n  --background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  font-family: \"Roboto\";\n  text-align: center;\n  font-size: 18px;\n}\n\nion-content {\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n  font-family: \"Roboto\";\n  text-align: center;\n  border-radius: 30px;\n  margin-top: 3%;\n}\n\n.header-card {\n  --background: #3949ab;\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\n.card-grid {\n  background: #00bcd4;\n  color: white;\n  width: 80%;\n  margin-left: 10%;\n}\n\n.boton {\n  width: 50px !important;\n  height: 50px;\n  border-radius: 200px;\n  box-shadow: 0px 0px 8px -2px rgba(0, 0, 0, 0.75);\n}\n\n.container-grid {\n  width: 100% !important;\n  margin-left: 0% !important;\n}\n\n@media (min-width: 900px) {\n  .menu-home {\n    display: none;\n  }\n\n  ion-header {\n    display: none;\n  }\n}\n\n@media (max-width: 900px) {\n  .grilla {\n    background: transparent;\n    height: 100% !important;\n    margin-bottom: 0%;\n  }\n\n  .fila {\n    height: 100% !important;\n  }\n\n  ion-card {\n    --background: white;\n    font-family: \"Roboto\";\n    text-align: center;\n    border-radius: 30px;\n    margin-top: 5%;\n  }\n\n  .card-celeste {\n    margin-bottom: 4%;\n  }\n\n  .card-naranjo {\n    margin-top: 5%;\n  }\n\n  .card-azul {\n    margin-top: 5%;\n    margin-bottom: 5%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvbGlzdC9ncmFmaWNvL2dyYWZpY28ucGFnZS5zY3NzIiwic3JjL2FwcC9saXN0L2dyYWZpY28vZ3JhZmljby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx3QkFBQTtBQ0NGOztBRENBO0VBQ0UscUJBQUE7QUNFRjs7QURDQTtFQUNFLHdEQUFBO0FDRUY7O0FEQ0E7RUFDRSx5REFBQTtBQ0VGOztBRENBO0VBQ0Usd0RBQUE7QUNFRjs7QURDQTtFQUNFLHdEQUFBO0FDRUY7O0FEQ0E7RUFDQyxlQUFBO0FDRUQ7O0FEQ0E7RUFDRSx3Q0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtBQ0VGOztBREVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FERUE7RUFDUSxpQkFBQTtFQUNKLDRCQUFBO0VBQ0EsMEJBQUE7RUFDQTs7aURBQUE7QUNHSjs7QURHQTtFQUNFLGNBQUE7QUNBRjs7QURHQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0FGOztBREdBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDQUY7O0FESUE7RUFDRTs7O0dBQUE7RUFLQSxxQkFBQTtFQUVBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0hGOztBRE1BO0VBQ0UsbUJBQUE7QUNIRjs7QURNQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0hGOztBRE1BO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNIRjs7QURNQTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDSEY7O0FETUE7RUFDRSxXQUFBO0FDSEY7O0FETUE7RUFDRSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ0hGOztBRE1BO0VBQ0UsbUJBQUE7QUNIRjs7QURNQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUNIRjs7QURNQTtFQUNFLG1CQUFBO0FDSEY7O0FETUE7RUFDRSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FDSEY7O0FETUE7RUFDRSxxQkFBQTtFQUNBLHlCQUFBO0FDSEY7O0FET0E7RUFBUzs7O0dBQUE7RUFJUCxxQkFBQTtFQUNBLGtCQUFBO0FDSEY7O0FESUU7RUFDRSxnRkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDRko7O0FETUE7RUFFRTs7OztHQUFBO0FDQUY7O0FET0E7RUFDRSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUNKRjs7QURPQTtFQUNFLHFCQUFBO0FDSkY7O0FES0U7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtBQ0hGOztBRE9BO0VBQ0UsK0ZBQUE7RUFDQSx5QkFBQTtBQ0pGOztBRE9BO0VBQ0UsaUNBQUE7QUNKRjs7QURPQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNKRjs7QURPQTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtBQ0pGOztBRE9BO0VBQ0Usc0JBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7RUFHQSxnREFBQTtBQ0pGOztBRE9BO0VBQ0Usc0JBQUE7RUFDQSwwQkFBQTtBQ0pGOztBRE9BO0VBQ0U7SUFDRSxhQUFBO0VDSkY7O0VET0E7SUFDRSxhQUFBO0VDSkY7QUFDRjs7QURRQTtFQUVFO0lBQ0UsdUJBQUE7SUFDQSx1QkFBQTtJQUNBLGlCQUFBO0VDUEY7O0VEVUE7SUFDRSx1QkFBQTtFQ1BGOztFRFVBO0lBQ0UsbUJBQUE7SUFDQSxxQkFBQTtJQUNBLGtCQUFBO0lBQ0EsbUJBQUE7SUFDQSxjQUFBO0VDUEY7O0VEVUE7SUFDRSxpQkFBQTtFQ1BGOztFRFVBO0lBQ0UsY0FBQTtFQ1BGOztFRFVBO0lBQ0UsY0FBQTtJQUNBLGlCQUFBO0VDUEY7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2xpc3QvZ3JhZmljby9ncmFmaWNvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RhbC13cmFwcGVyLnNjLWlvbi1tb2RhbC1tZCB7XG4gIHdpZHRoOiA3NTAwcHghaW1wb3J0YW50O1xufVxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDogI2Y1ZjVmNTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIzJlODZjNSwgIzliNWViNyk7XG59XG5cbi5iYWNrZ3JvdW5kLWRlZ3JhZGFkb2hvbWUye1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2YzNjUyMywgI2ZlZWEwMCk7XG59XG5cbi5iYWNrZ3JvdW5kLWRlZ3JhZGFkb2hvbWUze1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjZmZhMTZiLCAjZmY1MzhiICwjNmEzMjlkKTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZTR7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCNmODNlOWYsICNiMzQwYTUsICM2NTQyYWEpO1xufVxuXG4uaXRlbS10cm4ge1xuXHQtLWNvbG9yOiNmNWY1ZjU7XG59XG5cbi5pdGVtLW5vLWJhY2tncm91bmR7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogIzAwMDA7XG4gIC0tYm9yZGVyLWNvbG9yOiAjMDAwMDtcblxufVxuXG4uaWNvbm8tZ3JhbmRle1xuICBtYXgtd2lkdGg6ICAzNXB4O1xuICBtYXgtaGVpZ2h0OiAzNXB4O1xuICBtaW4td2lkdGg6ICAzNXB4O1xuICBtaW4taGVpZ2h0OiAzNXB4O1xufVxuXG4uaXRlbS1mb25kb3tcbiAgICAgICAgLyoqIGJhY2tncm91bmQgKiovXG4gICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbiAgICAtLWJhY2tncm91bmQ6I2Y1ZjVmNVxuICAgICAgLyoqIG9iamV0b3MgZGVsIGl0ZW0gKiovXG5cbiAgIC8qKiBjb2xvciBkZWwgaXRlbSAoZGVudHJvIG9iamV0b3MsbGV0cmFzKSAqKi9cbn1cblxuLm1hcmdpbi1jYXJke1xuICBtYXJnaW4tdG9wOiA0JTtcbn1cblxuLmljb25vcHh7XG4gIG1pbi13aWR0aDogMzBweDtcbiAgbWluLWhlaWdodDogMzBweDtcbn1cblxuaW9uLWNoaXB7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbiAgbWFyZ2luLXJpZ2h0OiAyJTtcbiAgbWFyZ2luLWJvdHRvbTogMyU7XG4gIG1hcmdpbi10b3A6IDMlO1xufVxuXG5cbmlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjMUIxRjNDO1xuXG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICMxQjFGM0M7XG59XG5cbi5pbWFnZW4taG9tZXtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWNhcmR7XG4gIHdpZHRoOiA1MHB4O1xuICBtYXJnaW4tbGVmdDogMCU7XG4gIG1hcmdpbi10b3A6IDAlO1xuICBtYXJnaW4tYm90dG9tOiAwJTtcbn1cblxuLmdyaWxsYXtcbiAgYmFja2dyb3VuZDogIzFCMUYzQztcbiAgaGVpZ2h0OiA0MCU7XG4gIG1hcmdpbi1ib3R0b206IDEzJTtcbn1cblxuLmZpbGF7XG4gIGhlaWdodDogODAlO1xufVxuXG4uY29udGVuZWRvci1henVse1xuICBiYWNrZ3JvdW5kOiAjMWYzZTdkO1xufVxuXG4uY2FyZC1henVse1xuICAtLWJhY2tncm91bmQ6ICMxZjNlN2Q7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmNvbnRlbmVkb3ItbmFyYW5qb3tcbiAgYmFja2dyb3VuZDogIzU3ODVjNDtcbn1cblxuLmNhcmQtbmFyYW5qb3tcbiAgLS1iYWNrZ3JvdW5kOiAjNTc4NWM0O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5jb250ZW5lZG9yLWNlbGVzdGV7XG4gIGJhY2tncm91bmQ6ICM5N2MyZTg7XG59XG5cbi5jYXJkLWNlbGVzdGV7XG4gIC0tYmFja2dyb3VuZDogIzk3YzJlODtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY29udGVuZWRvci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaW9uLWxhYmVse1xuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICB9XG59XG5cbmlvbi1jb250ZW50IHtcblxuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBtYXJnaW4tdG9wOiAzJTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWJ7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmNhcmQtZ3JpZHtcbiAgYmFja2dyb3VuZDogIzAwYmNkNDtcbiAgY29sb3I6IHdoaXRlO1xuICB3aWR0aDogODAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xufVxuXG4uYm90b257XG4gIHdpZHRoOiA1MHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNTBweDtcbiAgYm9yZGVyLXJhZGl1czogMjAwcHg7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsMCwwLDAuNzUpO1xuICAtbW96LWJveC1zaGFkb3c6IDBweCAwcHggOHB4IC0ycHggcmdiYSgwLDAsMCwwLjc1KTtcbiAgYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsMCwwLDAuNzUpO1xufVxuXG4uY29udGFpbmVyLWdyaWR7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAwJSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcbiAgLm1lbnUtaG9tZXtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgaW9uLWhlYWRlcntcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG59XG5cblxuQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KXtcblxuICAuZ3JpbGxhe1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1ib3R0b206IDAlO1xuICB9XG5cbiAgLmZpbGF7XG4gICAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICBpb24tY2FyZHtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgfVxuXG4gIC5jYXJkLWNlbGVzdGV7XG4gICAgbWFyZ2luLWJvdHRvbTogNCVcbiAgfVxuXG4gIC5jYXJkLW5hcmFuam97XG4gICAgbWFyZ2luLXRvcDogNSVcbiAgfVxuXG4gIC5jYXJkLWF6dWx7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cblxufVxuIiwiLm1vZGFsLXdyYXBwZXIuc2MtaW9uLW1vZGFsLW1kIHtcbiAgd2lkdGg6IDc1MDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI2Y1ZjVmNTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCMyZTg2YzUsICM5YjVlYjcpO1xufVxuXG4uYmFja2dyb3VuZC1kZWdyYWRhZG9ob21lMiB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZjM2NTIzLCAjZmVlYTAwKTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZTMge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjZmZhMTZiLCAjZmY1MzhiICwjNmEzMjlkKTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZTQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjZjgzZTlmLCAjYjM0MGE1LCAjNjU0MmFhKTtcbn1cblxuLml0ZW0tdHJuIHtcbiAgLS1jb2xvcjojZjVmNWY1O1xufVxuXG4uaXRlbS1uby1iYWNrZ3JvdW5kIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwMDtcbiAgLS1ib3JkZXItY29sb3I6ICMwMDAwO1xufVxuXG4uaWNvbm8tZ3JhbmRlIHtcbiAgbWF4LXdpZHRoOiAzNXB4O1xuICBtYXgtaGVpZ2h0OiAzNXB4O1xuICBtaW4td2lkdGg6IDM1cHg7XG4gIG1pbi1oZWlnaHQ6IDM1cHg7XG59XG5cbi5pdGVtLWZvbmRvIHtcbiAgLyoqIGJhY2tncm91bmQgKiovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xuICAtLWJhY2tncm91bmQ6I2Y1ZjVmNVxuICAgICAvKiogb2JqZXRvcyBkZWwgaXRlbSAqKi9cbiAgLyoqIGNvbG9yIGRlbCBpdGVtIChkZW50cm8gb2JqZXRvcyxsZXRyYXMpICoqLyA7XG59XG5cbi5tYXJnaW4tY2FyZCB7XG4gIG1hcmdpbi10b3A6IDQlO1xufVxuXG4uaWNvbm9weCB7XG4gIG1pbi13aWR0aDogMzBweDtcbiAgbWluLWhlaWdodDogMzBweDtcbn1cblxuaW9uLWNoaXAge1xuICBtYXJnaW4tbGVmdDogNCU7XG4gIG1hcmdpbi1yaWdodDogMiU7XG4gIG1hcmdpbi1ib3R0b206IDMlO1xuICBtYXJnaW4tdG9wOiAzJTtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogIzFCMUYzQztcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogIzFCMUYzQztcbn1cblxuLmltYWdlbi1ob21lIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWNhcmQge1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luLWxlZnQ6IDAlO1xuICBtYXJnaW4tdG9wOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbi5ncmlsbGEge1xuICBiYWNrZ3JvdW5kOiAjMUIxRjNDO1xuICBoZWlnaHQ6IDQwJTtcbiAgbWFyZ2luLWJvdHRvbTogMTMlO1xufVxuXG4uZmlsYSB7XG4gIGhlaWdodDogODAlO1xufVxuXG4uY29udGVuZWRvci1henVsIHtcbiAgYmFja2dyb3VuZDogIzFmM2U3ZDtcbn1cblxuLmNhcmQtYXp1bCB7XG4gIC0tYmFja2dyb3VuZDogIzFmM2U3ZDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY29udGVuZWRvci1uYXJhbmpvIHtcbiAgYmFja2dyb3VuZDogIzU3ODVjNDtcbn1cblxuLmNhcmQtbmFyYW5qbyB7XG4gIC0tYmFja2dyb3VuZDogIzU3ODVjNDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY29udGVuZWRvci1jZWxlc3RlIHtcbiAgYmFja2dyb3VuZDogIzk3YzJlODtcbn1cblxuLmNhcmQtY2VsZXN0ZSB7XG4gIC0tYmFja2dyb3VuZDogIzk3YzJlODtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY29udGVuZWRvci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMzk0OWFiO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLypcbiAgLS1jb2xvcjp3aGl0ZSFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDIsMCwzNiwxKSAwJSwgcmdiYSg5LDY4LDEyMSwwLjU2NDgxNDgxNDgxNDgxNDkpIDAlLCByZ2JhKDM1LDAsMjU1LDAuNjY0MzUxODUxODUxODUxOSkgMTAwJSk7XG4gICovXG59XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgbWFyZ2luLXRvcDogMyU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogIzM5NDlhYjtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDEyOCwyMjIsMjM0LDEpO1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmNhcmQtZ3JpZCB7XG4gIGJhY2tncm91bmQ6ICMwMGJjZDQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgd2lkdGg6IDgwJTtcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcbn1cblxuLmJvdG9uIHtcbiAgd2lkdGg6IDUwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBib3JkZXItcmFkaXVzOiAyMDBweDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwcHggMHB4IDhweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC43NSk7XG4gIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuNzUpO1xuICBib3gtc2hhZG93OiAwcHggMHB4IDhweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC43NSk7XG59XG5cbi5jb250YWluZXItZ3JpZCB7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAwJSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcbiAgLm1lbnUtaG9tZSB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuXG4gIGlvbi1oZWFkZXIge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbn1cbkBtZWRpYSAobWF4LXdpZHRoOiA5MDBweCkge1xuICAuZ3JpbGxhIHtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tYm90dG9tOiAwJTtcbiAgfVxuXG4gIC5maWxhIHtcbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIGlvbi1jYXJkIHtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICB9XG5cbiAgLmNhcmQtY2VsZXN0ZSB7XG4gICAgbWFyZ2luLWJvdHRvbTogNCU7XG4gIH1cblxuICAuY2FyZC1uYXJhbmpvIHtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgfVxuXG4gIC5jYXJkLWF6dWwge1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/list/grafico/grafico.page.ts":
/*!**********************************************!*\
  !*** ./src/app/list/grafico/grafico.page.ts ***!
  \**********************************************/
/*! exports provided: GraficoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GraficoPage", function() { return GraficoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/dist/Chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_5__);






var GraficoPage = /** @class */ (function () {
    function GraficoPage(userService, navParams) {
        this.userService = userService;
        this.navParams = navParams;
        this.evaluacion = undefined;
        this.indicadores = [];
        this.titulo = "";
        this.tipo = undefined;
        this.tipos = ["bar", "horizontalBar", "line", "radar", "polarArea", "pie", "doughnut", "bubble"];
        this.tipoActual = "horizontalBar";
        this.titulos = [];
        this.valores = [];
        this.colores = [];
        this.fondos = [];
        var usuario = JSON.parse(sessionStorage.getItem('usuario'));
        var instrumento = navParams.get('instrumento');
        if (usuario.permissionLevel > 4) {
            this.traerTodos(instrumento);
        }
        else {
            this.traerDatos();
        }
    }
    GraficoPage.prototype.random_rgba = function () {
        var o = Math.round, r = Math.random, s = 200;
        var rgb = 'rgba(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ',' + (r().toFixed(1) + 1) + ')';
        return rgb;
    };
    GraficoPage.prototype.ngOnInit = function () {
    };
    GraficoPage.prototype.calcular = function (instrumento) {
    };
    GraficoPage.prototype.traerTodos = function (instrumento) {
        var _this = this;
        this.userService.listar().subscribe(function (datos) {
            var usuarios = datos;
            var objetos = [];
            var labels = [];
            for (var i = 0; i < usuarios.length; i++) {
                var tipo = _this.navParams.get("tipo").toLowerCase();
                var obj = usuarios[i][tipo];
                if (tipo == "encuestas" && obj) {
                    for (var _i = 0, obj_1 = obj; _i < obj_1.length; _i++) {
                        var o = obj_1[_i];
                        if (o.id == instrumento.id) {
                            objetos.push(o);
                        }
                    }
                }
                if (tipo == "evaluaciones" && obj) {
                    for (var _a = 0, obj_2 = obj; _a < obj_2.length; _a++) {
                        var o = obj_2[_a];
                        if (o.estado == 1) {
                            if (o.sigla == instrumento.sigla) {
                                objetos.push(o);
                            }
                        }
                    }
                }
            }
            var valores = [];
            var cantidadReal = 0;
            for (var i = 0; i < objetos.length; i++) {
                labels = [];
                var preguntas = objetos[i].preguntas;
                for (var _b = 0, preguntas_1 = preguntas; _b < preguntas_1.length; _b++) {
                    var p = preguntas_1[_b];
                    labels.push(p.titulo);
                }
                var resultados = objetos[i].resultados;
                if (resultados) {
                    cantidadReal++;
                    for (var j = 0; j < resultados.length; j++) {
                        if (!valores[j]) {
                            valores[j] = 0;
                        }
                        valores[j] += resultados[j];
                    }
                }
            }
            _this.titulos = labels;
            for (var _c = 0, valores_1 = valores; _c < valores_1.length; _c++) {
                var valor = valores_1[_c];
                _this.valores.push((valor / cantidadReal));
                _this.colores.push(_this.random_rgba());
                _this.fondos.push(_this.random_rgba());
            }
            console.log(objetos);
            _this.ngAfterViewInit();
        });
    };
    GraficoPage.prototype.traerDatos = function () {
        this.evaluacion = this.navParams.get('instrumento');
        if (this.evaluacion.instrumento) {
            this.titulo = this.evaluacion.instrumento.nombre;
            if (this.evaluacion.instrumento.indicadores) {
                this.indicadores = this.evaluacion.instrumento.indicadores;
                for (var i = 0; i < this.indicadores.length; i++) {
                    var indicador = this.indicadores[i];
                    this.titulos.push(indicador.titulo);
                    this.valores.push(indicador.valor);
                    this.colores.push(this.random_rgba());
                    this.fondos.push(this.random_rgba());
                }
            }
        }
        if (this.evaluacion.preguntas) {
            this.titulo = this.evaluacion.titulo;
            for (var i = 0; i < this.evaluacion.preguntas.length; i++) {
                var pregunta = this.evaluacion.preguntas[i];
                this.titulos.push(pregunta.titulo);
                this.valores.push(this.evaluacion.resultados[i]);
                this.colores.push(this.random_rgba());
                this.fondos.push(this.random_rgba());
            }
        }
    };
    GraficoPage.prototype.ngAfterViewInit = function () {
        console.log(this.fondos);
        console.log(this.colores);
        console.log(this.titulos);
        console.log(this.valores);
        if (this.chart) {
            this.chart.destroy();
        }
        this.chart = new chart_js__WEBPACK_IMPORTED_MODULE_4__["Chart"](this.grafico.nativeElement, {
            type: this.tipoActual,
            data: {
                labels: this.titulos,
                datasets: [
                    {
                        label: this.titulo,
                        data: this.valores,
                        backgroundColor: this.colores,
                        borderColor: this.fondos,
                    }
                ]
            },
            options: {
                scales: {
                    yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                }
            }
        });
    };
    GraficoPage.prototype.exportar = function (id) {
        var canvas = document.querySelector('#' + id);
        ;
        //creates image
        console.log(canvas);
        var canvasImg = canvas.toDataURL("image/png", 1.0);
        //creates PDF from img
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_5__('landscape');
        doc.addImage(canvasImg, 'PNG', 10, 10, 280, 150);
        //    doc.save('canvas.pdf');
        var pdfSalida = doc.output();
        var buffer = new ArrayBuffer(pdfSalida.length);
        var array = new Uint8Array(buffer);
        for (var i = 0; i < pdfSalida.length; i++) {
            array[i] = pdfSalida.charCodeAt(i);
        }
        var archivo = new Blob([array], { type: 'application/pdf' });
        var urlArchivo = URL.createObjectURL(archivo);
        window.open(urlArchivo);
    };
    GraficoPage.ctorParameters = function () { return [
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("graficoCanvas", { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], GraficoPage.prototype, "grafico", void 0);
    GraficoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-grafico',
            template: __webpack_require__(/*! raw-loader!./grafico.page.html */ "./node_modules/raw-loader/index.js!./src/app/list/grafico/grafico.page.html"),
            styles: [__webpack_require__(/*! ./grafico.page.scss */ "./src/app/list/grafico/grafico.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
    ], GraficoPage);
    return GraficoPage;
}());



/***/ }),

/***/ "./src/app/list/list.page.scss":
/*!*************************************!*\
  !*** ./src/app/list/list.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".modals {\n  --width: 7500px!important;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n  --color: white !important;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  width: 60% !important;\n  margin-left: 20% !important;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #7A9FCC;\n  --color: white !important;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  width: 60% !important;\n  margin-left: 20% !important;\n}\n\nion-icon {\n  font-size: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvbGlzdC9saXN0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvbGlzdC9saXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FDQ0Y7O0FEQ0E7RUFDRTs7O0dBQUE7RUFLQSxvRkFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDRUY7O0FEQ0E7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNNRjs7QURDQTtFQUNFLG1CQUFBO0FDRUY7O0FEQ0E7RUFDRSxvRkFBQTtBQ0VGOztBRERFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNHRjs7QURDQTtFQUNFLCtGQUFBO0VBQ0EseUJBQUE7QUNFRjs7QURDQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNFRjs7QURDQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNFRjs7QURBQTtFQUNFOzs7R0FBQTtFQUtBLHFCQUFBO0VBQ0EseUJBQUE7QUNFRjs7QURDQTtFQUFTOzs7R0FBQTtFQUlQLDRCQUFBO0VBQ0EsMEJBQUE7QUNHRjs7QURBQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQ09GOztBREFBO0VBQ0UsbUJBQUE7QUNHRjs7QURBQTtFQUNFLG9GQUFBO0FDR0Y7O0FERkU7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtBQ0lGOztBREFBO0VBQ0UsK0ZBQUE7RUFDQSx5QkFBQTtBQ0dGOztBREFBO0VBQ0UsK0ZBQUE7RUFDQSx5R0FBQTtFQUNBLHFHQUFBO0VBQ0EsY0FBQTtBQ0dGOztBREFBO0VBQ0UsK0ZBQUE7RUFDQSx5R0FBQTtFQUNBLHFHQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtBQ0dGOztBRERBO0VBQ0UsZUFBQTtBQ0lGIiwiZmlsZSI6InNyYy9hcHAvbGlzdC9saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RhbHN7XG4gIC0td2lkdGg6IDc1MDBweCFpbXBvcnRhbnQ7XG59XG5pb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG59XG5pb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogIzdBOUZDQztcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG59XG5pb24taWNvbntcbiAgZm9udC1zaXplOiAzMHB4O1xufVxuIiwiLm1vZGFscyB7XG4gIC0td2lkdGg6IDc1MDBweCFpbXBvcnRhbnQ7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAzMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/list/list.page.ts":
/*!***********************************!*\
  !*** ./src/app/list/list.page.ts ***!
  \***********************************/
/*! exports provided: ListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListPage", function() { return ListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _grafico_grafico_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./grafico/grafico.page */ "./src/app/list/grafico/grafico.page.ts");
/* harmony import */ var _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../_servicios/encuestas.service */ "./src/app/_servicios/encuestas.service.ts");
/* harmony import */ var _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../_servicios/evaluaciones.service */ "./src/app/_servicios/evaluaciones.service.ts");







var ListPage = /** @class */ (function () {
    function ListPage(evaluacionesService, encuestaService, modalCtrl, userService, navParams) {
        this.evaluacionesService = evaluacionesService;
        this.encuestaService = encuestaService;
        this.modalCtrl = modalCtrl;
        this.userService = userService;
        this.navParams = navParams;
        this.tipo = "";
        this.datos = [];
        this.usuario = { permissionLevel: 2 };
        this.items = [];
        this.usuario = JSON.parse(sessionStorage.getItem('usuario'));
        this.tipo = this.navParams.get("tipo");
        if (this.usuario.permissionLevel > 4) {
            this.traerTodos();
        }
        else {
            this.traerDatos();
        }
    }
    ListPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    ListPage.prototype.traerTodos = function () {
        var _this = this;
        if (this.tipo == "Encuestas") {
            this.encuestaService.listar().subscribe(function (datos) {
                _this.datos = datos;
            });
        }
        else {
            this.evaluacionesService.listar().subscribe(function (datos) {
                console.log(datos);
                _this.datos = datos;
            });
        }
    };
    ListPage.prototype.traerDatos = function () {
        var _this = this;
        var userId = sessionStorage.getItem('userId');
        this.userService.gathering(userId).subscribe(function (datos) {
            console.log(_this.tipo.toLowerCase());
            _this.datos = datos[_this.tipo.toLowerCase()];
            console.log(_this.datos);
        });
    };
    ListPage.prototype.ngOnInit = function () {
    };
    ListPage.prototype.verGrafico = function (evaluacion, estado) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (estado == 0) {
                            return [2 /*return*/];
                        }
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _grafico_grafico_page__WEBPACK_IMPORTED_MODULE_4__["GraficoPage"],
                                cssClass: 'graficos',
                                componentProps: {
                                    'instrumento': evaluacion,
                                    'tipo': this.tipo,
                                    'noOcultar': false
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    ListPage.ctorParameters = function () { return [
        { type: _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_6__["EvaluacionesService"] },
        { type: _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_5__["EncuestaService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"] }
    ]; };
    ListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-list',
            template: __webpack_require__(/*! raw-loader!./list.page.html */ "./node_modules/raw-loader/index.js!./src/app/list/list.page.html"),
            styles: [__webpack_require__(/*! ./list.page.scss */ "./src/app/list/list.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_6__["EvaluacionesService"],
            _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_5__["EncuestaService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"]])
    ], ListPage);
    return ListPage;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/cristopherorellana/Desktop/corellana/estilosos/src/main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es5.js.map