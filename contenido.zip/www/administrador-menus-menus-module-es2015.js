(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["administrador-menus-menus-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/menus/menus.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/menus/menus.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"administrador\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Menu</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-menus\" src=\"https://image.flaticon.com/icons/png/512/295/295600.png\">\n  </div>\n  <ion-item *ngFor=\"let menu of menus\">\n    <ion-label>\n      {{menu.title}}\n    </ion-label>\n  </ion-item>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/administrador/menus/menus-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/administrador/menus/menus-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: MenusPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenusPageRoutingModule", function() { return MenusPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _menus_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menus.page */ "./src/app/administrador/menus/menus.page.ts");




const routes = [
    {
        path: '',
        component: _menus_page__WEBPACK_IMPORTED_MODULE_3__["MenusPage"]
    }
];
let MenusPageRoutingModule = class MenusPageRoutingModule {
};
MenusPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MenusPageRoutingModule);



/***/ }),

/***/ "./src/app/administrador/menus/menus.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/administrador/menus/menus.module.ts ***!
  \*****************************************************/
/*! exports provided: MenusPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenusPageModule", function() { return MenusPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _menus_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./menus-routing.module */ "./src/app/administrador/menus/menus-routing.module.ts");
/* harmony import */ var _menus_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./menus.page */ "./src/app/administrador/menus/menus.page.ts");







let MenusPageModule = class MenusPageModule {
};
MenusPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _menus_routing_module__WEBPACK_IMPORTED_MODULE_5__["MenusPageRoutingModule"]
        ],
        declarations: [_menus_page__WEBPACK_IMPORTED_MODULE_6__["MenusPage"]]
    })
], MenusPageModule);



/***/ }),

/***/ "./src/app/administrador/menus/menus.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/administrador/menus/menus.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #ffd600;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #ffd600;\n  margin-bottom: 5%;\n}\n\n.imagen-menus {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYWRtaW5pc3RyYWRvci9tZW51cy9tZW51cy5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkbWluaXN0cmFkb3IvbWVudXMvbWVudXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNBRjs7QURHQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNBRDs7QURHQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7RUFDQTs7OztHQUFBO0FDS0Y7O0FERUE7RUFDRSxtQkFBQTtBQ0NGOztBREVBO0VBQ0Usb0ZBQUE7QUNDRjs7QURBRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDRUY7O0FERUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxpQ0FBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvYWRtaW5pc3RyYWRvci9tZW51cy9tZW51cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogI2ZmZDYwMDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgYmFja2dyb3VuZDogI2ZmZDYwMDtcblx0bWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tbWVudXN7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFie1xuICAtLWJhY2tncm91bmQ6IHJnYmEoMTI4LDIyMiwyMzQsMSk7XG59XG4iLCJpb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjZmZkNjAwO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICBiYWNrZ3JvdW5kOiAjZmZkNjAwO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1tZW51cyB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDEyOCwyMjIsMjM0LDEpO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/administrador/menus/menus.page.ts":
/*!***************************************************!*\
  !*** ./src/app/administrador/menus/menus.page.ts ***!
  \***************************************************/
/*! exports provided: MenusPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenusPage", function() { return MenusPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _servicios_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../_servicios/menu.service */ "./src/app/_servicios/menu.service.ts");



let MenusPage = class MenusPage {
    constructor(menusService) {
        this.menusService = menusService;
        this.menus = [];
    }
    ngOnInit() {
        this.menusService.listar().subscribe(data => {
            console.log(data);
            this.menus = data;
        });
    }
};
MenusPage.ctorParameters = () => [
    { type: _servicios_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenusService"] }
];
MenusPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-menus',
        template: __webpack_require__(/*! raw-loader!./menus.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/menus/menus.page.html"),
        styles: [__webpack_require__(/*! ./menus.page.scss */ "./src/app/administrador/menus/menus.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_servicios_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenusService"]])
], MenusPage);



/***/ })

}]);
//# sourceMappingURL=administrador-menus-menus-module-es2015.js.map