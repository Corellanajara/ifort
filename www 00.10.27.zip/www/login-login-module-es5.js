(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html":
/*!*****************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"ion-padding\">\n  <div class=\"contenedor-inputs\">\n    <div class=\"contenedor-imagen\">\n      <img class=\"logo-ifort\" src=\"/assets/icon/LOGO IFORT-01.png\">\n    </div>\n\n    <form class=\"login-form\" #form=\"ngForm\" (ngSubmit)=\"login(form)\" autocomplete=\"off\">\n      <p class=\"login-text\">\n      </p>\n        <ion-item class=\"redondeado\">\n          <ion-label></ion-label>\n          <ion-input type=\"email\" ngModel name=\"email\" autofocus=\"true\" required=\"true\" placeholder=\"Email\" autocomplete=\"off\"></ion-input>\n        </ion-item>\n\n        <ion-item class=\"redondeado\">\n          <ion-label></ion-label>\n          <ion-input type=\"password\" ngModel name=\"password\" required=\"true\" placeholder=\"Clave\" autocomplete=\"off\" ></ion-input>\n        </ion-item>\n\n        <ion-button class=\"boton-login\" expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\"  name=\"Login\" value=\"Iniciar Sesión\">Iniciar Sesión</ion-button>\n\n    </form>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/login/login-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");




var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
var LoginPageRoutingModule = /** @class */ (function () {
    function LoginPageRoutingModule() {
    }
    LoginPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], LoginPageRoutingModule);
    return LoginPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "./src/app/login/login-routing.module.ts");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");






//import { AuthService } from '../_servicios/auth';

var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]],
            providers: []
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@import url(https://fonts.googleapis.com/css?family=Open+Sans:100,300,400,700);\n@import url(//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css);\n.imagen-home {\n  width: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\nbody, html {\n  height: 100%;\n}\nbody {\n  font-family: \"Open Sans\";\n  font-weight: 100;\n  display: -webkit-box;\n  display: flex;\n  overflow: hidden;\n}\n.login-form {\n  min-height: 10rem;\n  margin: auto;\n  max-width: 60%;\n  padding: 0.5rem;\n}\n.login-text {\n  color: white;\n  font-size: 2.5rem;\n  margin: 0 auto;\n  max-width: 50%;\n  padding: 0.5rem;\n  text-align: center;\n}\n.login-text .fa-stack-1x {\n  color: black;\n}\nion-content {\n  --background: #4dd0e1;\n}\n.imagen-candado {\n  width: 40% !important;\n  margin-left: 30% !important;\n}\n.contenedor-imagen {\n  width: 100%;\n}\n.contenedor-imagen .logo-ifort {\n  width: 30%;\n  margin-left: 35%;\n  padding: 0%;\n}\n.contenedor-texto {\n  width: 100%;\n}\n.no-recordar {\n  color: white;\n  text-align: center !important;\n}\nion-content {\n  --background: linear-gradient(180deg, rgba(19,15,94,0.9009978991596639) 7%, rgba(9,9,121,1) 14%, rgba(9,14,125,0.9009978991596639) 30%, rgba(7,62,156,0.9402135854341737) 53%, rgba(0,212,255,0.6404936974789917) 92%);\n}\n.redondeado {\n  border-radius: 25px;\n}\n.imagen-candado {\n  width: 40% !important;\n  margin-left: 30% !important;\n}\n.contenedor-inputs {\n  width: 60% !important;\n  margin-left: 20% !important;\n  border-radius: 25px;\n}\n.contenedor-inputs ion-item {\n  margin-top: 3% !important;\n  --background: white;\n  --background-hover:white;\n  --background-activated: white;\n  --background-focused: white;\n  /** objetos del item **/\n  /** color del item (dentro objetos,letras) **/\n  --color:black;\n  --color-activated:black;\n  /** color de lo de dentro cuando se le apreta tab encima **/\n  --color-focused:black;\n  /** color de lo de dentro cuando se le pasa el mouse encima **/\n  --color-hover:white;\n  --border-color: transparent;\n  margin-bottom: 5vh !important;\n}\n.contenedor-inputs ion-item input {\n  border: white !important;\n}\n.contenedor-inputs .boton-login {\n  --color: white !important;\n  margin-bottom: 6%;\n}\n@media (max-width: 1000px) {\n  .contenedor-imagen {\n    width: 100%;\n  }\n  .contenedor-imagen .logo-ifort {\n    width: 70%;\n    margin-left: 15%;\n    padding: 0%;\n  }\n\n  .formulario2 {\n    width: 100%;\n    margin-top: 0%;\n    background: white;\n    padding-bottom: 0%;\n  }\n\n  .contenedor-inputs {\n    width: 100% !important;\n    margin-left: 0% !important;\n    border-radius: 25px;\n  }\n  .contenedor-inputs ion-item {\n    margin-top: 3% !important;\n    --background: white;\n    --background-hover:white;\n    --background-activated: white;\n    --background-focused: white;\n    /** objetos del item **/\n    /** color del item (dentro objetos,letras) **/\n    --color:black;\n    --color-activated:black;\n    /** color de lo de dentro cuando se le apreta tab encima **/\n    --color-focused:black;\n    /** color de lo de dentro cuando se le pasa el mouse encima **/\n    --color-hover:black;\n    --border-color: transparent;\n    margin-bottom: 5vh !important;\n  }\n  .contenedor-inputs ion-item input {\n    border: white !important;\n  }\n  .contenedor-inputs .boton-login {\n    --color: white !important;\n    margin-bottom: 6%;\n  }\n\n  .content-tercero {\n    --background: white !important;\n  }\n\n  ion-item {\n    margin-top: 3% !important;\n    --background: #f5f5f5;\n    --background-hover: #f5f5f5;\n    --background-activated: #f5f5f5;\n    --background-focused: #f5f5f5;\n    /** objetos del item **/\n    /** color del item (dentro objetos,letras) **/\n    --color: black;\n    --color-activated: black;\n    /** color de lo de dentro cuando se le apreta tab encima **/\n    --color-focused: black;\n    /** color de lo de dentro cuando se le pasa el mouse encima **/\n    --color-hover: black;\n    --border-color: transparent;\n    margin-bottom: 5vh !important;\n  }\n  ion-item input {\n    border: white !important;\n  }\n\n  .boton-login {\n    --color: white !important;\n  }\n\n  ion-title {\n    text-align: center;\n    font-size: 30px;\n    font-family: serif, bold;\n    margin-top: 5%;\n    margin-bottom: 5%;\n    padding-bottom: 10vh;\n    background: #5db596;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic3JjL2FwcC9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEsOEVBQUE7QUFDQSw4RUFBQTtBQUVSO0VBQ0UsVUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGO0FER0E7RUFDRSxZQUFBO0FDQUY7QURHQTtFQUNFLHdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSxnQkFBQTtBQ0FGO0FER0E7RUFHRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0ZGO0FES0E7RUFHRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0pGO0FETUU7RUFDRSxZQUFBO0FDSko7QURRQTtFQUNFLHFCQUFBO0FDTEY7QURRQTtFQUNFLHFCQUFBO0VBQ0EsMkJBQUE7QUNMRjtBRFFBO0VBQ0UsV0FBQTtBQ0xGO0FET0U7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FDTEo7QURTQTtFQUNFLFdBQUE7QUNORjtBRFNBO0VBQ0UsWUFBQTtFQUNBLDZCQUFBO0FDTkY7QURTQTtFQUVFLHNOQUFBO0FDUEY7QURTQTtFQUNFLG1CQUFBO0FDTkY7QURRQTtFQUNFLHFCQUFBO0VBQ0EsMkJBQUE7QUNMRjtBRFFBO0VBQ0UscUJBQUE7RUFDQSwyQkFBQTtFQUNBLG1CQUFBO0FDTEY7QURNRTtFQUVFLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx3QkFBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7RUFDRSx1QkFBQTtFQUNBLDZDQUFBO0VBQ0gsYUFBQTtFQUVBLHVCQUFBO0VBQ0csMkRBQUE7RUFDSCxxQkFBQTtFQUNHLDhEQUFBO0VBQ0gsbUJBQUE7RUFFQSwyQkFBQTtFQUlDLDZCQUFBO0FDVko7QURPSTtFQUNFLHdCQUFBO0FDTE47QURVRTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7QUNSSjtBRFlFO0VBRUU7SUFDRSxXQUFBO0VDVko7RURZSTtJQUNFLFVBQUE7SUFDQSxnQkFBQTtJQUNBLFdBQUE7RUNWTjs7RURjRTtJQUNFLFdBQUE7SUFDQSxjQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtFQ1hKOztFRGNFO0lBQ0Usc0JBQUE7SUFDQSwwQkFBQTtJQUNBLG1CQUFBO0VDWEo7RURhSTtJQUVFLHlCQUFBO0lBQ0EsbUJBQUE7SUFDQSx3QkFBQTtJQUNBLDZCQUFBO0lBQ0EsMkJBQUE7SUFDRSx1QkFBQTtJQUNBLDZDQUFBO0lBQ0gsYUFBQTtJQUVBLHVCQUFBO0lBQ0csMkRBQUE7SUFDSCxxQkFBQTtJQUNHLDhEQUFBO0lBQ0gsbUJBQUE7SUFFQSwyQkFBQTtJQUlDLDZCQUFBO0VDakJOO0VEY007SUFDRSx3QkFBQTtFQ1pSO0VEaUJJO0lBQ0UseUJBQUE7SUFDQSxpQkFBQTtFQ2ZOOztFRG1CRTtJQUNFLDhCQUFBO0VDaEJKOztFRG1CSTtJQUVFLHlCQUFBO0lBQ0EscUJBQUE7SUFDQSwyQkFBQTtJQUNBLCtCQUFBO0lBQ0EsNkJBQUE7SUFDRSx1QkFBQTtJQUNBLDZDQUFBO0lBQ0gsY0FBQTtJQUVBLHdCQUFBO0lBQ0csMkRBQUE7SUFDSCxzQkFBQTtJQUNHLDhEQUFBO0lBQ0gsb0JBQUE7SUFFQSwyQkFBQTtJQUtDLDZCQUFBO0VDdkJOO0VEb0JNO0lBQ0Usd0JBQUE7RUNsQlI7O0VEdUJJO0lBQ0UseUJBQUE7RUNwQk47O0VEdUJJO0lBQ0Usa0JBQUE7SUFDQSxlQUFBO0lBQ0Esd0JBQUE7SUFDQSxjQUFBO0lBQ0EsaUJBQUE7SUFDQSxvQkFBQTtJQUNBLG1CQUFBO0VDcEJOO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybChodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zOjEwMCwzMDAsNDAwLDcwMCk7XG5AaW1wb3J0IHVybCgvL25ldGRuYS5ib290c3RyYXBjZG4uY29tL2ZvbnQtYXdlc29tZS80LjAuMy9jc3MvZm9udC1hd2Vzb21lLmNzcyk7XG5cbi5pbWFnZW4taG9tZXtcbiAgd2lkdGg6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG5ib2R5LCBodG1sIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG5ib2R5IHtcbiAgZm9udC1mYW1pbHk6ICdPcGVuIFNhbnMnO1xuICBmb250LXdlaWdodDogMTAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4ubG9naW4tZm9ybSB7XG4gIC8vYmFja2dyb3VuZDogIzIyMjtcbiAgLy9ib3gtc2hhZG93OiAwIDAgMXJlbSByZ2JhKDAsMCwwLDAuMyk7XG4gIG1pbi1oZWlnaHQ6IDEwcmVtO1xuICBtYXJnaW46IGF1dG87XG4gIG1heC13aWR0aDogNjAlO1xuICBwYWRkaW5nOiAuNXJlbTtcbn1cblxuLmxvZ2luLXRleHQge1xuICAvL2JhY2tncm91bmQ6IGhzbCg0MCwzMCw2MCk7XG4gIC8vYm9yZGVyLWJvdHRvbTogLjVyZW0gc29saWQgd2hpdGU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAyLjVyZW07XG4gIG1hcmdpbjogMCBhdXRvO1xuICBtYXgtd2lkdGg6IDUwJTtcbiAgcGFkZGluZzogLjVyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgLy90ZXh0LXNoYWRvdzogMXB4IC0xcHggMCByZ2JhKDAsMCwwLDAuMyk7XG4gIC5mYS1zdGFjay0xeCB7XG4gICAgY29sb3I6IGJsYWNrO1xuICB9XG59XG5cbmlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6ICM0ZGQwZTE7XG59XG5cbi5pbWFnZW4tY2FuZGFkb3tcbiAgd2lkdGg6IDQwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMzAlICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgd2lkdGg6IDEwMCU7XG5cbiAgLmxvZ28taWZvcnR7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBtYXJnaW4tbGVmdDogMzUlO1xuICAgIHBhZGRpbmc6IDAlO1xuICB9XG59XG5cbi5jb250ZW5lZG9yLXRleHRve1xuICB3aWR0aDogMTAwJTtcbn1cblxuLm5vLXJlY29yZGFye1xuICBjb2xvcjogd2hpdGU7XG4gIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xufVxuXG5pb24tY29udGVudHtcbiAgLy8tLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsIHJnYmEoODMsMTg2LDE1NiwxKSAwJSwgcmdiYSgxNzEsMTMzLDExMSwxKSAxMDAlKTtcbiAgLS1iYWNrZ3JvdW5kIDogbGluZWFyLWdyYWRpZW50KDE4MGRlZywgcmdiYSgxOSwxNSw5NCwwLjkwMDk5Nzg5OTE1OTY2MzkpIDclLCByZ2JhKDksOSwxMjEsMSkgMTQlLCByZ2JhKDksMTQsMTI1LDAuOTAwOTk3ODk5MTU5NjYzOSkgMzAlLCByZ2JhKDcsNjIsMTU2LDAuOTQwMjEzNTg1NDM0MTczNykgNTMlLCByZ2JhKDAsMjEyLDI1NSwwLjY0MDQ5MzY5NzQ3ODk5MTcpIDkyJSk7XG59XG4ucmVkb25kZWFkb3tcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbn1cbi5pbWFnZW4tY2FuZGFkb3tcbiAgd2lkdGg6IDQwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMzAlICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW5lZG9yLWlucHV0c3tcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gIGlvbi1pdGVte1xuXG4gICAgbWFyZ2luLXRvcDogMyUgIWltcG9ydGFudDtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAgIC0tYmFja2dyb3VuZC1ob3Zlcjp3aGl0ZTtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB3aGl0ZTtcbiAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogd2hpdGU7XG4gICAgICAvKiogb2JqZXRvcyBkZWwgaXRlbSAqKi9cbiAgICAgIC8qKiBjb2xvciBkZWwgaXRlbSAoZGVudHJvIG9iamV0b3MsbGV0cmFzKSAqKi9cbiAgIC0tY29sb3I6YmxhY2s7XG5cbiAgIC0tY29sb3ItYWN0aXZhdGVkOmJsYWNrO1xuICAgICAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgYXByZXRhIHRhYiBlbmNpbWEgKiovXG4gICAtLWNvbG9yLWZvY3VzZWQ6YmxhY2s7XG4gICAgICAvKiogY29sb3IgZGUgbG8gZGUgZGVudHJvIGN1YW5kbyBzZSBsZSBwYXNhIGVsIG1vdXNlIGVuY2ltYSAqKi9cbiAgIC0tY29sb3ItaG92ZXI6d2hpdGU7XG5cbiAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBpbnB1dHtcbiAgICAgIGJvcmRlcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICB9XG4gICAgbWFyZ2luLWJvdHRvbTogNXZoICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuYm90b24tbG9naW57XG4gICAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tYm90dG9tOiA2JTtcbiAgfVxufVxuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcblxuICAgIC5jb250ZW5lZG9yLWltYWdlbntcbiAgICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgICAubG9nby1pZm9ydHtcbiAgICAgICAgd2lkdGg6IDcwJTtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDE1JTtcbiAgICAgICAgcGFkZGluZzogMCU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLmZvcm11bGFyaW8ye1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBtYXJnaW4tdG9wOiAwJTtcbiAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgICAgcGFkZGluZy1ib3R0b206IDAlO1xuICAgIH1cblxuICAgIC5jb250ZW5lZG9yLWlucHV0c3tcbiAgICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gICAgICBtYXJnaW4tbGVmdDowJSAhaW1wb3J0YW50O1xuICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcblxuICAgICAgaW9uLWl0ZW17XG5cbiAgICAgICAgbWFyZ2luLXRvcDogMyUgIWltcG9ydGFudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWhvdmVyOndoaXRlO1xuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB3aGl0ZTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHdoaXRlO1xuICAgICAgICAgIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuICAgICAgICAgIC8qKiBjb2xvciBkZWwgaXRlbSAoZGVudHJvIG9iamV0b3MsbGV0cmFzKSAqKi9cbiAgICAgICAtLWNvbG9yOmJsYWNrO1xuXG4gICAgICAgLS1jb2xvci1hY3RpdmF0ZWQ6YmxhY2s7XG4gICAgICAgICAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgYXByZXRhIHRhYiBlbmNpbWEgKiovXG4gICAgICAgLS1jb2xvci1mb2N1c2VkOmJsYWNrO1xuICAgICAgICAgIC8qKiBjb2xvciBkZSBsbyBkZSBkZW50cm8gY3VhbmRvIHNlIGxlIHBhc2EgZWwgbW91c2UgZW5jaW1hICoqL1xuICAgICAgIC0tY29sb3ItaG92ZXI6YmxhY2s7XG5cbiAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgIGlucHV0e1xuICAgICAgICAgIGJvcmRlcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgICAgICBtYXJnaW4tYm90dG9tOiA1dmggIWltcG9ydGFudDtcbiAgICAgIH1cblxuICAgICAgLmJvdG9uLWxvZ2lue1xuICAgICAgICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA2JTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAuY29udGVudC10ZXJjZXJve1xuICAgICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgICAgaW9uLWl0ZW17XG5cbiAgICAgICAgbWFyZ2luLXRvcDogMyUgIWltcG9ydGFudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZjVmNWY1O1xuICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6ICNmNWY1ZjU7XG4gICAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICNmNWY1ZjU7XG4gICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiAjZjVmNWY1O1xuICAgICAgICAgIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuICAgICAgICAgIC8qKiBjb2xvciBkZWwgaXRlbSAoZGVudHJvIG9iamV0b3MsbGV0cmFzKSAqKi9cbiAgICAgICAtLWNvbG9yOiBibGFjaztcblxuICAgICAgIC0tY29sb3ItYWN0aXZhdGVkOiBibGFjaztcbiAgICAgICAgICAvKiogY29sb3IgZGUgbG8gZGUgZGVudHJvIGN1YW5kbyBzZSBsZSBhcHJldGEgdGFiIGVuY2ltYSAqKi9cbiAgICAgICAtLWNvbG9yLWZvY3VzZWQ6IGJsYWNrO1xuICAgICAgICAgIC8qKiBjb2xvciBkZSBsbyBkZSBkZW50cm8gY3VhbmRvIHNlIGxlIHBhc2EgZWwgbW91c2UgZW5jaW1hICoqL1xuICAgICAgIC0tY29sb3ItaG92ZXI6IGJsYWNrO1xuXG4gICAgICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuXG4gICAgICAgIGlucHV0e1xuICAgICAgICAgIGJvcmRlcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgICAgICBtYXJnaW4tYm90dG9tOiA1dmggIWltcG9ydGFudDtcbiAgICAgIH1cblxuICAgICAgLmJvdG9uLWxvZ2lue1xuICAgICAgICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgfVxuXG4gICAgICBpb24tdGl0bGV7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICBmb250LWZhbWlseTogc2VyaWYsIGJvbGQ7XG4gICAgICAgIG1hcmdpbi10b3A6IDUlO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA1JTtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDEwdmg7XG4gICAgICAgIGJhY2tncm91bmQ6ICM1ZGI1OTY7XG4gICAgICB9XG4gIH1cbiIsIkBpbXBvcnQgdXJsKGh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1PcGVuK1NhbnM6MTAwLDMwMCw0MDAsNzAwKTtcbkBpbXBvcnQgdXJsKC8vbmV0ZG5hLmJvb3RzdHJhcGNkbi5jb20vZm9udC1hd2Vzb21lLzQuMC4zL2Nzcy9mb250LWF3ZXNvbWUuY3NzKTtcbi5pbWFnZW4taG9tZSB7XG4gIHdpZHRoOiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuYm9keSwgaHRtbCB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuYm9keSB7XG4gIGZvbnQtZmFtaWx5OiBcIk9wZW4gU2Fuc1wiO1xuICBmb250LXdlaWdodDogMTAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4ubG9naW4tZm9ybSB7XG4gIG1pbi1oZWlnaHQ6IDEwcmVtO1xuICBtYXJnaW46IGF1dG87XG4gIG1heC13aWR0aDogNjAlO1xuICBwYWRkaW5nOiAwLjVyZW07XG59XG5cbi5sb2dpbi10ZXh0IHtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDIuNXJlbTtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIG1heC13aWR0aDogNTAlO1xuICBwYWRkaW5nOiAwLjVyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5sb2dpbi10ZXh0IC5mYS1zdGFjay0xeCB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM0ZGQwZTE7XG59XG5cbi5pbWFnZW4tY2FuZGFkbyB7XG4gIHdpZHRoOiA0MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDMwJSAhaW1wb3J0YW50O1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICB3aWR0aDogMTAwJTtcbn1cbi5jb250ZW5lZG9yLWltYWdlbiAubG9nby1pZm9ydCB7XG4gIHdpZHRoOiAzMCU7XG4gIG1hcmdpbi1sZWZ0OiAzNSU7XG4gIHBhZGRpbmc6IDAlO1xufVxuXG4uY29udGVuZWRvci10ZXh0byB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ubm8tcmVjb3JkYXIge1xuICBjb2xvcjogd2hpdGU7XG4gIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDE4MGRlZywgcmdiYSgxOSwxNSw5NCwwLjkwMDk5Nzg5OTE1OTY2MzkpIDclLCByZ2JhKDksOSwxMjEsMSkgMTQlLCByZ2JhKDksMTQsMTI1LDAuOTAwOTk3ODk5MTU5NjYzOSkgMzAlLCByZ2JhKDcsNjIsMTU2LDAuOTQwMjEzNTg1NDM0MTczNykgNTMlLCByZ2JhKDAsMjEyLDI1NSwwLjY0MDQ5MzY5NzQ3ODk5MTcpIDkyJSk7XG59XG5cbi5yZWRvbmRlYWRvIHtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbn1cblxuLmltYWdlbi1jYW5kYWRvIHtcbiAgd2lkdGg6IDQwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMzAlICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW5lZG9yLWlucHV0cyB7XG4gIHdpZHRoOiA2MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDIwJSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xufVxuLmNvbnRlbmVkb3ItaW5wdXRzIGlvbi1pdGVtIHtcbiAgbWFyZ2luLXRvcDogMyUgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOndoaXRlO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHdoaXRlO1xuICAvKiogb2JqZXRvcyBkZWwgaXRlbSAqKi9cbiAgLyoqIGNvbG9yIGRlbCBpdGVtIChkZW50cm8gb2JqZXRvcyxsZXRyYXMpICoqL1xuICAtLWNvbG9yOmJsYWNrO1xuICAtLWNvbG9yLWFjdGl2YXRlZDpibGFjaztcbiAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgYXByZXRhIHRhYiBlbmNpbWEgKiovXG4gIC0tY29sb3ItZm9jdXNlZDpibGFjaztcbiAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgcGFzYSBlbCBtb3VzZSBlbmNpbWEgKiovXG4gIC0tY29sb3ItaG92ZXI6d2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgbWFyZ2luLWJvdHRvbTogNXZoICFpbXBvcnRhbnQ7XG59XG4uY29udGVuZWRvci1pbnB1dHMgaW9uLWl0ZW0gaW5wdXQge1xuICBib3JkZXI6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG4uY29udGVuZWRvci1pbnB1dHMgLmJvdG9uLWxvZ2luIHtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogNiU7XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiAxMDAwcHgpIHtcbiAgLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuICAuY29udGVuZWRvci1pbWFnZW4gLmxvZ28taWZvcnQge1xuICAgIHdpZHRoOiA3MCU7XG4gICAgbWFyZ2luLWxlZnQ6IDE1JTtcbiAgICBwYWRkaW5nOiAwJTtcbiAgfVxuXG4gIC5mb3JtdWxhcmlvMiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luLXRvcDogMCU7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgcGFkZGluZy1ib3R0b206IDAlO1xuICB9XG5cbiAgLmNvbnRlbmVkb3ItaW5wdXRzIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1sZWZ0OiAwJSAhaW1wb3J0YW50O1xuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gIH1cbiAgLmNvbnRlbmVkb3ItaW5wdXRzIGlvbi1pdGVtIHtcbiAgICBtYXJnaW4tdG9wOiAzJSAhaW1wb3J0YW50O1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOndoaXRlO1xuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IHdoaXRlO1xuICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiB3aGl0ZTtcbiAgICAvKiogb2JqZXRvcyBkZWwgaXRlbSAqKi9cbiAgICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovXG4gICAgLS1jb2xvcjpibGFjaztcbiAgICAtLWNvbG9yLWFjdGl2YXRlZDpibGFjaztcbiAgICAvKiogY29sb3IgZGUgbG8gZGUgZGVudHJvIGN1YW5kbyBzZSBsZSBhcHJldGEgdGFiIGVuY2ltYSAqKi9cbiAgICAtLWNvbG9yLWZvY3VzZWQ6YmxhY2s7XG4gICAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgcGFzYSBlbCBtb3VzZSBlbmNpbWEgKiovXG4gICAgLS1jb2xvci1ob3ZlcjpibGFjaztcbiAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgbWFyZ2luLWJvdHRvbTogNXZoICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmNvbnRlbmVkb3ItaW5wdXRzIGlvbi1pdGVtIGlucHV0IHtcbiAgICBib3JkZXI6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmNvbnRlbmVkb3ItaW5wdXRzIC5ib3Rvbi1sb2dpbiB7XG4gICAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tYm90dG9tOiA2JTtcbiAgfVxuXG4gIC5jb250ZW50LXRlcmNlcm8ge1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcbiAgfVxuXG4gIGlvbi1pdGVtIHtcbiAgICBtYXJnaW4tdG9wOiAzJSAhaW1wb3J0YW50O1xuICAgIC0tYmFja2dyb3VuZDogI2Y1ZjVmNTtcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6ICNmNWY1ZjU7XG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2Y1ZjVmNTtcbiAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogI2Y1ZjVmNTtcbiAgICAvKiogb2JqZXRvcyBkZWwgaXRlbSAqKi9cbiAgICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovXG4gICAgLS1jb2xvcjogYmxhY2s7XG4gICAgLS1jb2xvci1hY3RpdmF0ZWQ6IGJsYWNrO1xuICAgIC8qKiBjb2xvciBkZSBsbyBkZSBkZW50cm8gY3VhbmRvIHNlIGxlIGFwcmV0YSB0YWIgZW5jaW1hICoqL1xuICAgIC0tY29sb3ItZm9jdXNlZDogYmxhY2s7XG4gICAgLyoqIGNvbG9yIGRlIGxvIGRlIGRlbnRybyBjdWFuZG8gc2UgbGUgcGFzYSBlbCBtb3VzZSBlbmNpbWEgKiovXG4gICAgLS1jb2xvci1ob3ZlcjogYmxhY2s7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIG1hcmdpbi1ib3R0b206IDV2aCAhaW1wb3J0YW50O1xuICB9XG4gIGlvbi1pdGVtIGlucHV0IHtcbiAgICBib3JkZXI6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuYm90b24tbG9naW4ge1xuICAgIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIH1cblxuICBpb24tdGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC1mYW1pbHk6IHNlcmlmLCBib2xkO1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICAgIHBhZGRpbmctYm90dG9tOiAxMHZoO1xuICAgIGJhY2tncm91bmQ6ICM1ZGI1OTY7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _servicios_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_servicios/auth.service */ "./src/app/_servicios/auth.service.ts");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../_servicios/empresas.service */ "./src/app/_servicios/empresas.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../app.component */ "./src/app/app.component.ts");









var LoginPage = /** @class */ (function () {
    function LoginPage(app, events, userService, empresaService, router, loadingController, authService) {
        this.app = app;
        this.events = events;
        this.userService = userService;
        this.empresaService = empresaService;
        this.router = router;
        this.loadingController = loadingController;
        this.authService = authService;
        var menu = document.querySelector('ion-menu');
        menu.hidden = true;
    }
    LoginPage.prototype.ngOnInit = function () {
        if (sessionStorage.getItem('empresaId')) {
            this.router.navigate(['home']);
        }
    };
    LoginPage.prototype.login = function (form) {
        var _this = this;
        var self = this;
        this.cargando();
        try {
            this.authService.login(form.value).subscribe(function (res) {
                //      console.log(res);
                var accessToken = res.accessToken;
                var refreshToken = res.refreshToken;
                var userId = res.userId;
                sessionStorage.setItem('accessToken', accessToken);
                sessionStorage.setItem('refreshToken', refreshToken);
                sessionStorage.setItem('userId', userId);
                self.userService.gathering(userId).subscribe(function (datos) {
                    var empresaId = datos.empresaId;
                    var asignado = datos.asignado;
                    var menus = datos.menus;
                    //menus.push({title: "Perfil",path: "perfil",icon: "person",_id:"askjdals"})
                    self.empresaService.listarById(empresaId).subscribe(function (empresa) {
                        if (!empresa['estado']) {
                            self.router.navigate(['login']);
                            return;
                        }
                        sessionStorage.setItem('empresaId', empresaId);
                        sessionStorage.setItem('usuario', JSON.stringify(datos));
                        _this.app.usuario.nombre = datos.firstName;
                        _this.app.usuario.apellido = datos.lastName;
                        sessionStorage.setItem('menus', JSON.stringify(datos.menus));
                        sessionStorage.setItem('asignado', JSON.stringify(asignado));
                        sessionStorage.setItem('evaluaciones', JSON.stringify(datos.evaluaciones));
                        _this.events.publish('user:login', menus);
                        sessionStorage.setItem('empresa', JSON.stringify(empresa));
                        var jerarquia = JSON.stringify(empresa['jerarquia']);
                        sessionStorage.setItem('jerarquia', JSON.stringify(jerarquia));
                        self.router.navigate(['home']);
                    });
                });
            });
        }
        catch (err) {
            console.log(err);
        }
    };
    LoginPage.prototype.cargando = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            spinner: null,
                            duration: 5000,
                            message: 'Iniciando sesión<ion-spinner></ion-spinner>',
                            translucent: true,
                            cssClass: 'custom-class custom-loading'
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoginPage.ctorParameters = function () { return [
        { type: _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Events"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
        { type: _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_4__["EmpresaService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
        { type: _servicios_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Events"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"],
            _servicios_empresas_service__WEBPACK_IMPORTED_MODULE_4__["EmpresaService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
            _servicios_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=login-login-module-es5.js.map