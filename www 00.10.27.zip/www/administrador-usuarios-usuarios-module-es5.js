(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["administrador-usuarios-usuarios-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/usuarios.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/usuarios/usuarios.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"dismiss()\"  defaultHref=\"usuarios\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Usuarios</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerUsuarios($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-usuarios\" src=\"https://image.flaticon.com/icons/png/512/554/554846.png\">\n  </div>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"!verAgregar\">\n    <ion-fab-button>\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n\n         <ion-fab-button (click)=\"abrirImportar();verAgregar = false;\" >\n           <ion-icon name=\"document\" ></ion-icon>\n         </ion-fab-button>\n\n         <ion-fab-button (click)=\"redifinirUsuario();verAgregar = true;\" *ngIf=\"!verAgregar\">\n           <ion-icon name=\"add\" ></ion-icon>\n         </ion-fab-button>\n\n    </ion-fab-list>\n\n  </ion-fab>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"verAgregar\">\n    <ion-fab-button (click)=\"redifinirUsuario();verAgregar = false;\" >\n      <ion-icon name=\"remove\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <br>\n\n\n\n  <form *ngIf=\"verAgregar\" [formGroup]=\"formularioUsuario\">\n    <ion-item style=\"padding-top: 20px\">\n\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Nombres</ion-label>\n      <ion-input formControlName=\"firstName\" [(ngModel)]=\"usuario.firstName\" ></ion-input>\n    </ion-item>\n    <br>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Apellidos</ion-label>\n      <ion-input formControlName=\"lastName\"  [(ngModel)]=\"usuario.lastName\"></ion-input>\n    </ion-item>\n    <br>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Rut</ion-label>\n      <ion-input formControlName=\"rut\" type=\"text\" [(ngModel)]=\"usuario.rut\" (change)=\"validar(usuario.rut)\"></ion-input>\n    </ion-item>\n    <br>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Email</ion-label>\n      <ion-input formControlName=\"email\" type=\"email\" [(ngModel)]=\"usuario.email\"></ion-input>\n    </ion-item>\n    <br>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Telefono</ion-label>\n      <ion-input formControlName=\"phone\" type=\"text\" [(ngModel)]=\"usuario.phone\"></ion-input>\n    </ion-item>\n    <br>\n    <ion-item style=\"padding-top: 20px\" *ngIf=\"usuario.id == '' \">\n\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Clave</ion-label>\n      <ion-input formControlName=\"password\" type=\"{{tipo}}\"  [(ngModel)]=\"usuario.password\" ></ion-input>\n      <ion-icon name=\"eye\"   *ngIf=\"tipo != 'text'\" (click)=\"tipo = 'text'\" slot=\"end\"></ion-icon>\n      <ion-icon name=\"eye-off\" *ngIf=\"tipo == 'text'\" (click)=\"tipo = 'password'\" slot=\"end\"></ion-icon>\n    </ion-item>\n\n    <br>\n    <ion-item-divider mode=\"md\">\n\n    </ion-item-divider>\n\n    <ion-button *ngIf=\"usuario.id == '' \" size=\"medium\" [disabled]=\"!formularioUsuario.valid\" (click)=\"confirmar()\">Guardar</ion-button>\n    <ion-button *ngIf=\"usuario.id != ''\"  size=\"medium\" (click)=\"actualizarUsuario();verAgregar = false\">Actualizar</ion-button>\n\n  </form>\n\n  <br>\n\n  <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n    <b>Lista de usuarios</b>\n  </ion-item-divider>\n\n  <ion-item-sliding #slidingItem *ngFor=\"let usuario of usuarios\">\n\n    <ion-item-options side=\"start\">\n      <ion-item-option color=\"danger\" expandable (click)=\"borrar(usuario)\" >\n        <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n      </ion-item-option>\n    </ion-item-options>\n\n    <ion-item (click)=\"visualizar(usuario,slidingItem);verAgregar = true\">\n      <div class=\"contenedor-card\">\n        <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/554/554846.png\">\n      </div>\n      <ion-label >{{usuario.firstName}} {{usuario.lastName}}</ion-label>\n    </ion-item>\n\n    <ion-item-options side=\"end\" >\n      <ion-item-option (click)=\"abrirPermisos(usuario,slidingItem)\" color=\"warning\">Menú</ion-item-option>\n      <ion-item-option (click)=\"asignar(usuario,slidingItem)\" color=\"primary\">Asignar</ion-item-option>\n      <ion-item-option (click)=\"abrirProductos(usuario,slidingItem)\" color=\"tertiary\">Productos</ion-item-option>\n\n    </ion-item-options>\n  </ion-item-sliding>\n\n  <h3 *ngIf=\"usuarios.length == 0\">No hay usuarios disponibles</h3>\n\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/administrador/usuarios/usuarios-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/administrador/usuarios/usuarios-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: UsuariosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosPageRoutingModule", function() { return UsuariosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _usuarios_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./usuarios.page */ "./src/app/administrador/usuarios/usuarios.page.ts");




var routes = [
    {
        path: '',
        component: _usuarios_page__WEBPACK_IMPORTED_MODULE_3__["UsuariosPage"]
    },
    {
        path: 'asignar',
        loadChildren: function () { return __webpack_require__.e(/*! import() | asignar-asignar-module */ "asignar-asignar-module").then(__webpack_require__.bind(null, /*! ./asignar/asignar.module */ "./src/app/administrador/usuarios/asignar/asignar.module.ts")).then(function (m) { return m.AsignarPageModule; }); }
    },
    {
        path: 'importar',
        loadChildren: function () { return __webpack_require__.e(/*! import() | importar-importar-module */ "importar-importar-module").then(__webpack_require__.bind(null, /*! ./importar/importar.module */ "./src/app/administrador/usuarios/importar/importar.module.ts")).then(function (m) { return m.ImportarPageModule; }); }
    },
    {
        path: 'productos',
        loadChildren: function () { return __webpack_require__.e(/*! import() | productos-productos-module */ "productos-productos-module").then(__webpack_require__.bind(null, /*! ./productos/productos.module */ "./src/app/administrador/usuarios/productos/productos.module.ts")).then(function (m) { return m.ProductosPageModule; }); }
    }
];
var UsuariosPageRoutingModule = /** @class */ (function () {
    function UsuariosPageRoutingModule() {
    }
    UsuariosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], UsuariosPageRoutingModule);
    return UsuariosPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/administrador/usuarios/usuarios.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/administrador/usuarios/usuarios.module.ts ***!
  \***********************************************************/
/*! exports provided: UsuariosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosPageModule", function() { return UsuariosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./usuarios-routing.module */ "./src/app/administrador/usuarios/usuarios-routing.module.ts");
/* harmony import */ var _usuarios_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./usuarios.page */ "./src/app/administrador/usuarios/usuarios.page.ts");







var UsuariosPageModule = /** @class */ (function () {
    function UsuariosPageModule() {
    }
    UsuariosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_5__["UsuariosPageRoutingModule"]
            ],
            declarations: [_usuarios_page__WEBPACK_IMPORTED_MODULE_6__["UsuariosPage"]]
        })
    ], UsuariosPageModule);
    return UsuariosPageModule;
}());



/***/ }),

/***/ "./src/app/administrador/usuarios/usuarios.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/administrador/usuarios/usuarios.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #21ada1;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #21ada1;\n  margin-bottom: 5%;\n}\n\n.imagen-usuarios {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.contenedor-card {\n  --background: #3949ab;\n  --color: white !important;\n  margin-right: 5%;\n}\n\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n  font-family: \"Roboto\";\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: #20d1c2;\n  --background-activated: #20d1c2;\n  --background-hover: #20d1c2;\n  --color: white;\n}\n\nion-button {\n  --background: #20d1c2 !important;\n  --background-activated: #20d1c2 !important;\n  --background-hover: #20d1c2 !important;\n  width: 60% !important;\n  margin-left: 20% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYWRtaW5pc3RyYWRvci91c3Vhcmlvcy91c3Vhcmlvcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkbWluaXN0cmFkb3IvdXN1YXJpb3MvdXN1YXJpb3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Qsa0JBQUE7QUNBRDs7QURHQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNBRDs7QURHQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FDQUY7O0FER0E7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtFQUNBLHFCQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNLRjs7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxvRkFBQTtBQ0NGOztBREFFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNFRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUJBQUE7QUNDRjs7QURFQTtFQUNFLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGdDQUFBO0VBQ0EsMENBQUE7RUFDQSxzQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL2FkbWluaXN0cmFkb3IvdXN1YXJpb3MvdXN1YXJpb3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICMyMWFkYTE7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcblx0dGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICMyMWFkYTE7XG5cdG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLXVzdWFyaW9ze1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5jb250ZW5lZG9yLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogIzM5NDlhYjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcblx0XHRtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG4uaW1hZ2VuLWNhcmR7XG4gIHdpZHRoOiA1MHB4O1xuICBtYXJnaW4tbGVmdDogMCU7XG4gIG1hcmdpbi10b3A6IDAlO1xuICBtYXJnaW4tYm90dG9tOiAwJTtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMyMGQxYzI7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzIwZDFjMjtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogIzIwZDFjMiAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMjBkMWMyICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogICMyMGQxYzIgIWltcG9ydGFudDtcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG59XG4iLCJpb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMjFhZGExO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICBiYWNrZ3JvdW5kOiAjMjFhZGExO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi11c3VhcmlvcyB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmNvbnRlbmVkb3ItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogIzM5NDlhYjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuLmltYWdlbi1jYXJkIHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG5pb24taXRlbSB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzIwZDFjMjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzIwZDFjMjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMjBkMWMyO1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzIwZDFjMiAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMjBkMWMyICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzIwZDFjMiAhaW1wb3J0YW50O1xuICB3aWR0aDogNjAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAyMCUgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/administrador/usuarios/usuarios.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/administrador/usuarios/usuarios.page.ts ***!
  \*********************************************************/
/*! exports provided: UsuariosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosPage", function() { return UsuariosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _permisos_permisos_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./permisos/permisos.page */ "./src/app/administrador/usuarios/permisos/permisos.page.ts");
/* harmony import */ var _asignar_asignar_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./asignar/asignar.page */ "./src/app/administrador/usuarios/asignar/asignar.page.ts");
/* harmony import */ var _importar_importar_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./importar/importar.page */ "./src/app/administrador/usuarios/importar/importar.page.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _productos_productos_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./productos/productos.page */ "./src/app/administrador/usuarios/productos/productos.page.ts");











// Definir modelo usuario
var UsuariosPage = /** @class */ (function () {
    function UsuariosPage(toastController, alertController, events, location, modalCtrl, userService) {
        this.toastController = toastController;
        this.alertController = alertController;
        this.events = events;
        this.location = location;
        this.modalCtrl = modalCtrl;
        this.userService = userService;
        this.usuarios = [];
        this.usuarioVacio = { id: '', firstName: '', lastName: '', email: '', password: '', rut: '', phone: '', empresaId: '' };
        this.usuario = { id: '', firstName: '', lastName: '', email: '', password: '', rut: '', phone: '', empresaId: '' };
        this.tipo = "password";
        this.verAgregar = false;
    }
    UsuariosPage.prototype.log = function () {
        console.log(this.formularioUsuario);
    };
    UsuariosPage.prototype.presentToast = function (Mensaje) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: Mensaje,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UsuariosPage.prototype.validar = function (rut) {
        // Despejar Puntos
        var valor = rut.replace('.', '');
        while (valor.indexOf('.') != -1) {
            valor = valor.replace('.', '');
        }
        // Despejar Guión
        valor = valor.replace('-', '');
        // Aislar Cuerpo y Dígito Verificador
        var cuerpo = valor.slice(0, -1);
        var dv = valor.slice(-1).toUpperCase();
        // Formatear RUN
        rut = cuerpo + '-' + dv;
        // Si no cumple con el mínimo ej. (n.nnn.nnn)
        if (cuerpo.length < 7) {
            alert("Rut incompleto");
        }
        // Calcular Dígito Verificador
        var suma = 0;
        var multiplo = 2;
        // Para cada dígito del Cuerpo
        for (var i = 1; i <= cuerpo.length; i++) {
            // Obtener su Producto con el Múltiplo Correspondiente
            var index = multiplo * valor.charAt(cuerpo.length - i);
            // Sumar al Contador General
            suma = suma + index;
            // Consolidar Múltiplo dentro del rango [2,7]
            if (multiplo < 7) {
                multiplo = multiplo + 1;
            }
            else {
                multiplo = 2;
            }
        }
        // Calcular Dígito Verificador en base al Módulo 11
        var dvEsperado = 11 - (suma % 11);
        // Casos Especiales (0 y K)
        dv = (dv == 'K') ? 10 : dv;
        dv = (dv == 0) ? 11 : dv;
        // Validar que el Cuerpo coincide con su Dígito Verificador
        if (dvEsperado != dv) {
            alert("RUT Inválido");
        }
    };
    /*
    <input type="file" style="display: inline-block;" (change)="incomingfile($event)" placeholder="Upload file" accept=".xlsx">
    <button type="button" class="btn btn-info" (click)="Upload()" >Upload</button>
    */
    UsuariosPage.prototype.ngOnInit = function () {
        this.formularioUsuario = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormGroup"]({
            firstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].minLength(2)]),
            lastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required),
            rut: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required),
            phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required)
        });
        this.traerUsuarios(false);
    };
    UsuariosPage.prototype.abrirImportar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _importar_importar_page__WEBPACK_IMPORTED_MODULE_6__["ImportarPage"],
                            cssClass: 'modals'
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            console.log("datos de importar usuarios", modal);
                            if (modal.data) {
                                console.log(modal);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    UsuariosPage.prototype.abrirProductos = function (usuario, slide) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        slide.close();
                        console.log(usuario);
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _productos_productos_page__WEBPACK_IMPORTED_MODULE_9__["ProductosPage"],
                                cssClass: 'modals',
                                componentProps: {
                                    'productos': usuario.canjeables,
                                    'usuario': usuario.firstName + " " + usuario.lastName
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log(modal);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    UsuariosPage.prototype.redifinirUsuario = function () {
        this.usuario = this.usuarioVacio;
    };
    UsuariosPage.prototype.traerUsuarios = function (evento) {
        var _this = this;
        this.userService.listar().subscribe(function (usuarios) {
            console.log(usuarios);
            _this.usuarios = usuarios;
            if (evento) {
                evento.target.complete();
            }
        });
    };
    UsuariosPage.prototype.abrirPermisos = function (usuario, slide) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        slide.close();
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _permisos_permisos_page__WEBPACK_IMPORTED_MODULE_4__["PermisosPage"],
                                cssClass: 'modals',
                                componentProps: {
                                    'usuario': usuario,
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            console.log("datos de permisos de usuario", modal);
                            if (modal.data) {
                                var id = sessionStorage.getItem('userId');
                                usuario.menus = modal.data;
                                usuario.password = undefined;
                                if (usuario.id == id) {
                                    _this.events.publish('user:login', usuario.menus);
                                    sessionStorage.setItem('menus', JSON.stringify(usuario.menus));
                                }
                                usuario.password = undefined;
                                console.log("usuario a actualizar", usuario);
                                _this.userService.actualizar(usuario.id, usuario).subscribe(function (res) {
                                    console.log(res);
                                });
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    UsuariosPage.prototype.actualizarUsuario = function () {
        var _this = this;
        this.userService.actualizar(this.usuario.id, this.usuario).subscribe(function (res) {
            _this.presentToast("Usuario actualizado satisfactoriamente");
            _this.usuario = _this.usuarioVacio;
        });
    };
    UsuariosPage.prototype.guardarUsuario = function () {
        var _this = this;
        this.usuario.id = "" + (this.usuarios.length + 1);
        this.userService.insertar(this.usuario).subscribe(function (usuario) {
            _this.presentToast("Usuario creado satisfactoriamente");
            _this.usuario = _this.usuarioVacio;
        });
    };
    UsuariosPage.prototype.confirmar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Favor confirmar!',
                            message: 'Estas a punto de <br><strong>CREAR UN USUARIO</strong>!!!',
                            buttons: [
                                {
                                    text: 'Cancelar',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function (blah) {
                                        console.log('Cancelado');
                                    }
                                }, {
                                    text: 'Aceptar',
                                    handler: function () {
                                        _this.guardarUsuario();
                                        _this.verAgregar = false;
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    UsuariosPage.prototype.borrar = function (usuario) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Confirmar Elminación!',
                            message: 'Estas a punto de <br><strong>BORRAR UN USUARIO</strong>!!!',
                            buttons: [
                                {
                                    text: 'Cancelar',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function (blah) {
                                        console.log('Cancelado');
                                    }
                                }, {
                                    text: 'Aceptar',
                                    handler: function () {
                                        _this.borrarUsuario(usuario);
                                        _this.verAgregar = false;
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    UsuariosPage.prototype.borrarUsuario = function (usuario) {
        var _this = this;
        this.userService.borrar(usuario.id).subscribe(function (res) {
            _this.traerUsuarios(false);
        });
    };
    UsuariosPage.prototype.asignar = function (usuario, slide) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        slide.close();
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _asignar_asignar_page__WEBPACK_IMPORTED_MODULE_5__["AsignarPage"],
                                cssClass: 'modals',
                                componentProps: {
                                    'usuario': usuario
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            console.log(usuario);
                            console.log("datos de asignacion de usuario", modal);
                            if (modal.data) {
                                var id = sessionStorage.getItem('userId');
                                usuario.asignado = modal.data;
                                usuario.password = undefined;
                                console.log("usuario a actualizar", usuario);
                                _this.userService.actualizar(usuario.id, usuario).subscribe(function (res) {
                                    console.log(res);
                                });
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    UsuariosPage.prototype.visualizar = function (usuario, slide) {
        this.usuario = usuario;
        slide.close();
    };
    UsuariosPage.prototype.dismiss = function () {
        this.location.back();
    };
    UsuariosPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Events"] },
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_7__["Location"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] }
    ]; };
    UsuariosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-usuarios',
            template: __webpack_require__(/*! raw-loader!./usuarios.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/usuarios/usuarios.page.html"),
            styles: [__webpack_require__(/*! ./usuarios.page.scss */ "./src/app/administrador/usuarios/usuarios.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Events"],
            _angular_common__WEBPACK_IMPORTED_MODULE_7__["Location"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"]])
    ], UsuariosPage);
    return UsuariosPage;
}());



/***/ })

}]);
//# sourceMappingURL=administrador-usuarios-usuarios-module-es5.js.map