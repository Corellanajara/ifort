(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["canjeables-canjeables-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/canjeables/canjeables.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/canjeables/canjeables.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Canjeables</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-badge color=\"light\">{{usuario.puntos || 0 }}</ion-badge>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-canjeables\" src=\"https://image.flaticon.com/icons/svg/679/679938.svg\">\n  </div>\n\n    <div class=\"contenedor-cards\">\n        <ion-card class=\"card\" *ngFor=\"let producto of productos;index as i\">\n          <div class=\"imagen-card\" [style.background-image]=\"imagenes[i]\"></div>\n          <ion-card-header>\n            <ion-card-subtitle>{{producto.puntos}} puntos</ion-card-subtitle>\n            <ion-card-title>{{producto.titulo}}</ion-card-title>\n          </ion-card-header>\n          <ion-card-content>\n            {{producto.descripcion}}\n          </ion-card-content>\n          <ion-fab vertical=\"center\" horizontal=\"end\" slot=\"fixed\"  *ngIf=\"usuario.puntos < producto.puntos\">\n\n            <ion-fab-button *ngIf=\"!estados[i]\" class=\"ion-fab-button-no-alcanza\" >\n              <ion-icon name=\"pricetag\" ></ion-icon>\n            </ion-fab-button>\n\n          </ion-fab>\n          <ion-fab vertical=\"center\" horizontal=\"end\" slot=\"fixed\"  *ngIf=\"usuario.puntos > producto.puntos\">\n\n            <ion-fab-button *ngIf=\"!estados[i]\" class=\"ion-fab-button\" (click)=\"presentAlert(i,producto)\">\n              <ion-icon name=\"pricetag\"></ion-icon>\n            </ion-fab-button>\n\n            <ion-fab-button *ngIf=\"estados[i]\" class=\"ion-fab-button-comprado\">\n              <ion-icon name=\"checkmark\"></ion-icon>\n            </ion-fab-button>\n          </ion-fab>\n        </ion-card>\n    </div>\n\n<!--\n  <div class=\"contenedor-tarjeta\">\n\n    <div class=\"wrapper\" *ngFor=\"let producto of productos;index as i\">\n\n      <div class=\"tarjeta\">\n\n        <div class=\"container\">\n            <div class=\"top\" [style.background-image]=\"imagenes[i]\"></div>\n\n            <div class=\"bottom {{clicked[i]}}\">\n              <div class=\"left\">\n                <div class=\"details\">\n                  <ion-label>{{producto.titulo}}</ion-label>\n                  <p>{{producto.puntos}} ptos</p>\n                </div>\n                <div class=\"buy\" (click)=\"presentAlert(i,producto)\" *ngIf=\"usuario.puntos >= producto.puntos\">\n                  <ion-icon style=\"font-size:500%\" name=\"cart\"></ion-icon>\n                </div>\n                <div class=\"buy\"  *ngIf=\"usuario.puntos < producto.puntos\">\n                  <ion-icon style=\"font-size:500%;color:gray\" name=\"cart\"></ion-icon>\n                </div>\n              </div>\n              <div class=\"right\">\n                <div class=\"done\"><ion-icon style=\"font-size:500%\" name=\"checkmark\"></ion-icon></div>\n                <div class=\"details\">\n                  <ion-label>{{producto.titulo}}</ion-label>\n                  <p>Solicitado!</p>\n                </div>\n                <div class=\"remove \" ><ion-icon style=\"font-size:500%\" name=\"happy\"></ion-icon></div>\n              </div>\n            </div>\n\n          </div>\n\n        </div>\n\n      <div class=\"inside\">\n        <div class=\"icon\"><ion-icon name=\"information-circle-outline\"></ion-icon></div>\n        <div class=\"contents\">\n          {{producto.descripcion}}\n        </div>\n      </div>\n\n    </div>\n  </div>\n  -->\n</ion-content>\n"

/***/ }),

/***/ "./src/app/canjeables/canjeables-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/canjeables/canjeables-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: CanjeablesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CanjeablesPageRoutingModule", function() { return CanjeablesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _canjeables_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./canjeables.page */ "./src/app/canjeables/canjeables.page.ts");




const routes = [
    {
        path: '',
        component: _canjeables_page__WEBPACK_IMPORTED_MODULE_3__["CanjeablesPage"]
    }
];
let CanjeablesPageRoutingModule = class CanjeablesPageRoutingModule {
};
CanjeablesPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CanjeablesPageRoutingModule);



/***/ }),

/***/ "./src/app/canjeables/canjeables.module.ts":
/*!*************************************************!*\
  !*** ./src/app/canjeables/canjeables.module.ts ***!
  \*************************************************/
/*! exports provided: CanjeablesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CanjeablesPageModule", function() { return CanjeablesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _canjeables_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./canjeables-routing.module */ "./src/app/canjeables/canjeables-routing.module.ts");
/* harmony import */ var _canjeables_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./canjeables.page */ "./src/app/canjeables/canjeables.page.ts");







let CanjeablesPageModule = class CanjeablesPageModule {
};
CanjeablesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _canjeables_routing_module__WEBPACK_IMPORTED_MODULE_5__["CanjeablesPageRoutingModule"]
        ],
        declarations: [_canjeables_page__WEBPACK_IMPORTED_MODULE_6__["CanjeablesPage"]]
    })
], CanjeablesPageModule);



/***/ }),

/***/ "./src/app/canjeables/canjeables.page.scss":
/*!*************************************************!*\
  !*** ./src/app/canjeables/canjeables.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "html, body {\n  background: #E3E3D8;\n  font-family: sans-serif;\n  padding: 25px;\n}\n\n/* cards */\n\n.contenedor-cards {\n  width: 100% !important;\n}\n\n.imagen-card {\n  width: 100%;\n  height: 350px;\n  background: no-repeat center;\n  background-size: cover;\n}\n\n.card {\n  width: 333px;\n  position: relative;\n  display: inline-block;\n}\n\n.ion-fab-button {\n  --background: #8bc34a !important;\n  --background-activated: #8bc34a !important;\n  --background-hover: #8bc34a !important;\n  --color: white;\n  -webkit-transition: 2s;\n  transition: 2s;\n}\n\n.ion-fab-button-no-alcanza {\n  --background: gray !important;\n  --background-activated: gray !important;\n  --background-hover: gray !important;\n  --color: white;\n  -webkit-transition: 2s;\n  transition: 2s;\n}\n\n.ion-fab-button-comprado {\n  --background: #00c853 !important;\n  --background-activated: #00c853!important;\n  --background-hover: #00c853 !important;\n  --color: white;\n  -webkit-transition: 2s;\n  transition: 2s;\n}\n\n/*    */\n\n.contenedor-tarjeta {\n  width: 100% !important;\n}\n\n.tarjeta {\n  width: 100%;\n}\n\n.wrapper {\n  width: 300px;\n  height: 500px;\n  background: white;\n  margin: auto;\n  position: relative;\n  overflow: hidden;\n  display: inline-block;\n  border-radius: 10px 10px 10px 10px;\n  box-shadow: 0;\n  -webkit-transform: scale(0.95);\n          transform: scale(0.95);\n  -webkit-transition: box-shadow 0.5s, -webkit-transform 0.5s;\n  transition: box-shadow 0.5s, -webkit-transform 0.5s;\n  transition: box-shadow 0.5s, transform 0.5s;\n  transition: box-shadow 0.5s, transform 0.5s, -webkit-transform 0.5s;\n  margin-left: calc((100% - 300px)/2);\n}\n\n.wrapper:hover {\n  -webkit-transform: scale(1);\n          transform: scale(1);\n  box-shadow: 5px 20px 30px rgba(0, 0, 0, 0.2);\n}\n\n.wrapper .container {\n  width: 100%;\n  height: 100%;\n}\n\n.wrapper .container .top {\n  height: 80%;\n  width: 100%;\n  background: no-repeat center center;\n  background-size: 100%;\n}\n\n.wrapper .container .bottom {\n  width: 200%;\n  height: 20%;\n  -webkit-transition: -webkit-transform 0.5s;\n  transition: -webkit-transform 0.5s;\n  transition: transform 0.5s;\n  transition: transform 0.5s, -webkit-transform 0.5s;\n}\n\n.wrapper .container .bottom.clicked {\n  -webkit-transform: translateX(-50%);\n          transform: translateX(-50%);\n}\n\n.wrapper .container .bottom h1 {\n  margin: 0;\n  padding: 0;\n}\n\n.wrapper .container .bottom p {\n  margin: 0;\n  padding: 0;\n}\n\n.wrapper .container .bottom .left {\n  height: 100%;\n  width: 50%;\n  background: #f4f4f4;\n  position: relative;\n  float: left;\n}\n\n.wrapper .container .bottom .left .details {\n  padding: 20px;\n  float: left;\n  width: calc(70% - 40px);\n}\n\n.wrapper .container .bottom .left .buy {\n  float: right;\n  width: calc(30% - 2px);\n  height: 100%;\n  background: #f1f1f1;\n  -webkit-transition: background 0.5s;\n  transition: background 0.5s;\n  border-left: solid thin rgba(0, 0, 0, 0.1);\n}\n\n.wrapper .container .bottom .left .buy i {\n  font-size: 30px;\n  padding: 30px;\n  color: #254053;\n  -webkit-transition: -webkit-transform 0.5s;\n  transition: -webkit-transform 0.5s;\n  transition: transform 0.5s;\n  transition: transform 0.5s, -webkit-transform 0.5s;\n}\n\n.wrapper .container .bottom .left .buy:hover {\n  background: #A6CDDE;\n}\n\n.wrapper .container .bottom .left .buy:hover i {\n  -webkit-transform: translateY(5px);\n          transform: translateY(5px);\n  color: #00394B;\n}\n\n.wrapper .container .bottom .right {\n  width: 50%;\n  background: #A6CDDE;\n  color: white;\n  float: right;\n  height: 200%;\n  overflow: hidden;\n}\n\n.wrapper .container .bottom .right .details {\n  padding: 20px;\n  float: right;\n  width: calc(70% - 40px);\n}\n\n.wrapper .container .bottom .right .done {\n  width: calc(30% - 2px);\n  float: left;\n  -webkit-transition: -webkit-transform 0.5s;\n  transition: -webkit-transform 0.5s;\n  transition: transform 0.5s;\n  transition: transform 0.5s, -webkit-transform 0.5s;\n  border-right: solid thin rgba(255, 255, 255, 0.3);\n  height: 50%;\n}\n\n.wrapper .container .bottom .right .done i {\n  font-size: 30px;\n  padding: 30px;\n  color: white;\n}\n\n.wrapper .container .bottom .right .remove {\n  width: calc(30% - 1px);\n  clear: both;\n  border-right: solid thin rgba(255, 255, 255, 0.3);\n  height: 50%;\n  background: #2ac334;\n  -webkit-transition: background 0.5s, -webkit-transform 0.5s;\n  transition: background 0.5s, -webkit-transform 0.5s;\n  transition: transform 0.5s, background 0.5s;\n  transition: transform 0.5s, background 0.5s, -webkit-transform 0.5s;\n}\n\n.wrapper .container .bottom .right .remove:hover {\n  background: #29c154;\n}\n\n.wrapper .container .bottom .right .remove:hover i {\n  -webkit-transform: translateY(5px);\n          transform: translateY(5px);\n}\n\n.wrapper .container .bottom .right .remove i {\n  -webkit-transition: -webkit-transform 0.5s;\n  transition: -webkit-transform 0.5s;\n  transition: transform 0.5s;\n  transition: transform 0.5s, -webkit-transform 0.5s;\n  font-size: 30px;\n  padding: 30px;\n  color: white;\n}\n\n.wrapper .container .bottom .right:hover .remove, .wrapper .container .bottom .right:hover .done {\n  -webkit-transform: translateY(-100%);\n          transform: translateY(-100%);\n}\n\n.wrapper .inside {\n  z-index: 9;\n  background: #92879B;\n  width: 140px;\n  height: 140px;\n  position: absolute;\n  top: -70px;\n  right: -70px;\n  border-radius: 0px 0px 200px 200px;\n  -webkit-transition: all 0.5s, border-radius 2s, top 1s;\n  transition: all 0.5s, border-radius 2s, top 1s;\n  overflow: hidden;\n}\n\n.wrapper .inside .icon {\n  position: absolute;\n  right: 85px;\n  top: 85px;\n  color: white;\n  opacity: 1;\n}\n\n.wrapper .inside:hover {\n  width: 100%;\n  right: 0;\n  top: 0;\n  border-radius: 0;\n  height: 80%;\n}\n\n.wrapper .inside:hover .icon {\n  opacity: 0;\n  right: 15px;\n  top: 15px;\n}\n\n.wrapper .inside:hover .contents {\n  opacity: 1;\n  -webkit-transform: scale(1);\n          transform: scale(1);\n  -webkit-transform: translateY(0);\n          transform: translateY(0);\n}\n\n.wrapper .inside .contents {\n  padding: 5%;\n  opacity: 0;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5);\n  -webkit-transform: translateY(-200%);\n          transform: translateY(-200%);\n  -webkit-transition: opacity 0.2s, -webkit-transform 0.8s;\n  transition: opacity 0.2s, -webkit-transform 0.8s;\n  transition: opacity 0.2s, transform 0.8s;\n  transition: opacity 0.2s, transform 0.8s, -webkit-transform 0.8s;\n}\n\n.wrapper .inside .contents table {\n  text-align: left;\n  width: 100%;\n}\n\n.wrapper .inside .contents h1, .wrapper .inside .contents p, .wrapper .inside .contents table {\n  color: white;\n}\n\n.wrapper .inside .contents p {\n  font-size: 13px;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #b5f7cf;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n\n.imagen-canjeables {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  width: 60% !important;\n  margin-left: 20% !important;\n}\n\n@media (max-width: 1000px) {\n  .contenedor-cards {\n    width: 100%;\n    display: inline-block;\n  }\n  .contenedor-cards .card {\n    width: 80%;\n    margin-left: 10%;\n    background-attachment: scroll;\n  }\n\n  .wrapper {\n    margin-left: 9%;\n  }\n}\n\n@media (min-width: 300px) and (orientation: landscape) {\n  .wrapper {\n    margin-left: 2%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvY2FuamVhYmxlcy9jYW5qZWFibGVzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvY2FuamVhYmxlcy9jYW5qZWFibGVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0FDQ0Y7O0FERUEsVUFBQTs7QUFDQTtFQUNFLHNCQUFBO0FDQ0Y7O0FERUE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDRCQUFBO0VBSUEsc0JBQUE7QUNDRjs7QURFQTtFQUNFLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQ0FBQTtFQUNBLDBDQUFBO0VBQ0Esc0NBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7RUFBQSxjQUFBO0FDQ0Y7O0FEQ0E7RUFDRSw2QkFBQTtFQUNBLHVDQUFBO0VBQ0EsbUNBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7RUFBQSxjQUFBO0FDRUY7O0FEQUE7RUFDRSxnQ0FBQTtFQUNBLHlDQUFBO0VBQ0Esc0NBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7RUFBQSxjQUFBO0FDR0Y7O0FEQUEsT0FBQTs7QUFFQTtFQUNFLHNCQUFBO0FDRUY7O0FEQ0E7RUFDRSxXQUFBO0FDRUY7O0FEQ0E7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtDQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO1VBQUEsc0JBQUE7RUFDQSwyREFBQTtFQUFBLG1EQUFBO0VBQUEsMkNBQUE7RUFBQSxtRUFBQTtFQUNBLG1DQUFBO0FDRUY7O0FEREU7RUFDRSwyQkFBQTtVQUFBLG1CQUFBO0VBQ0EsNENBQUE7QUNHSjs7QURBRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDRUo7O0FEQUk7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUNBLG1DQUFBO0VBSUEscUJBQUE7QUNFTjs7QURBSTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EsMENBQUE7RUFBQSxrQ0FBQTtFQUFBLDBCQUFBO0VBQUEsa0RBQUE7QUNFTjs7QURETTtFQUNFLG1DQUFBO1VBQUEsMkJBQUE7QUNHUjs7QURETTtFQUNJLFNBQUE7RUFDQSxVQUFBO0FDR1Y7O0FERE07RUFDSSxTQUFBO0VBQ0EsVUFBQTtBQ0dWOztBRERNO0VBQ0UsWUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ0dSOztBREZRO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtBQ0lWOztBREZRO0VBQ0UsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUNBQUE7RUFBQSwyQkFBQTtFQUNBLDBDQUFBO0FDSVY7O0FESFU7RUFDRSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSwwQ0FBQTtFQUFBLGtDQUFBO0VBQUEsMEJBQUE7RUFBQSxrREFBQTtBQ0taOztBREhVO0VBQ0UsbUJBQUE7QUNLWjs7QURIVTtFQUNFLGtDQUFBO1VBQUEsMEJBQUE7RUFDQSxjQUFBO0FDS1o7O0FERE07RUFDRSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0dSOztBREZRO0VBQ0UsYUFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtBQ0lWOztBREZRO0VBQ0Usc0JBQUE7RUFDQSxXQUFBO0VBQ0EsMENBQUE7RUFBQSxrQ0FBQTtFQUFBLDBCQUFBO0VBQUEsa0RBQUE7RUFDQSxpREFBQTtFQUNBLFdBQUE7QUNJVjs7QURIVTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQ0taOztBREZRO0VBQ0Usc0JBQUE7RUFDQSxXQUFBO0VBQ0EsaURBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSwyREFBQTtFQUFBLG1EQUFBO0VBQUEsMkNBQUE7RUFBQSxtRUFBQTtBQ0lWOztBREhVO0VBQ0UsbUJBQUE7QUNLWjs7QURIVTtFQUNFLGtDQUFBO1VBQUEsMEJBQUE7QUNLWjs7QURIVTtFQUNFLDBDQUFBO0VBQUEsa0NBQUE7RUFBQSwwQkFBQTtFQUFBLGtEQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FDS1o7O0FERFU7RUFDRSxvQ0FBQTtVQUFBLDRCQUFBO0FDR1o7O0FESUU7RUFDRSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLHNEQUFBO0VBQUEsOENBQUE7RUFDQSxnQkFBQTtBQ0ZKOztBREdJO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FDRE47O0FER0k7RUFDRSxXQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7QUNETjs7QURFTTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtBQ0FSOztBREVNO0VBQ0UsVUFBQTtFQUNBLDJCQUFBO1VBQUEsbUJBQUE7RUFDQSxnQ0FBQTtVQUFBLHdCQUFBO0FDQVI7O0FER0k7RUFDRSxXQUFBO0VBQ0EsVUFBQTtFQUNBLDZCQUFBO1VBQUEscUJBQUE7RUFDQSxvQ0FBQTtVQUFBLDRCQUFBO0VBQ0Esd0RBQUE7RUFBQSxnREFBQTtFQUFBLHdDQUFBO0VBQUEsZ0VBQUE7QUNETjs7QURFTTtFQUNFLGdCQUFBO0VBQ0EsV0FBQTtBQ0FSOztBREVNO0VBQ0UsWUFBQTtBQ0FSOztBREVNO0VBQ0UsZUFBQTtBQ0FSOztBRE1BO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNKRjs7QURPQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNKRDs7QURPQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0pGOztBRE9BO0VBQVM7OztHQUFBO0VBSVAsNEJBQUE7RUFDQSwwQkFBQTtBQ0hGOztBRE1BO0VBQ0UsbUJBQUE7RUFDQTs7OztHQUFBO0FDQ0Y7O0FETUE7RUFDRSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0Usb0ZBQUE7QUNIRjs7QURJRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDRkY7O0FETUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDSEY7O0FEUUE7RUFDRSwrRkFBQTtFQUNBLHlHQUFBO0VBQ0EscUdBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDTEY7O0FEUUE7RUFFRTtJQUNFLFdBQUE7SUFDQSxxQkFBQTtFQ05GO0VEUUU7SUFDRSxVQUFBO0lBQ0EsZ0JBQUE7SUFDQSw2QkFBQTtFQ05KOztFRFVBO0lBRUUsZUFBQTtFQ1JGO0FBQ0Y7O0FEV0E7RUFDSTtJQUVFLGVBQUE7RUNWSjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY2FuamVhYmxlcy9jYW5qZWFibGVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImh0bWwsIGJvZHl7XG4gIGJhY2tncm91bmQ6ICNFM0UzRDg7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xuICBwYWRkaW5nOiAyNXB4O1xufVxuXG4vKiBjYXJkcyAqL1xuLmNvbnRlbmVkb3ItY2FyZHN7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5pbWFnZW4tY2FyZHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMzUwcHg7XG4gIGJhY2tncm91bmQ6IG5vLXJlcGVhdCBjZW50ZXI7XG4gIC13ZWJraXQtYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgLW1vei1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAtby1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4uY2FyZHtcbiAgd2lkdGg6IDMzM3B4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6ICM4YmMzNGEgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzhiYzM0YSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM4YmMzNGEgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIHRyYW5zaXRpb246IDJzO1xufVxuLmlvbi1mYWItYnV0dG9uLW5vLWFsY2FuemF7XG4gIC0tYmFja2dyb3VuZDogZ3JheSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBncmF5ICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogZ3JheSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgdHJhbnNpdGlvbjogMnM7XG59XG4uaW9uLWZhYi1idXR0b24tY29tcHJhZG97XG4gIC0tYmFja2dyb3VuZDogIzAwYzg1MyAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMDBjODUzIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDBjODUzICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICB0cmFuc2l0aW9uOiAycztcbn1cblxuLyogICAgKi9cblxuLmNvbnRlbmVkb3ItdGFyamV0YXtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4udGFyamV0YXtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi53cmFwcGVye1xuICB3aWR0aDogMzAwcHg7XG4gIGhlaWdodDogNTAwcHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBtYXJnaW46IGF1dG87XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrOyAvL2FxdWkgZXN0w6FcbiAgYm9yZGVyLXJhZGl1czogMTBweCAxMHB4IDEwcHggMTBweDtcbiAgYm94LXNoYWRvdzogMDtcbiAgdHJhbnNmb3JtOiBzY2FsZSgwLjk1KTtcbiAgdHJhbnNpdGlvbjogYm94LXNoYWRvdyAwLjVzLCB0cmFuc2Zvcm0gMC41cztcbiAgbWFyZ2luLWxlZnQ6IGNhbGMoKDEwMCUgLSAzMDBweCkvMik7XG4gICY6aG92ZXJ7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICBib3gtc2hhZG93OiA1cHggMjBweCAzMHB4IHJnYmEoMCwwLDAsMC4yKTtcbiAgfVxuXG4gIC5jb250YWluZXJ7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBoZWlnaHQ6MTAwJTtcblxuICAgIC50b3B7XG4gICAgICBoZWlnaHQ6IDgwJTtcbiAgICAgIHdpZHRoOjEwMCU7XG4gICAgICBiYWNrZ3JvdW5kOiBuby1yZXBlYXQgY2VudGVyIGNlbnRlcjtcbiAgICAgIC13ZWJraXQtYmFja2dyb3VuZC1zaXplOiAxMDAlO1xuICAgICAgLW1vei1iYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gICAgICAtby1iYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gICAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gICAgfVxuICAgIC5ib3R0b217XG4gICAgICB3aWR0aDogMjAwJTtcbiAgICAgIGhlaWdodDogMjAlO1xuICAgICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXM7XG4gICAgICAmLmNsaWNrZWR7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbiAgICAgIH1cbiAgICAgIGgxe1xuICAgICAgICAgIG1hcmdpbjowO1xuICAgICAgICAgIHBhZGRpbmc6MDtcbiAgICAgIH1cbiAgICAgIHB7XG4gICAgICAgICAgbWFyZ2luOjA7XG4gICAgICAgICAgcGFkZGluZzowO1xuICAgICAgfVxuICAgICAgLmxlZnR7XG4gICAgICAgIGhlaWdodDoxMDAlO1xuICAgICAgICB3aWR0aDogNTAlO1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZjRmNGY0O1xuICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcbiAgICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgICAgLmRldGFpbHN7XG4gICAgICAgICAgcGFkZGluZzogMjBweDtcbiAgICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgICB3aWR0aDogY2FsYyg3MCUgLSA0MHB4KTtcbiAgICAgICAgfVxuICAgICAgICAuYnV5e1xuICAgICAgICAgIGZsb2F0OnJpZ2h0O1xuICAgICAgICAgIHdpZHRoOiBjYWxjKDMwJSAtIDJweCk7XG4gICAgICAgICAgaGVpZ2h0OjEwMCU7XG4gICAgICAgICAgYmFja2dyb3VuZDogI2YxZjFmMTtcbiAgICAgICAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuNXM7XG4gICAgICAgICAgYm9yZGVyLWxlZnQ6c29saWQgdGhpbiByZ2JhKDAsMCwwLDAuMSk7XG4gICAgICAgICAgaXtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTozMHB4O1xuICAgICAgICAgICAgcGFkZGluZzozMHB4O1xuICAgICAgICAgICAgY29sb3I6ICMyNTQwNTM7XG4gICAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC41cztcbiAgICAgICAgICB9XG4gICAgICAgICAgJjpob3ZlcntcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNBNkNEREU7XG4gICAgICAgICAgfVxuICAgICAgICAgICY6aG92ZXIgaXtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSg1cHgpO1xuICAgICAgICAgICAgY29sb3I6IzAwMzk0QjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC5yaWdodHtcbiAgICAgICAgd2lkdGg6IDUwJTtcbiAgICAgICAgYmFja2dyb3VuZDogI0E2Q0RERTtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICBmbG9hdDpyaWdodDtcbiAgICAgICAgaGVpZ2h0OjIwMCU7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIC5kZXRhaWxze1xuICAgICAgICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICAgIHdpZHRoOiBjYWxjKDcwJSAtIDQwcHgpO1xuICAgICAgICB9XG4gICAgICAgIC5kb25le1xuICAgICAgICAgIHdpZHRoOiBjYWxjKDMwJSAtIDJweCk7XG4gICAgICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC41cztcbiAgICAgICAgICBib3JkZXItcmlnaHQ6c29saWQgdGhpbiByZ2JhKDI1NSwyNTUsMjU1LDAuMyk7XG4gICAgICAgICAgaGVpZ2h0OjUwJTtcbiAgICAgICAgICBpe1xuICAgICAgICAgICAgZm9udC1zaXplOjMwcHg7XG4gICAgICAgICAgICBwYWRkaW5nOjMwcHg7XG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC5yZW1vdmV7XG4gICAgICAgICAgd2lkdGg6IGNhbGMoMzAlIC0gMXB4KTtcbiAgICAgICAgICBjbGVhcjogYm90aDtcbiAgICAgICAgICBib3JkZXItcmlnaHQ6c29saWQgdGhpbiByZ2JhKDI1NSwyNTUsMjU1LDAuMyk7XG4gICAgICAgICAgaGVpZ2h0OjUwJTtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjMmFjMzM0O1xuICAgICAgICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjVzLCBiYWNrZ3JvdW5kIDAuNXM7XG4gICAgICAgICAgJjpob3ZlcntcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICMyOWMxNTQ7XG4gICAgICAgICAgfVxuICAgICAgICAgICY6aG92ZXIgaXtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSg1cHgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpe1xuICAgICAgICAgICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXM7XG4gICAgICAgICAgICBmb250LXNpemU6MzBweDtcbiAgICAgICAgICAgIHBhZGRpbmc6MzBweDtcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgJjpob3ZlcntcbiAgICAgICAgICAucmVtb3ZlLCAuZG9uZXtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMTAwJSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmluc2lkZXtcbiAgICB6LWluZGV4Ojk7XG4gICAgYmFja2dyb3VuZDogIzkyODc5QjtcbiAgICB3aWR0aDoxNDBweDtcbiAgICBoZWlnaHQ6MTQwcHg7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogLTcwcHg7XG4gICAgcmlnaHQ6IC03MHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMjAwcHggMjAwcHg7XG4gICAgdHJhbnNpdGlvbjogYWxsIDAuNXMsIGJvcmRlci1yYWRpdXMgMnMsIHRvcCAxcztcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIC5pY29ue1xuICAgICAgcG9zaXRpb246YWJzb2x1dGU7XG4gICAgICByaWdodDo4NXB4O1xuICAgICAgdG9wOjg1cHg7XG4gICAgICBjb2xvcjp3aGl0ZTtcbiAgICAgIG9wYWNpdHk6IDE7XG4gICAgfVxuICAgICY6aG92ZXJ7XG4gICAgICB3aWR0aDoxMDAlO1xuICAgICAgcmlnaHQ6MDtcbiAgICAgIHRvcDowO1xuICAgICAgYm9yZGVyLXJhZGl1czogMDtcbiAgICAgIGhlaWdodDo4MCU7XG4gICAgICAuaWNvbntcbiAgICAgICAgb3BhY2l0eTogMDtcbiAgICAgICAgcmlnaHQ6MTVweDtcbiAgICAgICAgdG9wOjE1cHg7XG4gICAgICB9XG4gICAgICAuY29udGVudHN7XG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLmNvbnRlbnRze1xuICAgICAgcGFkZGluZzogNSU7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjUpO1xuICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0yMDAlKTtcbiAgICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycywgdHJhbnNmb3JtIDAuOHM7XG4gICAgICB0YWJsZXtcbiAgICAgICAgdGV4dC1hbGlnbjpsZWZ0O1xuICAgICAgICB3aWR0aDoxMDAlO1xuICAgICAgfVxuICAgICAgaDEsIHAsIHRhYmxle1xuICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICB9XG4gICAgICBwe1xuICAgICAgICBmb250LXNpemU6MTNweDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuaW9uLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW57XG4gIGJhY2tncm91bmQ6ICNiNWY3Y2Y7XG5cdG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWNhbmplYWJsZXN7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5cblxuaW9uLWJ1dHRvbntcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA2MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDIwJSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSB7XG5cbiAgLmNvbnRlbmVkb3ItY2FyZHN7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXG4gICAgLmNhcmR7XG4gICAgICB3aWR0aDogODAlO1xuICAgICAgbWFyZ2luLWxlZnQ6IDEwJTtcbiAgICAgIGJhY2tncm91bmQtYXR0YWNobWVudDpzY3JvbGxcbiAgICB9XG4gIH1cblxuICAud3JhcHBlclxuICB7XG4gICAgbWFyZ2luLWxlZnQ6IDklO1xuICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAzMDBweCkgYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKSB7XG4gICAgLndyYXBwZXJcbiAgICB7XG4gICAgICBtYXJnaW4tbGVmdDogMiU7XG4gICAgfVxuICB9XG4iLCJodG1sLCBib2R5IHtcbiAgYmFja2dyb3VuZDogI0UzRTNEODtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gIHBhZGRpbmc6IDI1cHg7XG59XG5cbi8qIGNhcmRzICovXG4uY29udGVuZWRvci1jYXJkcyB7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5pbWFnZW4tY2FyZCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDM1MHB4O1xuICBiYWNrZ3JvdW5kOiBuby1yZXBlYXQgY2VudGVyO1xuICAtd2Via2l0LWJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIC1tb3otYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgLW8tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuLmNhcmQge1xuICB3aWR0aDogMzMzcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICM4YmMzNGEgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzhiYzM0YSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM4YmMzNGEgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIHRyYW5zaXRpb246IDJzO1xufVxuXG4uaW9uLWZhYi1idXR0b24tbm8tYWxjYW56YSB7XG4gIC0tYmFja2dyb3VuZDogZ3JheSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBncmF5ICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogZ3JheSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgdHJhbnNpdGlvbjogMnM7XG59XG5cbi5pb24tZmFiLWJ1dHRvbi1jb21wcmFkbyB7XG4gIC0tYmFja2dyb3VuZDogIzAwYzg1MyAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMDBjODUzIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDBjODUzICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICB0cmFuc2l0aW9uOiAycztcbn1cblxuLyogICAgKi9cbi5jb250ZW5lZG9yLXRhcmpldGEge1xuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xufVxuXG4udGFyamV0YSB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ud3JhcHBlciB7XG4gIHdpZHRoOiAzMDBweDtcbiAgaGVpZ2h0OiA1MDBweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIG1hcmdpbjogYXV0bztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAxMHB4IDEwcHg7XG4gIGJveC1zaGFkb3c6IDA7XG4gIHRyYW5zZm9ybTogc2NhbGUoMC45NSk7XG4gIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMC41cywgdHJhbnNmb3JtIDAuNXM7XG4gIG1hcmdpbi1sZWZ0OiBjYWxjKCgxMDAlIC0gMzAwcHgpLzIpO1xufVxuLndyYXBwZXI6aG92ZXIge1xuICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xuICBib3gtc2hhZG93OiA1cHggMjBweCAzMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcbn1cbi53cmFwcGVyIC5jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAudG9wIHtcbiAgaGVpZ2h0OiA4MCU7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiBuby1yZXBlYXQgY2VudGVyIGNlbnRlcjtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gIC1tb3otYmFja2dyb3VuZC1zaXplOiAxMDAlO1xuICAtby1iYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJTtcbn1cbi53cmFwcGVyIC5jb250YWluZXIgLmJvdHRvbSB7XG4gIHdpZHRoOiAyMDAlO1xuICBoZWlnaHQ6IDIwJTtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXM7XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20uY2xpY2tlZCB7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbn1cbi53cmFwcGVyIC5jb250YWluZXIgLmJvdHRvbSBoMSB7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMDtcbn1cbi53cmFwcGVyIC5jb250YWluZXIgLmJvdHRvbSBwIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5sZWZ0IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogNTAlO1xuICBiYWNrZ3JvdW5kOiAjZjRmNGY0O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZsb2F0OiBsZWZ0O1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5sZWZ0IC5kZXRhaWxzIHtcbiAgcGFkZGluZzogMjBweDtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHdpZHRoOiBjYWxjKDcwJSAtIDQwcHgpO1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5sZWZ0IC5idXkge1xuICBmbG9hdDogcmlnaHQ7XG4gIHdpZHRoOiBjYWxjKDMwJSAtIDJweCk7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogI2YxZjFmMTtcbiAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjVzO1xuICBib3JkZXItbGVmdDogc29saWQgdGhpbiByZ2JhKDAsIDAsIDAsIDAuMSk7XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLmxlZnQgLmJ1eSBpIHtcbiAgZm9udC1zaXplOiAzMHB4O1xuICBwYWRkaW5nOiAzMHB4O1xuICBjb2xvcjogIzI1NDA1MztcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXM7XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLmxlZnQgLmJ1eTpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICNBNkNEREU7XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLmxlZnQgLmJ1eTpob3ZlciBpIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDVweCk7XG4gIGNvbG9yOiAjMDAzOTRCO1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5yaWdodCB7XG4gIHdpZHRoOiA1MCU7XG4gIGJhY2tncm91bmQ6ICNBNkNEREU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBoZWlnaHQ6IDIwMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLnJpZ2h0IC5kZXRhaWxzIHtcbiAgcGFkZGluZzogMjBweDtcbiAgZmxvYXQ6IHJpZ2h0O1xuICB3aWR0aDogY2FsYyg3MCUgLSA0MHB4KTtcbn1cbi53cmFwcGVyIC5jb250YWluZXIgLmJvdHRvbSAucmlnaHQgLmRvbmUge1xuICB3aWR0aDogY2FsYygzMCUgLSAycHgpO1xuICBmbG9hdDogbGVmdDtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXM7XG4gIGJvcmRlci1yaWdodDogc29saWQgdGhpbiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMyk7XG4gIGhlaWdodDogNTAlO1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5yaWdodCAuZG9uZSBpIHtcbiAgZm9udC1zaXplOiAzMHB4O1xuICBwYWRkaW5nOiAzMHB4O1xuICBjb2xvcjogd2hpdGU7XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLnJpZ2h0IC5yZW1vdmUge1xuICB3aWR0aDogY2FsYygzMCUgLSAxcHgpO1xuICBjbGVhcjogYm90aDtcbiAgYm9yZGVyLXJpZ2h0OiBzb2xpZCB0aGluIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4zKTtcbiAgaGVpZ2h0OiA1MCU7XG4gIGJhY2tncm91bmQ6ICMyYWMzMzQ7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjVzLCBiYWNrZ3JvdW5kIDAuNXM7XG59XG4ud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLnJpZ2h0IC5yZW1vdmU6aG92ZXIge1xuICBiYWNrZ3JvdW5kOiAjMjljMTU0O1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5yaWdodCAucmVtb3ZlOmhvdmVyIGkge1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNXB4KTtcbn1cbi53cmFwcGVyIC5jb250YWluZXIgLmJvdHRvbSAucmlnaHQgLnJlbW92ZSBpIHtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXM7XG4gIGZvbnQtc2l6ZTogMzBweDtcbiAgcGFkZGluZzogMzBweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuLndyYXBwZXIgLmNvbnRhaW5lciAuYm90dG9tIC5yaWdodDpob3ZlciAucmVtb3ZlLCAud3JhcHBlciAuY29udGFpbmVyIC5ib3R0b20gLnJpZ2h0OmhvdmVyIC5kb25lIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xMDAlKTtcbn1cbi53cmFwcGVyIC5pbnNpZGUge1xuICB6LWluZGV4OiA5O1xuICBiYWNrZ3JvdW5kOiAjOTI4NzlCO1xuICB3aWR0aDogMTQwcHg7XG4gIGhlaWdodDogMTQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAtNzBweDtcbiAgcmlnaHQ6IC03MHB4O1xuICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDIwMHB4IDIwMHB4O1xuICB0cmFuc2l0aW9uOiBhbGwgMC41cywgYm9yZGVyLXJhZGl1cyAycywgdG9wIDFzO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLndyYXBwZXIgLmluc2lkZSAuaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDg1cHg7XG4gIHRvcDogODVweDtcbiAgY29sb3I6IHdoaXRlO1xuICBvcGFjaXR5OiAxO1xufVxuLndyYXBwZXIgLmluc2lkZTpob3ZlciB7XG4gIHdpZHRoOiAxMDAlO1xuICByaWdodDogMDtcbiAgdG9wOiAwO1xuICBib3JkZXItcmFkaXVzOiAwO1xuICBoZWlnaHQ6IDgwJTtcbn1cbi53cmFwcGVyIC5pbnNpZGU6aG92ZXIgLmljb24ge1xuICBvcGFjaXR5OiAwO1xuICByaWdodDogMTVweDtcbiAgdG9wOiAxNXB4O1xufVxuLndyYXBwZXIgLmluc2lkZTpob3ZlciAuY29udGVudHMge1xuICBvcGFjaXR5OiAxO1xuICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7XG59XG4ud3JhcHBlciAuaW5zaWRlIC5jb250ZW50cyB7XG4gIHBhZGRpbmc6IDUlO1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2Zvcm06IHNjYWxlKDAuNSk7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMjAwJSk7XG4gIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycywgdHJhbnNmb3JtIDAuOHM7XG59XG4ud3JhcHBlciAuaW5zaWRlIC5jb250ZW50cyB0YWJsZSB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHdpZHRoOiAxMDAlO1xufVxuLndyYXBwZXIgLmluc2lkZSAuY29udGVudHMgaDEsIC53cmFwcGVyIC5pbnNpZGUgLmNvbnRlbnRzIHAsIC53cmFwcGVyIC5pbnNpZGUgLmNvbnRlbnRzIHRhYmxlIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuLndyYXBwZXIgLmluc2lkZSAuY29udGVudHMgcCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tY2FuamVhYmxlcyB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA2MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDIwJSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSB7XG4gIC5jb250ZW5lZG9yLWNhcmRzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIH1cbiAgLmNvbnRlbmVkb3ItY2FyZHMgLmNhcmQge1xuICAgIHdpZHRoOiA4MCU7XG4gICAgbWFyZ2luLWxlZnQ6IDEwJTtcbiAgICBiYWNrZ3JvdW5kLWF0dGFjaG1lbnQ6IHNjcm9sbDtcbiAgfVxuXG4gIC53cmFwcGVyIHtcbiAgICBtYXJnaW4tbGVmdDogOSU7XG4gIH1cbn1cbkBtZWRpYSAobWluLXdpZHRoOiAzMDBweCkgYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKSB7XG4gIC53cmFwcGVyIHtcbiAgICBtYXJnaW4tbGVmdDogMiU7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/canjeables/canjeables.page.ts":
/*!***********************************************!*\
  !*** ./src/app/canjeables/canjeables.page.ts ***!
  \***********************************************/
/*! exports provided: CanjeablesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CanjeablesPage", function() { return CanjeablesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../_servicios/encuestas.service */ "./src/app/_servicios/encuestas.service.ts");
/* harmony import */ var _servicios_correos_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../_servicios/correos.service */ "./src/app/_servicios/correos.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");








let CanjeablesPage = class CanjeablesPage {
    constructor(localNotifications, correosService, sanitization, productoService, userService, alertController) {
        this.localNotifications = localNotifications;
        this.correosService = correosService;
        this.sanitization = sanitization;
        this.productoService = productoService;
        this.userService = userService;
        this.alertController = alertController;
        this.productos = [{ descripcion: '', titulo: "Silla bonita", puntos: 1500 }, { descripcion: '', titulo: "Silla fea", puntos: 1200 }, { descripcion: '', titulo: "Silla", puntos: 3500 }];
        this.clicked = [];
        this.imagenes = [];
        this.estados = [];
        this.usuario = JSON.parse(sessionStorage.getItem('usuario'));
        let userId = sessionStorage.getItem('userId');
        this.usuario = JSON.parse(sessionStorage.getItem('usuario'));
        productoService.listar().subscribe(datos => {
            for (let i = 0; i < datos.length; i++) {
                this.imagenes.push(sanitization.bypassSecurityTrustStyle(`url(${datos[i].url})`));
                this.estados.push(false);
            }
            this.productos = datos;
        });
        userService.gathering(userId).subscribe(datos => {
            this.usuario = datos;
        });
        console.log(this.usuario);
    }
    presentAlert(i, prod) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: '¿Deseas canjear?',
                subHeader: 'Estas a punto de canjear este producto',
                message: 'Al ser canjeado el producto se te van a descontar los puntos necesarios para conseguirlo.',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            this.enviarCorreo(prod);
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Canjear',
                        handler: () => {
                            this.cambiarEstilo(i);
                            this.usuario.puntos = this.usuario.puntos - prod.puntos;
                            this.usuario.password = undefined;
                            if (!this.usuario.canjeables) {
                                this.usuario.canjeables = [];
                            }
                            this.usuario.canjeables.push(prod);
                            this.userService.actualizar(this.usuario.id, this.usuario).subscribe(datos => {
                                console.log(datos);
                                sessionStorage.setItem('usuario', JSON.stringify(datos));
                                this.enviarCorreo(prod);
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enviarCorreo(prod) {
        var self = this;
        ;
        this.userService.listar().subscribe(datos => {
            var admin = datos[0];
            var email = admin.email;
            var usuario = this.usuario;
            var emailUsuario = usuario.email;
            var mAdmin = "El usuario " + usuario.firstName + " " + usuario.lastName + " ha canjeado " + prod.titulo;
            self.correosService.insertar(email, "Se ha canjeado un item", mAdmin).subscribe(datos => {
            });
            var mUsuario = "Has canjeado " + prod.titulo;
            self.correosService.insertar(emailUsuario, "Has canjeado un item", mUsuario).subscribe(datos => {
            });
            self.notificacion(prod);
        });
    }
    notificacion(prod) {
        this.localNotifications.schedule({
            text: '¡Has canjeado ' + prod.titulo + '!',
            //trigger: {at: new Date(new Date().getTime() + 3600)},
            led: 'FF0000',
            sound: null
        });
    }
    ngOnInit() {
        for (let i = 0; i < this.productos.length; i++) {
            this.clicked[i] = "";
        }
    }
    cambiarEstilo(i) {
        this.estados[i] = !this.estados[i];
    }
};
CanjeablesPage.ctorParameters = () => [
    { type: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_7__["LocalNotifications"] },
    { type: _servicios_correos_service__WEBPACK_IMPORTED_MODULE_5__["CorreosService"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] },
    { type: _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_4__["ProductoService"] },
    { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] }
];
CanjeablesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-canjeables',
        template: __webpack_require__(/*! raw-loader!./canjeables.page.html */ "./node_modules/raw-loader/index.js!./src/app/canjeables/canjeables.page.html"),
        styles: [__webpack_require__(/*! ./canjeables.page.scss */ "./src/app/canjeables/canjeables.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_7__["LocalNotifications"], _servicios_correos_service__WEBPACK_IMPORTED_MODULE_5__["CorreosService"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"], _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_4__["ProductoService"], _servicios_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]])
], CanjeablesPage);



/***/ })

}]);
//# sourceMappingURL=canjeables-canjeables-module-es2015.js.map