(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["evaluaciones-evaluaciones-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/evaluaciones.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluaciones/evaluaciones.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Evaluaciones</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerUsuarios($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-evaluaciones\" src=\"https://image.flaticon.com/icons/png/512/1570/1570567.png\">\n  </div>\n\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"!verAgregar\">\n    <ion-fab-button class=\"ion-fab\">\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n\n      <ion-fab-list side=\"start\">\n           <ion-fab-button (click)=\"abrirAyuda()\" *ngIf=\"!verAgregar\">\n             <ion-icon name=\"help\" ></ion-icon>\n           </ion-fab-button>\n      </ion-fab-list>\n\n    </ion-fab-list>\n\n  </ion-fab>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"verAgregar\">\n    <ion-fab-button (click)=\"redifinirUsuario();verAgregar = false;\" >\n      <ion-icon name=\"remove\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n    <b>Lista de usuarios</b>\n  </ion-item-divider>\n\n  <ion-item-sliding #slidingItem *ngFor=\"let usuario of usuarios\">\n    <ion-item (click)=\"mostrarHistorial(usuario.evaluaciones)\">\n      <div class=\"contenedor-card\">\n        <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/554/554846.png\">\n      </div>\n      <ion-label>&nbsp;&nbsp;{{usuario.firstName}} {{usuario.lastName}}</ion-label>\n    </ion-item>\n\n    <ion-item-options side=\"end\" >\n      <ion-item-option *ngFor=\"let ev of pendientes(usuario.evaluaciones);index as i\" (click)=\"evaluar(i,ev,usuario)\">{{ev.instrumento.sigla}}</ion-item-option>\n      <ion-item-option *ngIf=\"pendientes(usuario.evaluaciones).length == 0\"> <ion-icon name=\"checkmark\"> </ion-icon> </ion-item-option>\n\n    </ion-item-options>\n  </ion-item-sliding>\n\n  <h3 *ngIf=\"usuarios.length == 0\">No hay usuarios disponibles</h3>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/evaluaciones/evaluaciones-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/evaluaciones/evaluaciones-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: EvaluacionesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionesPageRoutingModule", function() { return EvaluacionesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _evaluaciones_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./evaluaciones.page */ "./src/app/evaluaciones/evaluaciones.page.ts");




var routes = [
    {
        path: '',
        component: _evaluaciones_page__WEBPACK_IMPORTED_MODULE_3__["EvaluacionesPage"]
    },
    {
        path: 'instrumento',
        loadChildren: function () { return __webpack_require__.e(/*! import() | instrumento-instrumento-module */ "instrumento-instrumento-module").then(__webpack_require__.bind(null, /*! ./instrumento/instrumento.module */ "./src/app/evaluaciones/instrumento/instrumento.module.ts")).then(function (m) { return m.InstrumentoPageModule; }); }
    },
    {
        path: 'historial',
        loadChildren: function () { return __webpack_require__.e(/*! import() | historial-historial-module */ "historial-historial-module").then(__webpack_require__.bind(null, /*! ./historial/historial.module */ "./src/app/evaluaciones/historial/historial.module.ts")).then(function (m) { return m.HistorialPageModule; }); }
    }
];
var EvaluacionesPageRoutingModule = /** @class */ (function () {
    function EvaluacionesPageRoutingModule() {
    }
    EvaluacionesPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], EvaluacionesPageRoutingModule);
    return EvaluacionesPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/evaluaciones/evaluaciones.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/evaluaciones/evaluaciones.module.ts ***!
  \*****************************************************/
/*! exports provided: EvaluacionesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionesPageModule", function() { return EvaluacionesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _evaluaciones_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./evaluaciones-routing.module */ "./src/app/evaluaciones/evaluaciones-routing.module.ts");
/* harmony import */ var _evaluaciones_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./evaluaciones.page */ "./src/app/evaluaciones/evaluaciones.page.ts");







var EvaluacionesPageModule = /** @class */ (function () {
    function EvaluacionesPageModule() {
    }
    EvaluacionesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _evaluaciones_routing_module__WEBPACK_IMPORTED_MODULE_5__["EvaluacionesPageRoutingModule"]
            ],
            declarations: [_evaluaciones_page__WEBPACK_IMPORTED_MODULE_6__["EvaluacionesPage"]]
        })
    ], EvaluacionesPageModule);
    return EvaluacionesPageModule;
}());



/***/ }),

/***/ "./src/app/evaluaciones/evaluaciones.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/evaluaciones/evaluaciones.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  text-align: center;\n  --background: #7A9FCC;\n  --color:white;\n}\n\n.contenedor-imagen {\n  background: #7A9FCC;\n  margin-bottom: 5%;\n}\n\n.imagen-evaluaciones {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n\n.contenedor-descripcion {\n  text-align: center;\n  width: 90%;\n  margin-top: 5%;\n  margin-left: 5%;\n  margin-bottom: 5%;\n}\n\n.seccion-secciones {\n  display: -webkit-box;\n  display: flex;\n  margin-top: 2.5%;\n}\n\n.seccion-preguntas {\n  width: 70%;\n}\n\n.pregunta {\n  margin-left: 5% !important;\n}\n\n.seccion-estrellas {\n  width: 30%;\n}\n\n.seccion-estrellas ion-badge {\n  margin-left: 1.5%;\n  --background: transparent;\n  --color: #424242;\n}\n\n.seccion-estrellas .icono {\n  width: 25px;\n  height: 25px;\n}\n\n.seccion-estrellas .cambiador {\n  color: #ffd600;\n}\n\n.ion-item {\n  --border-color: transparent;\n}\n\n.ion-button {\n  --background: #7A9FCC;\n  --background-activated: #7A9FCC;\n  --background-hover: #7A9FCC;\n  width: 70% !important;\n  margin-left: 15% !important;\n  margin-top: 10%;\n  margin-bottom: 10%;\n}\n\n.ion-fab {\n  --background: #89a5c7;\n  --background-hover: #89a5c7;\n  --background-activated: #89a5c7;\n  --background-focused: #89a5c7;\n}\n\n@media (max-width: 550px) {\n  .seccion-secciones {\n    display: inline !important;\n    margin-top: 2.5%;\n  }\n\n  .seccion-preguntas {\n    margin-top: 5%;\n    margin-left: 0% !important;\n    width: 100%;\n    text-align: center !important;\n  }\n\n  .pregunta {\n    margin-top: 10% !important;\n    margin-left: 0% !important;\n  }\n\n  .seccion-estrellas {\n    margin-top: 5%;\n    width: 50% !important;\n    margin-left: 25%;\n  }\n  .seccion-estrellas ion-badge {\n    margin-left: 1.5%;\n    margin-left: 1.5%;\n    --background: transparent;\n    --color: #424242;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbmVzL2V2YWx1YWNpb25lcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2V2YWx1YWNpb25lcy9ldmFsdWFjaW9uZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7QUNDSjs7QURDRTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNFSDs7QURDRTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0VKOztBREFFO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNHSjs7QURERTtFQUVFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNHSjs7QURJRTtFQUNFLG9CQUFBO0VBQUEsYUFBQTtFQUNBLGdCQUFBO0FDREo7O0FER0U7RUFDRSxVQUFBO0FDQUo7O0FER0U7RUFDRSwwQkFBQTtBQ0FKOztBREdFO0VBQ0UsVUFBQTtBQ0FKOztBRENJO0VBQ0UsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FDQ047O0FERUk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ0FOOztBREdJO0VBQ0UsY0FBQTtBQ0ROOztBRE1FO0VBQ0UsMkJBQUE7QUNISjs7QURNRTtFQUNFLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNISjs7QURNRTtFQUNFLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0FDSEo7O0FET0U7RUFFRTtJQUNFLDBCQUFBO0lBQ0EsZ0JBQUE7RUNMSjs7RURRRTtJQUNFLGNBQUE7SUFDQSwwQkFBQTtJQUNBLFdBQUE7SUFDQSw2QkFBQTtFQ0xKOztFRFFFO0lBQ0UsMEJBQUE7SUFDQSwwQkFBQTtFQ0xKOztFRFFFO0lBQ0UsY0FBQTtJQUNBLHFCQUFBO0lBQ0EsZ0JBQUE7RUNMSjtFRE1JO0lBQ0UsaUJBQUE7SUFDQSxpQkFBQTtJQUNBLHlCQUFBO0lBQ0EsZ0JBQUE7RUNKTjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvZXZhbHVhY2lvbmVzL2V2YWx1YWNpb25lcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAgIC0tY29sb3I6d2hpdGU7XG4gIH1cbiAgLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICAgIGJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIFx0bWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cblxuICAuaW1hZ2VuLWV2YWx1YWNpb25lc3tcbiAgICB3aWR0aDogMjAlO1xuICAgIG1hcmdpbi1sZWZ0OiA0MCU7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cbiAgLmltYWdlbi1jYXJke1xuICAgIHdpZHRoOiA1MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tdG9wOiAwJTtcbiAgICBtYXJnaW4tYm90dG9tOiAwJTtcbiAgfVxuICAuY29udGVuZWRvci1kZXNjcmlwY2lvblxuICB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiA5MCU7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICB9XG5cbiAgLmRlc2NyaXBjaW9ue1xuXG4gIH1cblxuICAuc2VjY2lvbi1zZWNjaW9uZXN7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBtYXJnaW4tdG9wOiAyLjUlO1xuICB9XG4gIC5zZWNjaW9uLXByZWd1bnRhc3tcbiAgICB3aWR0aDogNzAlO1xuICB9XG5cbiAgLnByZWd1bnRhe1xuICAgIG1hcmdpbi1sZWZ0OiA1JSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnNlY2Npb24tZXN0cmVsbGFze1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaW9uLWJhZGdle1xuICAgICAgbWFyZ2luLWxlZnQ6IDEuNSU7XG4gICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgLS1jb2xvcjogIzQyNDI0MjtcbiAgICB9XG5cbiAgICAuaWNvbm97XG4gICAgICB3aWR0aDogMjVweDtcbiAgICAgIGhlaWdodDogMjVweDtcbiAgICB9XG5cbiAgICAuY2FtYmlhZG9ye1xuICAgICAgY29sb3I6ICNmZmQ2MDA7XG4gICAgfVxuXG4gIH1cblxuICAuaW9uLWl0ZW17XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG5cbiAgLmlvbi1idXR0b257XG4gICAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICM3QTlGQ0M7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjN0E5RkNDO1xuICAgIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLXRvcDogMTAlO1xuICAgIG1hcmdpbi1ib3R0b206IDEwJTtcbiAgfVxuXG4gIC5pb24tZmFie1xuICAgIC0tYmFja2dyb3VuZDogIzg5YTVjNztcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6ICM4OWE1Yzc7XG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzg5YTVjNztcbiAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogIzg5YTVjNztcbiAgfVxuXG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU1MHB4KSB7XG5cbiAgICAuc2VjY2lvbi1zZWNjaW9uZXN7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUgIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi10b3A6IDIuNSU7XG4gICAgfVxuXG4gICAgLnNlY2Npb24tcHJlZ3VudGFze1xuICAgICAgbWFyZ2luLXRvcDogNSU7XG4gICAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgLnByZWd1bnRhe1xuICAgICAgbWFyZ2luLXRvcDogMTAlICFpbXBvcnRhbnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuc2VjY2lvbi1lc3RyZWxsYXN7XG4gICAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICAgIHdpZHRoOiA1MCUgIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAyNSU7XG4gICAgICBpb24tYmFkZ2V7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxLjUlO1xuICAgICAgICBtYXJnaW4tbGVmdDogMS41JTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1jb2xvcjogIzQyNDI0MjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiIsImlvbi10b29sYmFyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtLWJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIC0tY29sb3I6d2hpdGU7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICM3QTlGQ0M7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWV2YWx1YWNpb25lcyB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1jYXJkIHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG4uY29udGVuZWRvci1kZXNjcmlwY2lvbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDkwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5zZWNjaW9uLXNlY2Npb25lcyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi10b3A6IDIuNSU7XG59XG5cbi5zZWNjaW9uLXByZWd1bnRhcyB7XG4gIHdpZHRoOiA3MCU7XG59XG5cbi5wcmVndW50YSB7XG4gIG1hcmdpbi1sZWZ0OiA1JSAhaW1wb3J0YW50O1xufVxuXG4uc2VjY2lvbi1lc3RyZWxsYXMge1xuICB3aWR0aDogMzAlO1xufVxuLnNlY2Npb24tZXN0cmVsbGFzIGlvbi1iYWRnZSB7XG4gIG1hcmdpbi1sZWZ0OiAxLjUlO1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiAjNDI0MjQyO1xufVxuLnNlY2Npb24tZXN0cmVsbGFzIC5pY29ubyB7XG4gIHdpZHRoOiAyNXB4O1xuICBoZWlnaHQ6IDI1cHg7XG59XG4uc2VjY2lvbi1lc3RyZWxsYXMgLmNhbWJpYWRvciB7XG4gIGNvbG9yOiAjZmZkNjAwO1xufVxuXG4uaW9uLWl0ZW0ge1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjN0E5RkNDO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM3QTlGQ0M7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiAxMCU7XG4gIG1hcmdpbi1ib3R0b206IDEwJTtcbn1cblxuLmlvbi1mYWIge1xuICAtLWJhY2tncm91bmQ6ICM4OWE1Yzc7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzg5YTVjNztcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzg5YTVjNztcbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICM4OWE1Yzc7XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiA1NTBweCkge1xuICAuc2VjY2lvbi1zZWNjaW9uZXMge1xuICAgIGRpc3BsYXk6IGlubGluZSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi10b3A6IDIuNSU7XG4gIH1cblxuICAuc2VjY2lvbi1wcmVndW50YXMge1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1sZWZ0OiAwJSAhaW1wb3J0YW50O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnByZWd1bnRhIHtcbiAgICBtYXJnaW4tdG9wOiAxMCUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5zZWNjaW9uLWVzdHJlbGxhcyB7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgd2lkdGg6IDUwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1sZWZ0OiAyNSU7XG4gIH1cbiAgLnNlY2Npb24tZXN0cmVsbGFzIGlvbi1iYWRnZSB7XG4gICAgbWFyZ2luLWxlZnQ6IDEuNSU7XG4gICAgbWFyZ2luLWxlZnQ6IDEuNSU7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAtLWNvbG9yOiAjNDI0MjQyO1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/evaluaciones/evaluaciones.page.ts":
/*!***************************************************!*\
  !*** ./src/app/evaluaciones/evaluaciones.page.ts ***!
  \***************************************************/
/*! exports provided: EvaluacionesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionesPage", function() { return EvaluacionesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./instrumento/instrumento.page */ "./src/app/evaluaciones/instrumento/instrumento.page.ts");
/* harmony import */ var _historial_historial_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./historial/historial.page */ "./src/app/evaluaciones/historial/historial.page.ts");






var EvaluacionesPage = /** @class */ (function () {
    function EvaluacionesPage(modalCtrl, userService) {
        var _this = this;
        this.modalCtrl = modalCtrl;
        this.userService = userService;
        this.usuarios = [];
        userService.listar().subscribe(function (usuarios) {
            _this.usuarios = usuarios;
            console.log(usuarios);
        });
    }
    EvaluacionesPage.prototype.ngOnInit = function () {
    };
    EvaluacionesPage.prototype.dismiss = function () {
        this.modalCtrl.dismiss();
    };
    EvaluacionesPage.prototype.mostrarHistorial = function (evaluaciones) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _historial_historial_page__WEBPACK_IMPORTED_MODULE_5__["HistorialPage"],
                            cssClass: 'modals',
                            componentProps: { evaluaciones: evaluaciones },
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (datos) {
                            console.log(datos);
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EvaluacionesPage.prototype.traerUsuarios = function (evento) {
        var _this = this;
        this.userService.listar().subscribe(function (usuarios) {
            console.log(usuarios);
            _this.usuarios = usuarios;
            if (evento) {
                evento.target.complete();
            }
        });
    };
    EvaluacionesPage.prototype.pendientes = function (evaluaciones) {
        var evs = [];
        for (var i = 0; i < evaluaciones.length; i++) {
            if (evaluaciones[i].estado == 0) {
                evs.push(evaluaciones[i]);
            }
        }
        return evs;
    };
    EvaluacionesPage.prototype.evaluar = function (i, evaluacion, usuario) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(i);
                        console.log(evaluacion);
                        console.log(usuario);
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_4__["InstrumentoPage"],
                                cssClass: 'modals',
                                componentProps: {
                                    'evaluacion': evaluacion.instrumento,
                                    //'indicadores':evaluacion.instrumento.indicadores,
                                    'usuario': usuario
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                evaluacion.instrumento.indicadores = modal.data.indicadores;
                                var valorTotal = 0;
                                var cantidad = evaluacion.instrumento.indicadores.length;
                                for (var i_1 = 0; i_1 < cantidad; i_1++) {
                                    var indicador = evaluacion.instrumento.indicadores[i_1];
                                    valorTotal += indicador.valor;
                                }
                                var porcentaje = valorTotal / cantidad;
                                var puntos = evaluacion.puntos * (porcentaje / 100);
                                puntos = Math.round(puntos);
                                evaluacion.estado = 1;
                                usuario.password = undefined;
                                if (usuario.puntos) {
                                    usuario.puntos += puntos;
                                }
                                else {
                                    usuario.puntos = puntos;
                                }
                                console.log(usuario);
                                var usuarioSistema = JSON.parse(sessionStorage.getItem('usuario'));
                                if (usuario.id == usuarioSistema.id) {
                                    sessionStorage.setItem("usuario", JSON.stringify(usuario));
                                }
                                _this.userService.actualizar(usuario._id, usuario).subscribe(function (res) {
                                    console.log(res);
                                });
                                console.log(modal.data);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EvaluacionesPage.prototype.abrirAyuda = function () {
        alert("aqui se crean evaluaciones");
    };
    EvaluacionesPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"] }
    ]; };
    EvaluacionesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-evaluaciones',
            template: __webpack_require__(/*! raw-loader!./evaluaciones.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluaciones/evaluaciones.page.html"),
            styles: [__webpack_require__(/*! ./evaluaciones.page.scss */ "./src/app/evaluaciones/evaluaciones.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"]])
    ], EvaluacionesPage);
    return EvaluacionesPage;
}());



/***/ })

}]);
//# sourceMappingURL=evaluaciones-evaluaciones-module-es5.js.map