(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["perfil-perfil-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/perfil/perfil.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/perfil/perfil.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Rendimiento Personal</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-perfil\" src=\"https://image.flaticon.com/icons/png/512/1055/1055654.png\">\n    <div class=\"contenedor-estadisticas\">\n    </div>\n  </div>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col (click)=\"navegar('canjeables')\">\n        <ion-card class=\"card-naranjo\" style=\"text-align:center;\" (click)=\"navegar('canjeables')\">\n          <div class=\"contenedor-naranjo\" (click)=\"navegar('canjeables')\">\n            <img class=\"imagen-home\" src=\"https://image.flaticon.com/icons/svg/679/679938.svg\">\n          </div>\n          <ion-card-header (click)=\"navegar('canjeables')\">\n            <ion-card-title color=\"blanco\">Tus puntos</ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content style=\"font-size:50px\" (click)=\"navegar('canjeables')\">\n            <b>{{ (usuario.puntos|| \"0\") }}</b>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n\n      <ion-col>\n        <ion-card class=\"card-naranjo\" style=\"text-align:center;\" (click)=\"verEncuestas()\">\n          <div class=\"contenedor-naranjo\">\n            <img class=\"imagen-home\" src=\"https://image.flaticon.com/icons/svg/1475/1475107.svg\">\n          </div>\n          <ion-card-header>\n            <ion-card-title color=\"blanco\">Encuestas</ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content style=\"font-size:50px\">\n            <b>{{ (usuario.encuestas.length|| \"Sin datos\") }}</b>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n      <ion-col>\n        <ion-card class=\"card-celeste\" style=\"text-align:center;\" (click)=\"verEvaluaciones()\">\n          <div class=\"contenedor-celeste\">\n            <img class=\"imagen-home\" src=\"https://image.flaticon.com/icons/svg/1790/1790014.svg\">\n          </div>\n          <ion-card-header>\n            <ion-card-title color=\"blanco\">Evaluaciones</ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content style=\"font-size:50px\">\n            <b>{{ (usuario.evaluaciones.length|| \"Sin datos\") }}</b>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/perfil/perfil-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/perfil/perfil-routing.module.ts ***!
  \*************************************************/
/*! exports provided: PerfilPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerfilPageRoutingModule", function() { return PerfilPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _perfil_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./perfil.page */ "./src/app/perfil/perfil.page.ts");




const routes = [
    {
        path: '',
        component: _perfil_page__WEBPACK_IMPORTED_MODULE_3__["PerfilPage"]
    }
];
let PerfilPageRoutingModule = class PerfilPageRoutingModule {
};
PerfilPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PerfilPageRoutingModule);



/***/ }),

/***/ "./src/app/perfil/perfil.module.ts":
/*!*****************************************!*\
  !*** ./src/app/perfil/perfil.module.ts ***!
  \*****************************************/
/*! exports provided: PerfilPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerfilPageModule", function() { return PerfilPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _perfil_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./perfil-routing.module */ "./src/app/perfil/perfil-routing.module.ts");
/* harmony import */ var _perfil_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./perfil.page */ "./src/app/perfil/perfil.page.ts");







let PerfilPageModule = class PerfilPageModule {
};
PerfilPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _perfil_routing_module__WEBPACK_IMPORTED_MODULE_5__["PerfilPageRoutingModule"]
        ],
        declarations: [_perfil_page__WEBPACK_IMPORTED_MODULE_6__["PerfilPage"]]
    })
], PerfilPageModule);



/***/ }),

/***/ "./src/app/perfil/perfil.page.scss":
/*!*****************************************!*\
  !*** ./src/app/perfil/perfil.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #7A9FCC;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\nion-toolbar ion-item {\n  --background: transparent;\n  --border-color: transparent;\n  color: white;\n  width: 100%;\n  height: 10%;\n}\nion-toolbar .badge-canje {\n  background: transparent;\n  width: 40px;\n}\n.contenedor-imagen {\n  background: #7A9FCC;\n}\n.contenedor-estadisticas {\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n}\n.imagen-home {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n.contenedor-azul {\n  background: #1F3E7D;\n}\n.card-azul {\n  --background: #1F3E7D ;\n  --color: white !important;\n  border-radius: 30px;\n}\n.contenedor-naranjo {\n  background: #1F3E7D;\n}\n.card-naranjo {\n  --background: #1F3E7D ;\n  --color: white !important;\n  border-radius: 30px;\n}\n.contenedor-celeste {\n  background: #1F3E7D;\n}\n.card-celeste {\n  --background: #1F3E7D ;\n  --color: white !important;\n  border-radius: 30px;\n}\n.contenedor-card {\n  --background: #3949ab;\n  --color: white !important;\n}\n.imagen-perfil {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n.contenedor-card {\n  --background: #ff5252;\n  --color: white !important;\n}\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n.ion-title {\n  text-align: center;\n  margin-top: 3.5%;\n  font-size: 24px;\n}\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\nion-card {\n  --background: white;\n}\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n.contenedor-datos {\n  background: #ff5252;\n  height: 9%;\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n}\n.nombre-perfil {\n  height: 100%;\n  width: 35%;\n}\n.cupones-perfil {\n  height: 100%;\n  width: 35%;\n  display: -webkit-box;\n  display: flex;\n}\n.texto-perfil {\n  color: white;\n  align-text: center;\n  margin-top: 3.5%;\n  margin-left: 8%;\n  font-size: 20px;\n}\n@media (max-width: 900px) {\n  .nombre-perfil {\n    width: 100% !important;\n  }\n\n  .cupones-perfil {\n    width: 100% !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvcGVyZmlsL3BlcmZpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BlcmZpbC9wZXJmaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNBRjtBREVFO0VBQ0UseUJBQUE7RUFDQSwyQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQ0FKO0FER0U7RUFDRSx1QkFBQTtFQUNBLFdBQUE7QUNESjtBRFdBO0VBQ0UsbUJBQUE7QUNURjtBRFlBO0VBQ0UsV0FBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ1RGO0FEWUE7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNURjtBRFlBO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNURjtBRFlBO0VBQ0UsbUJBQUE7QUNURjtBRGFBO0VBQ0Usc0JBQUE7RUFFQSx5QkFBQTtFQUNBLG1CQUFBO0FDWEY7QURjQTtFQUNFLG1CQUFBO0FDWEY7QURlQTtFQUNFLHNCQUFBO0VBRUEseUJBQUE7RUFDQSxtQkFBQTtBQ2JGO0FEZ0JBO0VBQ0UsbUJBQUE7QUNiRjtBRGlCQTtFQUNFLHNCQUFBO0VBRUEseUJBQUE7RUFDQSxtQkFBQTtBQ2ZGO0FEa0JBO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtBQ2ZGO0FEa0JBO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FDZkY7QURrQkE7RUFDRSxxQkFBQTtFQUNBLHlCQUFBO0FDZkY7QURrQkE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ2ZGO0FEa0JBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNmRjtBRGtCQTtFQUFTOzs7R0FBQTtFQUlQLDRCQUFBO0VBQ0EsMEJBQUE7QUNkRjtBRGlCQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQ1ZGO0FEaUJBO0VBQ0UsbUJBQUE7QUNkRjtBRGlCQTtFQUNFLG9GQUFBO0FDZEY7QURlRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDYkY7QURpQkE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDZEY7QURpQkE7RUFDRSxpQ0FBQTtBQ2RGO0FEaUJBO0VBQ0UsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ2RGO0FEaUJBO0VBQ0UsWUFBQTtFQUNBLFVBQUE7QUNkRjtBRGlCQTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0FDZEY7QURpQkE7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDZEY7QURpQkE7RUFLRTtJQUNFLHNCQUFBO0VDbEJGOztFRHFCQTtJQUNFLHNCQUFBO0VDbEJGO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9wZXJmaWwvcGVyZmlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICBpb24taXRlbXtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMCU7XG4gIH1cblxuICAuYmFkZ2UtY2FuamV7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgd2lkdGg6IDQwcHg7XG5cbiAgICAuaW1hZ2VuLWNhbmplc1xuICAgIHtcblxuICAgIH1cbiAgfVxuXG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgYmFja2dyb3VuZDogIzdBOUZDQztcbn1cblxuLmNvbnRlbmVkb3ItZXN0YWRpc3RpY2Fze1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmltYWdlbi1ob21le1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tY2FyZHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG4uY29udGVuZWRvci1henVse1xuICBiYWNrZ3JvdW5kOiAjMUYzRTdEXG47XG59XG5cbi5jYXJkLWF6dWx7XG4gIC0tYmFja2dyb3VuZDogIzFGM0U3RFxuO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuXG4uY29udGVuZWRvci1uYXJhbmpve1xuICBiYWNrZ3JvdW5kOiAjMUYzRTdEXG47XG59XG5cbi5jYXJkLW5hcmFuam97XG4gIC0tYmFja2dyb3VuZDogIzFGM0U3RFxuO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuXG4uY29udGVuZWRvci1jZWxlc3Rle1xuICBiYWNrZ3JvdW5kOiAjMUYzRTdEXG47XG59XG5cbi5jYXJkLWNlbGVzdGV7XG4gIC0tYmFja2dyb3VuZDogIzFGM0U3RFxuO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuXG4uY29udGVuZWRvci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi5pbWFnZW4tcGVyZmlse1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5jb250ZW5lZG9yLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogI2ZmNTI1MjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLmltYWdlbi1jYXJke1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luLWxlZnQ6IDAlO1xuICBtYXJnaW4tdG9wOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbi5pb24tdGl0bGV7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMy41JTtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuXG5pb24taXRlbXsvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWJ7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuLmNvbnRlbmVkb3ItZGF0b3N7XG4gIGJhY2tncm91bmQ6I2ZmNTI1MjtcbiAgaGVpZ2h0OjklO1xuICB3aWR0aDoxMDAlO1xuICBkaXNwbGF5OmZsZXg7XG59XG5cbi5ub21icmUtcGVyZmlse1xuICBoZWlnaHQ6MTAwJTtcbiAgd2lkdGg6MzUlO1xufVxuXG4uY3Vwb25lcy1wZXJmaWx7XG4gIGhlaWdodDoxMDAlO1xuICB3aWR0aDozNSU7XG4gIGRpc3BsYXk6ZmxleDtcbn1cblxuLnRleHRvLXBlcmZpbHtcbiAgY29sb3I6d2hpdGU7XG4gIGFsaWduLXRleHQ6IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDozLjUlO1xuICBtYXJnaW4tbGVmdDo4JTtcbiAgZm9udC1zaXplOjIwcHg7XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiA5MDBweCkge1xuICAuY29udGVuZWRvci1kYXRvc3tcblxuICB9XG5cbiAgLm5vbWJyZS1wZXJmaWx7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jdXBvbmVzLXBlcmZpbHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG59XG4iLCJpb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjN0E5RkNDO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuaW9uLXRvb2xiYXIgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAlO1xufVxuaW9uLXRvb2xiYXIgLmJhZGdlLWNhbmplIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIHdpZHRoOiA0MHB4O1xufVxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogIzdBOUZDQztcbn1cblxuLmNvbnRlbmVkb3ItZXN0YWRpc3RpY2FzIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5pbWFnZW4taG9tZSB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1jYXJkIHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG4uY29udGVuZWRvci1henVsIHtcbiAgYmFja2dyb3VuZDogIzFGM0U3RDtcbn1cblxuLmNhcmQtYXp1bCB7XG4gIC0tYmFja2dyb3VuZDogIzFGM0U3RCA7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG59XG5cbi5jb250ZW5lZG9yLW5hcmFuam8ge1xuICBiYWNrZ3JvdW5kOiAjMUYzRTdEO1xufVxuXG4uY2FyZC1uYXJhbmpvIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMUYzRTdEIDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbn1cblxuLmNvbnRlbmVkb3ItY2VsZXN0ZSB7XG4gIGJhY2tncm91bmQ6ICMxRjNFN0Q7XG59XG5cbi5jYXJkLWNlbGVzdGUge1xuICAtLWJhY2tncm91bmQ6ICMxRjNFN0QgO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuXG4uY29udGVuZWRvci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMzk0OWFiO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG4uaW1hZ2VuLXBlcmZpbCB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmNvbnRlbmVkb3ItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogI2ZmNTI1MjtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLmltYWdlbi1jYXJkIHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG4uaW9uLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAzLjUlO1xuICBmb250LXNpemU6IDI0cHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYiB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuLmNvbnRlbmVkb3ItZGF0b3Mge1xuICBiYWNrZ3JvdW5kOiAjZmY1MjUyO1xuICBoZWlnaHQ6IDklO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLm5vbWJyZS1wZXJmaWwge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAzNSU7XG59XG5cbi5jdXBvbmVzLXBlcmZpbCB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDM1JTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLnRleHRvLXBlcmZpbCB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYWxpZ24tdGV4dDogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAzLjUlO1xuICBtYXJnaW4tbGVmdDogOCU7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XG4gIC5ub21icmUtcGVyZmlsIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmN1cG9uZXMtcGVyZmlsIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/perfil/perfil.page.ts":
/*!***************************************!*\
  !*** ./src/app/perfil/perfil.page.ts ***!
  \***************************************/
/*! exports provided: PerfilPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerfilPage", function() { return PerfilPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _list_list_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../list/list.page */ "./src/app/list/list.page.ts");






let PerfilPage = class PerfilPage {
    constructor(router, modalCtrl, userService) {
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.userService = userService;
        this.usuario = { encuestas: [], evaluaciones: [], canjeables: [] };
        let userId = sessionStorage.getItem('userId');
        userService.gathering(userId).subscribe(usuario => {
            this.usuario = usuario;
        });
    }
    navegar(ruta) {
        console.log("navega a " + ruta);
        this.router.navigate([ruta]);
    }
    ngOnInit() {
    }
    verEvaluaciones() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _list_list_page__WEBPACK_IMPORTED_MODULE_5__["ListPage"],
                cssClass: 'modals'
            });
            return yield modal.present();
        });
    }
    verEncuestas() {
    }
};
PerfilPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"] }
];
PerfilPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-perfil',
        template: __webpack_require__(/*! raw-loader!./perfil.page.html */ "./node_modules/raw-loader/index.js!./src/app/perfil/perfil.page.html"),
        styles: [__webpack_require__(/*! ./perfil.page.scss */ "./src/app/perfil/perfil.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        _servicios_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"]])
], PerfilPage);



/***/ })

}]);
//# sourceMappingURL=perfil-perfil-module-es2015.js.map