(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n  <ion-toolbar>\n   <ion-buttons slot=\"start\">\n     <ion-menu-button color=\"light\"></ion-menu-button>\n   </ion-buttons>\n   <ion-title color=\"blanco\">\n     Home - {{(asignado.name || \"Aun sin asignar\")}}\n   </ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerDatos($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n   <!--\n  <div class=\"contenedor-imagen\" style=' background : url(\"http://localhost:8100/assets/icon/fondo-azul.svg\") no repeat'>\n    <img class=\"imagen-mancha\" src=\"http://localhost:8100/assets/icon/mancha-verde-oscuro.svg\">\n    <div class=\"contenedor-logo\">\n      <img class=\"imagen-logo\" src=\"http://localhost:8100/assets/icon/LOGO IFORT-02.svg\">\n    </div>\n  </div>\n\n  <!--<div class=\"contenedor-imagen\">\n    <img class=\"imagen-home\" src=\"assets/icon/LOGO IFORT-02.png\">\n  </div>-->\n  <div class=\"grilla contenedor-imagen\" style=' background : url(\"http://167.71.162.34/assets/icon/fondo1.svg\") , #3E55A1'>\n    <div class=\"contenedor-logo\">\n      <img class=\"imagen-logo\" src=\"assets/icon/LOGO IFORT-02.svg\">\n    </div>\n  </div>\n<div class=\"contenedor-cards\">\n  <div class=\"card-derecha\">\n    <ion-card class=\"ion-card-derecha\" style=\"text-align:center;\" (click)=\"verEvaluacion(getPersonalEvaluation())\">\n      <ion-card-header>\n        <ion-card-title color=\"blanco\" *ngIf=\"!isAdmin\">Rendimiento actual personal </ion-card-title>\n        <ion-card-title color=\"blanco\" *ngIf=\"isAdmin\">Promedio de rendimiento general</ion-card-title>\n      </ion-card-header>\n      <circle-progress\n        [percent]=obtenDatos()\n        [radius]=\"100\"\n        [outerStrokeWidth]=\"16\"\n        [innerStrokeWidth]=\"8\"\n        [backgroundOpacity] = \"0\"\n        [space] = \"11\"\n        [showUnits] = true\n        [toFixed] = \"1\"\n        [maxPercent] = \"320\"\n        [innerStrokeColor] = \"'#3a68e5'\"\n        [titleFontSize] = \"35\"\n        [animationDuration] =  \"800\"\n        [showSubtitle] = false\n        [titleColor] = \"'#ffffff'\"\n      ></circle-progress>\n    </ion-card>\n  </div>\n  <div class=\"card-centro\">\n    <ion-card class=\"ion-card-centro\" style=\"text-align:center;\" (click)=\"verEncuestas()\">\n      <div class=\"contenedor-naranjo\">\n        <img class=\"imagen-home\" src=\"https://image.flaticon.com/icons/svg/1475/1475107.svg\">\n      </div>\n      <ion-card-header>\n        <ion-card-title class=\"texto-encuestas\" color=\"blanco\" *ngIf=\"!isAdmin\">Encuestas</ion-card-title>\n      </ion-card-header>\n\n      <ion-card-content style=\"font-size:50px\">\n        <b *ngIf=\"!isAdmin\">{{ (usuario.encuestas.length|| \"Sin datos\") }}</b>\n        <b class=\"texto-encuestas\" *ngIf=\"isAdmin\">Encuestas</b>\n      </ion-card-content>\n    </ion-card>\n  </div>\n  <div class=\"card-izquierda\">\n    <ion-card class=\"ion-card-izquierda\" style=\"text-align:center;\" (click)=\"verEvaluaciones()\">\n      <div class=\"contenedor-celeste\">\n        <img class=\"imagen-home\" src=\"https://image.flaticon.com/icons/svg/1790/1790014.svg\">\n      </div>\n      <ion-card-header>\n        <ion-card-title color=\"blanco\" *ngIf=\"!isAdmin\">Evaluaciones</ion-card-title>\n      </ion-card-header>\n\n      <ion-card-content style=\"font-size:50px\">\n        <b *ngIf=\"!isAdmin\">{{ (usuario.evaluaciones.length|| \"Sin datos\") }}</b>\n        <b class=\"texto-encuestas\" *ngIf=\"isAdmin\">Evaluaciones</b>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</div>\n\n\n\n  <ion-card class=\"menu-home \">\n\n      <ion-card-header class=\"header-card\" >\n        <ion-item>\n          <ion-label style=\"font-size:23px;\">Explora</ion-label>\n        <!--\n          <ion-buttons>\n            <ion-button slot=\"end\" color=\"terciary\">\n              <ion-icon slot=\"icon-only\" name=\"cart\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n          -->\n        </ion-item>\n    </ion-card-header>\n\n    <div class=\"contenedor-botones\">\n        <ion-buttons class=\"contenedor-boton\">\n          <ion-button slot=\"end\" class=\"boton\" style=\"background: #fffff;\"  (click)=\"navegar('home')\">\n            <img src=\"https://image.flaticon.com/icons/svg/747/747240.svg\">\n          </ion-button>\n        </ion-buttons>\n\n        <ion-buttons class=\"contenedor-boton\">\n          <ion-button slot=\"end\" class=\"boton\" style=\"background: #fffff;\" (click)=\"navegar('perfil')\">\n            <img src=\"https://image.flaticon.com/icons/svg/1475/1475107.svg\">\n          </ion-button>\n        </ion-buttons>\n\n        <ion-buttons class=\"contenedor-boton\">\n          <ion-button slot=\"end\" class=\"boton\" style=\"background: #fffff;\" (click)=\"navegar('canjeables')\">\n            <img src=\"https://image.flaticon.com/icons/svg/1170/1170576.svg\">\n        </ion-button>\n      </ion-buttons>\n    </div>\n\n  </ion-card>\n\n  <ion-slides pager=\"true\" [options]=\"slideOpts\" style=\"padding-bottom: 5%;\">\n    <ion-slide style=\"height: auto;\" *ngIf=\"usuario.permissionLevel > 4\" >\n      <ion-card *ngIf=\"usuario.permissionLevel > 4\" class=\"grafico\" style=\"width: 100%;height: 100%;\" >\n          <ion-card-header class=\"header-card\">\n            <ion-item>\n              <div class=\"contenedor-card\">\n                <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/386/386901.png\">\n              </div>\n              <ion-item>\n               <ion-label>Por Usuario</ion-label>\n               <ion-select okText=\"OK\" cancelText=\"Cancelar\" (ionChange)=\"dibujarGrafico()\" [(ngModel)]=\"usuarioActual\">\n                 <ion-select-option value=\"{{i}}\" *ngFor=\"let user of usuarios;index as i\">{{user.firstName}} {{user.lastName}}</ion-select-option>\n               </ion-select>\n             </ion-item>\n             <ion-item>\n               <ion-buttons >\n                 <ion-label>Tipo grafico</ion-label>\n                 <ion-select okText=\"Aceptar\" cancelText=\"Cancelar\" (ionChange)=\"dibujarGrafico()\" [(ngModel)]=\"tipoActual\">\n                   <ion-select-option value=\"{{tipo}}\" *ngFor=\"let tipo of tipos;index as i\">{{tipo.toUpperCase()}}</ion-select-option>\n                 </ion-select>\n                </ion-buttons>\n            </ion-item>\n\n              <ion-buttons>\n                <ion-button slot=\"end\" (click)=\"exportar('rendimiento-por-persona')\">\n                  <ion-icon color=\"light\" name=\"cloud-download\"></ion-icon>\n                </ion-button>\n              </ion-buttons>\n\n            </ion-item>\n        </ion-card-header>\n\n        <ion-card-content>\n\n          <canvas #radarCanvas id=\"rendimiento-por-persona\"></canvas>\n          <h2 *ngIf=\"!radarChart\"> No se ha cargado grafico aun</h2>\n\n        </ion-card-content>\n      </ion-card>\n    </ion-slide>\n    <ion-slide style=\"height: auto;\">\n      <ion-card class=\"volteado\" style=\"width: 100%;height: 100%;\">\n          <ion-card-header class=\"header-card\">\n            <ion-item>\n              <div class=\"contenedor-card\">\n                <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/554/554719.png\">\n              </div>\n              <ion-label>Actividades</ion-label>\n\n              <ion-buttons>\n                <ion-button slot=\"end\" (click)=\"exportar('actividades')\">\n                  <ion-icon color=\"light\" name=\"cloud-download\"></ion-icon>\n                </ion-button>\n              </ion-buttons>\n            </ion-item>\n        </ion-card-header>\n\n        <ion-card-content>\n          <div class=\"contenedor-canvas\">\n            <canvas #bubbleCanvas id=\"actividades\"></canvas>\n          </div>\n          <div class=\"contenedor-boton-2\">\n            <ion-buttons class=\"contenedor-boton-canvas\">\n              <ion-button slot=\"end\" class=\"boton-canvas\" style=\"background: #fffff;\" href=\"perfil\">\n                <img src=\"https://image.flaticon.com/icons/svg/747/747240.svg\">\n              </ion-button>\n            </ion-buttons>\n            <ion-label class=\"texto-grafico\">Ver Gráfico</ion-label>\n          </div>\n        </ion-card-content>\n      </ion-card>\n    </ion-slide>\n    <ion-slide style=\"height: auto;\">\n      <ion-card style=\"width: 100%;height: 100%;\" >\n        <ion-card-header class=\"header-card\">\n          <ion-item>\n            <div class=\"contenedor-card\">\n              <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/906/906188.png\">\n            </div>\n            <ion-label>Rendimiento Personal</ion-label>\n\n            <ion-buttons>\n              <ion-button slot=\"end\" (click)=\"exportar('rendimiento-personal')\">\n                <ion-icon color=\"light\" name=\"cloud-download\"></ion-icon>\n              </ion-button>\n            </ion-buttons>\n          </ion-item>\n      </ion-card-header>\n\n      <ion-card-content>\n        <canvas style=\"background: #fff !important;\" #barCanvas id=\"rendimiento-personal\"></canvas>\n      </ion-card-content>\n      </ion-card>\n\n    </ion-slide>\n  </ion-slides>\n\n\n\n\n\n\n\n\n\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var ng_circle_progress__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-circle-progress */ "./node_modules/ng-circle-progress/fesm2015/ng-circle-progress.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");








let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ng_circle_progress__WEBPACK_IMPORTED_MODULE_6__["NgCircleProgressModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".contenedor-imagen {\n  background: #3E55A1;\n  background-size: cover;\n  background-repeat: no-repeat;\n  margin-bottom: 5%;\n  border-bottom-left-radius: 45%;\n  border-bottom-right-radius: 45%;\n}\n\n.sc-ion-buttons-md-h {\n  padding-left: 13% !important;\n}\n\n.imagen-mancha {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 0%;\n}\n\n.contenedor-logo {\n  background: transparent;\n}\n\n.imagen-logo {\n  width: 20%;\n  margin-top: 0%;\n  margin-left: 40%;\n}\n\n/* cards */\n\n.texto-encuestas {\n  font-size: 24px !important;\n}\n\n.contenedor-cards {\n  margin-top: -7%;\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n}\n\n.card-izquierda {\n  width: 50%;\n}\n\n.card-centro {\n  width: 50%;\n}\n\n.card-derecha {\n  width: 50%;\n}\n\n.ion-card-derecha {\n  --background: #1f3e7d;\n  --color: white;\n}\n\n.ion-card-centro {\n  --background: #5785c4;\n  --color: white !important;\n}\n\n.ion-card-izquierda {\n  --background: #97c2e8;\n  --color: white !important;\n}\n\n/* */\n\nion-content {\n  --background: #f5f5f5;\n}\n\n.background-degradadohome {\n  --background: linear-gradient(to right,#2e86c5, #9b5eb7);\n}\n\n.background-degradadohome2 {\n  --background: linear-gradient(to right, #f36523, #feea00);\n}\n\n.background-degradadohome3 {\n  --background: linear-gradient(#ffa16b, #ff538b ,#6a329d);\n}\n\n.background-degradadohome4 {\n  --background: linear-gradient(#f83e9f, #b340a5, #6542aa);\n}\n\n.item-trn {\n  --color:#f5f5f5;\n}\n\n.item-no-background {\n  background-color: transparent !important;\n  background: transparent !important;\n  --background: #0000;\n  --border-color: #0000;\n}\n\n.icono-grande {\n  max-width: 35px;\n  max-height: 35px;\n  min-width: 35px;\n  min-height: 35px;\n}\n\n.item-fondo {\n  /** background **/\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n  --background:#f5f5f5\n     /** objetos del item **/\n  /** color del item (dentro objetos,letras) **/ ;\n}\n\n.margin-card {\n  margin-top: 4%;\n}\n\n.iconopx {\n  min-width: 30px;\n  min-height: 30px;\n}\n\nion-chip {\n  margin-left: 4%;\n  margin-right: 2%;\n  margin-bottom: 3%;\n  margin-top: 3%;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #1B1F3C;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  width: 100%;\n  height: 100%;\n  background: url(\"http://localhost:8100/assets/icon/Background-03.svg\") no-repeat center center;\n}\n\n.imagen-home {\n  width: 35%;\n  margin-left: 30%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n\n.grilla {\n  background: #1B1F3C;\n  height: 40%;\n  margin-bottom: auto;\n}\n\n.fila {\n  height: 80%;\n}\n\n.contenedor-azul {\n  background: #1f3e7d;\n}\n\n.card-azul {\n  --background: #1f3e7d;\n  --color: white !important;\n  border-radius: 30px;\n  height: 100%;\n}\n\n.contenedor-naranjo {\n  background: #5785c4;\n}\n\n.card-naranjo {\n  --background: #5785c4;\n  --color: white !important;\n  border-radius: 30px;\n  height: 100%;\n}\n\n.contenedor-celeste {\n  background: #97c2e8;\n}\n\n.card-celeste {\n  --background: #97c2e8;\n  --color: white !important;\n  border-radius: 30px;\n  height: 100%;\n}\n\n.contenedor-card {\n  --background: #3949ab;\n  --color: white !important;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\nion-item ion-label {\n  --background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  font-family: \"Roboto\";\n  text-align: center;\n  font-size: 18px;\n}\n\nion-content {\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n  font-family: \"Roboto\";\n  text-align: center;\n  border-radius: 30px;\n  margin-top: 3% !important;\n  -webkit-margin-top-collapse: separate;\n}\n\n.header-card {\n  --background: #3949ab;\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\n.card-grid {\n  background: #00bcd4;\n  color: white;\n  width: 80%;\n  margin-left: 10%;\n}\n\n.contenedor-botones {\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n}\n\n.contenedor-boton {\n  width: 50%;\n  padding: 0%;\n  padding-top: 5%;\n  padding-bottom: 5%;\n}\n\n.sc-ion-buttons-md-h {\n  padding-left: 0% !important;\n}\n\n.boton {\n  width: 50px !important;\n  height: 50px;\n  border-radius: 200px;\n  box-shadow: 0px 0px 8px -2px rgba(0, 0, 0, 0.75);\n  margin-left: calc((100% - 50px)/2);\n}\n\n.container-grid {\n  width: 100% !important;\n  margin-left: 0% !important;\n}\n\n@media (min-width: 900px) {\n  .menu-home {\n    display: none;\n  }\n\n  ion-header {\n    display: none;\n  }\n\n  .contenedor-boton-2 {\n    display: none !important;\n  }\n}\n\n@media (max-width: 1000px) and (orientation: landscape) {\n  .contenedor-canvas {\n    display: auto !important;\n  }\n\n  .contenedor-boton-2 {\n    display: none !important;\n  }\n\n  .fila {\n    margin-top: 5%;\n  }\n\n  .menu-home {\n    margin-top: 0% !important;\n  }\n\n  .contenedor-cards {\n    width: 100%;\n    display: inline-block !important;\n    margin-top: 0% !important;\n  }\n\n  .card-izquierda {\n    width: 100% !important;\n  }\n\n  .card-centro {\n    width: 100% !important;\n  }\n\n  .card-derecha {\n    width: 100% !important;\n  }\n}\n\n@media (max-width: 900px) and (orientation: portrait) {\n  .contenedor-cards {\n    width: 100%;\n    display: inline-block !important;\n    margin-top: 0% !important;\n  }\n\n  .card-izquierda {\n    width: 100% !important;\n  }\n\n  .card-centro {\n    width: 100% !important;\n  }\n\n  .card-derecha {\n    width: 100% !important;\n  }\n\n  .contenedor-canvas {\n    display: none;\n  }\n\n  .menu-home {\n    margin-top: 0% !important;\n  }\n\n  .grilla {\n    background: transparent;\n    height: 20% !important;\n    margin-bottom: auto;\n  }\n\n  .fila {\n    margin-top: 10%;\n    margin-bottom: 0%;\n    height: 100% !important;\n  }\n\n  ion-card {\n    --background: white;\n    font-family: \"Roboto\";\n    text-align: center;\n    border-radius: 30px;\n    margin-top: 5%;\n    margin-bottom: 2%;\n  }\n\n  .contenedor-logo {\n    padding-top: 0%;\n  }\n\n  .imagen-logo {\n    width: 40%;\n    margin-top: 0%;\n    margin-left: 30%;\n  }\n\n  .card-celeste {\n    margin-bottom: 4%;\n  }\n\n  .columna-celeste {\n    margin-top: 5%;\n  }\n\n  .columna-naranjo {\n    margin-top: 5%;\n  }\n\n  .card-naranjo {\n    margin-top: 10%;\n  }\n\n  .card-azul {\n    margin-top: 0%;\n  }\n\n  .contenedor-boton-canvas {\n    padding-left: 0%;\n    width: 100% !important;\n  }\n\n  .sc-ion-buttons-md-h {\n    padding-left: 0% !important;\n  }\n\n  .boton-canvas {\n    margin-top: 5%;\n    margin-bottom: 5%;\n    width: 50px !important;\n    height: 50px;\n    margin-left: calc((100% - 50px)/2);\n    padding-left: 0% !important;\n    border-radius: 200px;\n    box-shadow: 0px 0px 8px -2px rgba(0, 0, 0, 0.75);\n  }\n\n  .texto-grafico {\n    width: 100%;\n    font-size: 16px;\n    text-align: center;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNFLGlCQUFBO0VBQ0YsOEJBQUE7RUFDQSwrQkFBQTtBQ0NGOztBRENBO0VBQ0UsNEJBQUE7QUNFRjs7QURDQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0VGOztBRENBO0VBQ0UsdUJBQUE7QUNFRjs7QURDQTtFQUNFLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNFRjs7QURDQSxVQUFBOztBQUVBO0VBQ0UsMEJBQUE7QUNDRjs7QURFQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0FDQ0Y7O0FERUE7RUFFRSxVQUFBO0FDQUY7O0FER0E7RUFDRSxVQUFBO0FDQUY7O0FER0E7RUFDRSxVQUFBO0FDQUY7O0FER0E7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUNBQTs7QURHQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7QUNBRjs7QURHQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7QUNBRjs7QURHQSxJQUFBOztBQUVBO0VBQ0UscUJBQUE7QUNERjs7QURJQTtFQUNFLHdEQUFBO0FDREY7O0FESUE7RUFDRSx5REFBQTtBQ0RGOztBRElBO0VBQ0Usd0RBQUE7QUNERjs7QURJQTtFQUNFLHdEQUFBO0FDREY7O0FESUE7RUFDQyxlQUFBO0FDREQ7O0FESUE7RUFDRSx3Q0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtBQ0RGOztBREtBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDRkY7O0FES0E7RUFDUSxpQkFBQTtFQUNKLDRCQUFBO0VBQ0EsMEJBQUE7RUFDQTs7aURBQUE7QUNBSjs7QURNQTtFQUNFLGNBQUE7QUNIRjs7QURNQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0hGOztBRE1BO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDSEY7O0FET0E7RUFDRTs7O0dBQUE7RUFLQSxxQkFBQTtFQUVBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ05GOztBRFNBO0VBRUUsV0FBQTtFQUNBLFlBQUE7RUFDQSw4RkFBQTtBQ1BGOztBRFVBO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FDUEY7O0FEVUE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ1BGOztBRFVBO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUNQRjs7QURVQTtFQUNFLFdBQUE7QUNQRjs7QURVQTtFQUNFLG1CQUFBO0FDUEY7O0FEVUE7RUFDRSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FDUEY7O0FEVUE7RUFDRSxtQkFBQTtBQ1BGOztBRFVBO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ1BGOztBRFVBO0VBQ0UsbUJBQUE7QUNQRjs7QURVQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUNQRjs7QURVQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7QUNQRjs7QURXQTtFQUFTOzs7R0FBQTtFQUlQLHFCQUFBO0VBQ0Esa0JBQUE7QUNQRjs7QURRRTtFQUNFLGdGQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNOSjs7QURVQTtFQUVFOzs7O0dBQUE7QUNKRjs7QURXQTtFQUNFLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxxQ0FBQTtBQ1JGOztBRFlBO0VBQ0UscUJBQUE7QUNURjs7QURVRTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FDUkY7O0FEWUE7RUFDRSwrRkFBQTtFQUNBLHlCQUFBO0FDVEY7O0FEWUE7RUFDRSxpQ0FBQTtBQ1RGOztBRFlBO0VBQ0UsK0ZBQUE7RUFDQSx5R0FBQTtFQUNBLHFHQUFBO0VBQ0EsY0FBQTtBQ1RGOztBRFlBO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FDVEY7O0FEWUE7RUFDRSxXQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0FDVEY7O0FEWUE7RUFDRSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ1RGOztBRFlBO0VBQ0UsMkJBQUE7QUNURjs7QURZQTtFQUNFLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBR0EsZ0RBQUE7RUFDQSxrQ0FBQTtBQ1RGOztBRFlBO0VBQ0Usc0JBQUE7RUFDQSwwQkFBQTtBQ1RGOztBRFlBO0VBQ0U7SUFDRSxhQUFBO0VDVEY7O0VEWUE7SUFDRSxhQUFBO0VDVEY7O0VEWUE7SUFDRSx3QkFBQTtFQ1RGO0FBQ0Y7O0FEWUE7RUFDRTtJQUNFLHdCQUFBO0VDVkY7O0VEYUE7SUFDRSx3QkFBQTtFQ1ZGOztFRGFBO0lBQ0UsY0FBQTtFQ1ZGOztFRGFBO0lBQ0UseUJBQUE7RUNWRjs7RURhQTtJQUNFLFdBQUE7SUFDQSxnQ0FBQTtJQUNBLHlCQUFBO0VDVkY7O0VEYUE7SUFFRSxzQkFBQTtFQ1hGOztFRGNBO0lBQ0Usc0JBQUE7RUNYRjs7RURjQTtJQUNFLHNCQUFBO0VDWEY7QUFDRjs7QURjQTtFQUNFO0lBQ0UsV0FBQTtJQUNBLGdDQUFBO0lBQ0EseUJBQUE7RUNaRjs7RURlQTtJQUVFLHNCQUFBO0VDYkY7O0VEZ0JBO0lBQ0Usc0JBQUE7RUNiRjs7RURnQkE7SUFDRSxzQkFBQTtFQ2JGOztFRGdCQTtJQUNFLGFBQUE7RUNiRjs7RURnQkE7SUFDRSx5QkFBQTtFQ2JGOztFRGdCQTtJQUNFLHVCQUFBO0lBQ0Esc0JBQUE7SUFDQSxtQkFBQTtFQ2JGOztFRGdCQTtJQUNFLGVBQUE7SUFDQSxpQkFBQTtJQUNBLHVCQUFBO0VDYkY7O0VEZ0JBO0lBQ0UsbUJBQUE7SUFDQSxxQkFBQTtJQUNBLGtCQUFBO0lBQ0EsbUJBQUE7SUFDQSxjQUFBO0lBQ0EsaUJBQUE7RUNiRjs7RURlQTtJQUNFLGVBQUE7RUNaRjs7RURlQTtJQUNFLFVBQUE7SUFDQSxjQUFBO0lBQ0EsZ0JBQUE7RUNaRjs7RURlQTtJQUNFLGlCQUFBO0VDWkY7O0VEZUE7SUFDRSxjQUFBO0VDWkY7O0VEZUE7SUFDRSxjQUFBO0VDWkY7O0VEZUE7SUFFRSxlQUFBO0VDYkY7O0VEZ0JBO0lBQ0UsY0FBQTtFQ2JGOztFRGdCRjtJQUVJLGdCQUFBO0lBQ0Esc0JBQUE7RUNkRjs7RURnQkE7SUFDRSwyQkFBQTtFQ2JGOztFRGdCQTtJQUNFLGNBQUE7SUFDQSxpQkFBQTtJQUNBLHNCQUFBO0lBQ0EsWUFBQTtJQUNBLGtDQUFBO0lBQ0EsMkJBQUE7SUFDQSxvQkFBQTtJQUdBLGdEQUFBO0VDYkY7O0VEZ0JBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxrQkFBQTtFQ2JGO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICBiYWNrZ3JvdW5kOiAjM0U1NUExO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOjQ1JTtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6NDUlO1xufVxuLnNjLWlvbi1idXR0b25zLW1kLWgge1xuICBwYWRkaW5nLWxlZnQ6IDEzJSFpbXBvcnRhbnQ7XG59XG5cbi5pbWFnZW4tbWFuY2hhe1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbi5jb250ZW5lZG9yLWxvZ297XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG4uaW1hZ2VuLWxvZ297XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi10b3A6IDAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xufVxuXG4vKiBjYXJkcyAqL1xuXG4udGV4dG8tZW5jdWVzdGFze1xuICBmb250LXNpemU6IDI0cHggIWltcG9ydGFudDtcbn1cblxuLmNvbnRlbmVkb3ItY2FyZHN7XG4gIG1hcmdpbi10b3A6IC03JTtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5jYXJkLWl6cXVpZXJkYVxue1xuICB3aWR0aDogNTAlO1xufVxuXG4uY2FyZC1jZW50cm97XG4gIHdpZHRoOiA1MCU7XG59XG5cbi5jYXJkLWRlcmVjaGF7XG4gIHdpZHRoOiA1MCU7XG59XG5cbi5pb24tY2FyZC1kZXJlY2hhe1xuLS1iYWNrZ3JvdW5kOiAjMWYzZTdkO1xuLS1jb2xvcjogd2hpdGU7XG59XG5cbi5pb24tY2FyZC1jZW50cm97XG4gIC0tYmFja2dyb3VuZDogIzU3ODVjNDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1jYXJkLWl6cXVpZXJkYXtcbiAgLS1iYWNrZ3JvdW5kOiAjOTdjMmU4O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG4vKiAqL1xuXG5pb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjVmNWY1O1xufVxuXG4uYmFja2dyb3VuZC1kZWdyYWRhZG9ob21le1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwjMmU4NmM1LCAjOWI1ZWI3KTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZTJ7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZjM2NTIzLCAjZmVlYTAwKTtcbn1cblxuLmJhY2tncm91bmQtZGVncmFkYWRvaG9tZTN7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCNmZmExNmIsICNmZjUzOGIgLCM2YTMyOWQpO1xufVxuXG4uYmFja2dyb3VuZC1kZWdyYWRhZG9ob21lNHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoI2Y4M2U5ZiwgI2IzNDBhNSwgIzY1NDJhYSk7XG59XG5cbi5pdGVtLXRybiB7XG5cdC0tY29sb3I6I2Y1ZjVmNTtcbn1cblxuLml0ZW0tbm8tYmFja2dyb3VuZHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwMDtcbiAgLS1ib3JkZXItY29sb3I6ICMwMDAwO1xuXG59XG5cbi5pY29uby1ncmFuZGV7XG4gIG1heC13aWR0aDogIDM1cHg7XG4gIG1heC1oZWlnaHQ6IDM1cHg7XG4gIG1pbi13aWR0aDogIDM1cHg7XG4gIG1pbi1oZWlnaHQ6IDM1cHg7XG59XG5cbi5pdGVtLWZvbmRve1xuICAgICAgICAvKiogYmFja2dyb3VuZCAqKi9cbiAgICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAgIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xuICAgIC0tYmFja2dyb3VuZDojZjVmNWY1XG4gICAgICAvKiogb2JqZXRvcyBkZWwgaXRlbSAqKi9cblxuICAgLyoqIGNvbG9yIGRlbCBpdGVtIChkZW50cm8gb2JqZXRvcyxsZXRyYXMpICoqL1xufVxuXG4ubWFyZ2luLWNhcmR7XG4gIG1hcmdpbi10b3A6IDQlO1xufVxuXG4uaWNvbm9weHtcbiAgbWluLXdpZHRoOiAzMHB4O1xuICBtaW4taGVpZ2h0OiAzMHB4O1xufVxuXG5pb24tY2hpcHtcbiAgbWFyZ2luLWxlZnQ6IDQlO1xuICBtYXJnaW4tcmlnaHQ6IDIlO1xuICBtYXJnaW4tYm90dG9tOiAzJTtcbiAgbWFyZ2luLXRvcDogMyU7XG59XG5cblxuaW9uLXRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICMxQjFGM0M7XG5cbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgLy9iYWNrZ3JvdW5kOiAjMUIxRjNDO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kIDogdXJsKCdodHRwOi8vbG9jYWxob3N0OjgxMDAvYXNzZXRzL2ljb24vQmFja2dyb3VuZC0wMy5zdmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlcjtcbn1cblxuLmltYWdlbi1ob21le1xuICB3aWR0aDogMzUlO1xuICBtYXJnaW4tbGVmdDogMzAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tY2FyZHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG4uZ3JpbGxhe1xuICBiYWNrZ3JvdW5kOiAjMUIxRjNDO1xuICBoZWlnaHQ6IDQwJTtcbiAgbWFyZ2luLWJvdHRvbTogYXV0bztcbn1cblxuLmZpbGF7XG4gIGhlaWdodDogODAlO1xufVxuXG4uY29udGVuZWRvci1henVse1xuICBiYWNrZ3JvdW5kOiAjMWYzZTdkO1xufVxuXG4uY2FyZC1henVse1xuICAtLWJhY2tncm91bmQ6ICMxZjNlN2Q7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmNvbnRlbmVkb3ItbmFyYW5qb3tcbiAgYmFja2dyb3VuZDogIzU3ODVjNDtcbn1cblxuLmNhcmQtbmFyYW5qb3tcbiAgLS1iYWNrZ3JvdW5kOiAjNTc4NWM0O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5jb250ZW5lZG9yLWNlbGVzdGV7XG4gIGJhY2tncm91bmQ6ICM5N2MyZTg7XG59XG5cbi5jYXJkLWNlbGVzdGV7XG4gIC0tYmFja2dyb3VuZDogIzk3YzJlODtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY29udGVuZWRvci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cblxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaW9uLWxhYmVse1xuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICB9XG59XG5cbmlvbi1jb250ZW50IHtcblxuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBtYXJnaW4tdG9wOiAzJSFpbXBvcnRhbnQ7XG4gIC13ZWJraXQtbWFyZ2luLXRvcC1jb2xsYXBzZTogc2VwYXJhdGU7XG5cbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWJ7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmNhcmQtZ3JpZHtcbiAgYmFja2dyb3VuZDogIzAwYmNkNDtcbiAgY29sb3I6IHdoaXRlO1xuICB3aWR0aDogODAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xufVxuXG4uY29udGVuZWRvci1ib3RvbmVze1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmNvbnRlbmVkb3ItYm90b257XG4gIHdpZHRoOiA1MCU7XG4gIHBhZGRpbmc6IDAlO1xuICBwYWRkaW5nLXRvcDogNSU7XG4gIHBhZGRpbmctYm90dG9tOiA1JTtcbn1cblxuLnNjLWlvbi1idXR0b25zLW1kLWgge1xuICBwYWRkaW5nLWxlZnQ6IDAlICFpbXBvcnRhbnQ7XG59XG5cbi5ib3RvbntcbiAgd2lkdGg6IDUwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBib3JkZXItcmFkaXVzOiAyMDBweDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwcHggMHB4IDhweCAtMnB4IHJnYmEoMCwwLDAsMC43NSk7XG4gIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsMCwwLDAuNzUpO1xuICBib3gtc2hhZG93OiAwcHggMHB4IDhweCAtMnB4IHJnYmEoMCwwLDAsMC43NSk7XG4gIG1hcmdpbi1sZWZ0OiBjYWxjKCgxMDAlIC0gNTBweCkvMik7XG59XG5cbi5jb250YWluZXItZ3JpZHtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDAlICFpbXBvcnRhbnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5MDBweCkge1xuICAubWVudS1ob21le1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICBpb24taGVhZGVye1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAuY29udGVuZWRvci1ib3Rvbi0ye1xuICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcbiAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogMTAwMHB4KSBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpe1xuICAuY29udGVuZWRvci1jYW52YXN7XG4gICAgZGlzcGxheTogYXV0byAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNvbnRlbmVkb3ItYm90b24tMntcbiAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuZmlsYXtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgfVxuXG4gIC5tZW51LWhvbWV7XG4gICAgbWFyZ2luLXRvcDogMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jb250ZW5lZG9yLWNhcmRze1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jayAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi10b3A6IDAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuY2FyZC1penF1aWVyZGFcbiAge1xuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuY2FyZC1jZW50cm97XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYXJkLWRlcmVjaGF7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogOTAwcHgpIGFuZCAob3JpZW50YXRpb246IHBvcnRyYWl0KXtcbiAgLmNvbnRlbmVkb3ItY2FyZHN7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLXRvcDogMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYXJkLWl6cXVpZXJkYVxuICB7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYXJkLWNlbnRyb3tcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNhcmQtZGVyZWNoYXtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNvbnRlbmVkb3ItY2FudmFze1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAubWVudS1ob21le1xuICAgIG1hcmdpbi10b3A6IDAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuZ3JpbGxhe1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIGhlaWdodDogMjAlICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLWJvdHRvbTogYXV0bztcbiAgfVxuXG4gIC5maWxhe1xuICAgIG1hcmdpbi10b3A6IDEwJTtcbiAgICBtYXJnaW4tYm90dG9tOiAwJTtcbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIGlvbi1jYXJke1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDIlO1xuICB9XG4gIC5jb250ZW5lZG9yLWxvZ297XG4gICAgcGFkZGluZy10b3A6IDAlO1xuICB9XG5cbiAgLmltYWdlbi1sb2dve1xuICAgIHdpZHRoOiA0MCU7XG4gICAgbWFyZ2luLXRvcDogMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDMwJTtcbiAgfVxuXG4gIC5jYXJkLWNlbGVzdGV7XG4gICAgbWFyZ2luLWJvdHRvbTogNCVcbiAgfVxuXG4gIC5jb2x1bW5hLWNlbGVzdGV7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gIH1cblxuICAuY29sdW1uYS1uYXJhbmpve1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICB9XG5cbiAgLmNhcmQtbmFyYW5qb3tcblxuICAgIG1hcmdpbi10b3A6IDEwJVxuICB9XG5cbiAgLmNhcmQtYXp1bHtcbiAgICBtYXJnaW4tdG9wOiAwJTtcbiAgfVxuXG4uY29udGVuZWRvci1ib3Rvbi1jYW52YXNcbiAge1xuICAgIHBhZGRpbmctbGVmdDogMCU7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuICAuc2MtaW9uLWJ1dHRvbnMtbWQtaHtcbiAgICBwYWRkaW5nLWxlZnQ6IDAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuYm90b24tY2FudmFze1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICAgIHdpZHRoOiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiBjYWxjKCgxMDAlIC0gNTBweCkvMik7XG4gICAgcGFkZGluZy1sZWZ0OiAwJSAhaW1wb3J0YW50O1xuICAgIGJvcmRlci1yYWRpdXM6IDIwMHB4O1xuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsMCwwLDAuNzUpO1xuICAgIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsMCwwLDAuNzUpO1xuICAgIGJveC1zaGFkb3c6IDBweCAwcHggOHB4IC0ycHggcmdiYSgwLDAsMCwwLjc1KTtcbiAgfVxuXG4gIC50ZXh0by1ncmFmaWNve1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbn1cbiIsIi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICMzRTU1QTE7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA0NSU7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA0NSU7XG59XG5cbi5zYy1pb24tYnV0dG9ucy1tZC1oIHtcbiAgcGFkZGluZy1sZWZ0OiAxMyUgIWltcG9ydGFudDtcbn1cblxuLmltYWdlbi1tYW5jaGEge1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbi5jb250ZW5lZG9yLWxvZ28ge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLmltYWdlbi1sb2dvIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG59XG5cbi8qIGNhcmRzICovXG4udGV4dG8tZW5jdWVzdGFzIHtcbiAgZm9udC1zaXplOiAyNHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW5lZG9yLWNhcmRzIHtcbiAgbWFyZ2luLXRvcDogLTclO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmNhcmQtaXpxdWllcmRhIHtcbiAgd2lkdGg6IDUwJTtcbn1cblxuLmNhcmQtY2VudHJvIHtcbiAgd2lkdGg6IDUwJTtcbn1cblxuLmNhcmQtZGVyZWNoYSB7XG4gIHdpZHRoOiA1MCU7XG59XG5cbi5pb24tY2FyZC1kZXJlY2hhIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMWYzZTdkO1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1jYXJkLWNlbnRybyB7XG4gIC0tYmFja2dyb3VuZDogIzU3ODVjNDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1jYXJkLWl6cXVpZXJkYSB7XG4gIC0tYmFja2dyb3VuZDogIzk3YzJlODtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuLyogKi9cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjVmNWY1O1xufVxuXG4uYmFja2dyb3VuZC1kZWdyYWRhZG9ob21lIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIzJlODZjNSwgIzliNWViNyk7XG59XG5cbi5iYWNrZ3JvdW5kLWRlZ3JhZGFkb2hvbWUyIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmMzY1MjMsICNmZWVhMDApO1xufVxuXG4uYmFja2dyb3VuZC1kZWdyYWRhZG9ob21lMyB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCNmZmExNmIsICNmZjUzOGIgLCM2YTMyOWQpO1xufVxuXG4uYmFja2dyb3VuZC1kZWdyYWRhZG9ob21lNCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KCNmODNlOWYsICNiMzQwYTUsICM2NTQyYWEpO1xufVxuXG4uaXRlbS10cm4ge1xuICAtLWNvbG9yOiNmNWY1ZjU7XG59XG5cbi5pdGVtLW5vLWJhY2tncm91bmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICMwMDAwO1xuICAtLWJvcmRlci1jb2xvcjogIzAwMDA7XG59XG5cbi5pY29uby1ncmFuZGUge1xuICBtYXgtd2lkdGg6IDM1cHg7XG4gIG1heC1oZWlnaHQ6IDM1cHg7XG4gIG1pbi13aWR0aDogMzVweDtcbiAgbWluLWhlaWdodDogMzVweDtcbn1cblxuLml0ZW0tZm9uZG8ge1xuICAvKiogYmFja2dyb3VuZCAqKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZDojZjVmNWY1XG4gICAgIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovIDtcbn1cblxuLm1hcmdpbi1jYXJkIHtcbiAgbWFyZ2luLXRvcDogNCU7XG59XG5cbi5pY29ub3B4IHtcbiAgbWluLXdpZHRoOiAzMHB4O1xuICBtaW4taGVpZ2h0OiAzMHB4O1xufVxuXG5pb24tY2hpcCB7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbiAgbWFyZ2luLXJpZ2h0OiAyJTtcbiAgbWFyZ2luLWJvdHRvbTogMyU7XG4gIG1hcmdpbi10b3A6IDMlO1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMUIxRjNDO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB1cmwoXCJodHRwOi8vbG9jYWxob3N0OjgxMDAvYXNzZXRzL2ljb24vQmFja2dyb3VuZC0wMy5zdmdcIikgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXI7XG59XG5cbi5pbWFnZW4taG9tZSB7XG4gIHdpZHRoOiAzNSU7XG4gIG1hcmdpbi1sZWZ0OiAzMCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1jYXJkIHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiAwJTtcbiAgbWFyZ2luLXRvcDogMCU7XG4gIG1hcmdpbi1ib3R0b206IDAlO1xufVxuXG4uZ3JpbGxhIHtcbiAgYmFja2dyb3VuZDogIzFCMUYzQztcbiAgaGVpZ2h0OiA0MCU7XG4gIG1hcmdpbi1ib3R0b206IGF1dG87XG59XG5cbi5maWxhIHtcbiAgaGVpZ2h0OiA4MCU7XG59XG5cbi5jb250ZW5lZG9yLWF6dWwge1xuICBiYWNrZ3JvdW5kOiAjMWYzZTdkO1xufVxuXG4uY2FyZC1henVsIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMWYzZTdkO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5jb250ZW5lZG9yLW5hcmFuam8ge1xuICBiYWNrZ3JvdW5kOiAjNTc4NWM0O1xufVxuXG4uY2FyZC1uYXJhbmpvIHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTc4NWM0O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5jb250ZW5lZG9yLWNlbGVzdGUge1xuICBiYWNrZ3JvdW5kOiAjOTdjMmU4O1xufVxuXG4uY2FyZC1jZWxlc3RlIHtcbiAgLS1iYWNrZ3JvdW5kOiAjOTdjMmU4O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5jb250ZW5lZG9yLWNhcmQge1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuaW9uLWl0ZW0gaW9uLWxhYmVsIHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBtYXJnaW4tdG9wOiAzJSAhaW1wb3J0YW50O1xuICAtd2Via2l0LW1hcmdpbi10b3AtY29sbGFwc2U6IHNlcGFyYXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6ICMzOTQ5YWI7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYiB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbi5jYXJkLWdyaWQge1xuICBiYWNrZ3JvdW5kOiAjMDBiY2Q0O1xuICBjb2xvcjogd2hpdGU7XG4gIHdpZHRoOiA4MCU7XG4gIG1hcmdpbi1sZWZ0OiAxMCU7XG59XG5cbi5jb250ZW5lZG9yLWJvdG9uZXMge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmNvbnRlbmVkb3ItYm90b24ge1xuICB3aWR0aDogNTAlO1xuICBwYWRkaW5nOiAwJTtcbiAgcGFkZGluZy10b3A6IDUlO1xuICBwYWRkaW5nLWJvdHRvbTogNSU7XG59XG5cbi5zYy1pb24tYnV0dG9ucy1tZC1oIHtcbiAgcGFkZGluZy1sZWZ0OiAwJSAhaW1wb3J0YW50O1xufVxuXG4uYm90b24ge1xuICB3aWR0aDogNTBweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDIwMHB4O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IDBweCAwcHggOHB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjc1KTtcbiAgLW1vei1ib3gtc2hhZG93OiAwcHggMHB4IDhweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC43NSk7XG4gIGJveC1zaGFkb3c6IDBweCAwcHggOHB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjc1KTtcbiAgbWFyZ2luLWxlZnQ6IGNhbGMoKDEwMCUgLSA1MHB4KS8yKTtcbn1cblxuLmNvbnRhaW5lci1ncmlkIHtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDAlICFpbXBvcnRhbnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5MDBweCkge1xuICAubWVudS1ob21lIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgaW9uLWhlYWRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuXG4gIC5jb250ZW5lZG9yLWJvdG9uLTIge1xuICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcbiAgfVxufVxuQG1lZGlhIChtYXgtd2lkdGg6IDEwMDBweCkgYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKSB7XG4gIC5jb250ZW5lZG9yLWNhbnZhcyB7XG4gICAgZGlzcGxheTogYXV0byAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNvbnRlbmVkb3ItYm90b24tMiB7XG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmZpbGEge1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICB9XG5cbiAgLm1lbnUtaG9tZSB7XG4gICAgbWFyZ2luLXRvcDogMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jb250ZW5lZG9yLWNhcmRzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2sgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tdG9wOiAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNhcmQtaXpxdWllcmRhIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNhcmQtY2VudHJvIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNhcmQtZGVyZWNoYSB7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxufVxuQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSBhbmQgKG9yaWVudGF0aW9uOiBwb3J0cmFpdCkge1xuICAuY29udGVuZWRvci1jYXJkcyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLXRvcDogMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYXJkLWl6cXVpZXJkYSB7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYXJkLWNlbnRybyB7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYXJkLWRlcmVjaGEge1xuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuY29udGVuZWRvci1jYW52YXMge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAubWVudS1ob21lIHtcbiAgICBtYXJnaW4tdG9wOiAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmdyaWxsYSB7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgaGVpZ2h0OiAyMCUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tYm90dG9tOiBhdXRvO1xuICB9XG5cbiAgLmZpbGEge1xuICAgIG1hcmdpbi10b3A6IDEwJTtcbiAgICBtYXJnaW4tYm90dG9tOiAwJTtcbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIGlvbi1jYXJkIHtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDIlO1xuICB9XG5cbiAgLmNvbnRlbmVkb3ItbG9nbyB7XG4gICAgcGFkZGluZy10b3A6IDAlO1xuICB9XG5cbiAgLmltYWdlbi1sb2dvIHtcbiAgICB3aWR0aDogNDAlO1xuICAgIG1hcmdpbi10b3A6IDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAzMCU7XG4gIH1cblxuICAuY2FyZC1jZWxlc3RlIHtcbiAgICBtYXJnaW4tYm90dG9tOiA0JTtcbiAgfVxuXG4gIC5jb2x1bW5hLWNlbGVzdGUge1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICB9XG5cbiAgLmNvbHVtbmEtbmFyYW5qbyB7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gIH1cblxuICAuY2FyZC1uYXJhbmpvIHtcbiAgICBtYXJnaW4tdG9wOiAxMCU7XG4gIH1cblxuICAuY2FyZC1henVsIHtcbiAgICBtYXJnaW4tdG9wOiAwJTtcbiAgfVxuXG4gIC5jb250ZW5lZG9yLWJvdG9uLWNhbnZhcyB7XG4gICAgcGFkZGluZy1sZWZ0OiAwJTtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnNjLWlvbi1idXR0b25zLW1kLWgge1xuICAgIHBhZGRpbmctbGVmdDogMCUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5ib3Rvbi1jYW52YXMge1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDUlO1xuICAgIHdpZHRoOiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiBjYWxjKCgxMDAlIC0gNTBweCkvMik7XG4gICAgcGFkZGluZy1sZWZ0OiAwJSAhaW1wb3J0YW50O1xuICAgIGJvcmRlci1yYWRpdXM6IDIwMHB4O1xuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuNzUpO1xuICAgIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCA4cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuNzUpO1xuICAgIGJveC1zaGFkb3c6IDBweCAwcHggOHB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjc1KTtcbiAgfVxuXG4gIC50ZXh0by1ncmFmaWNvIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/dist/Chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _evaluaciones_instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../evaluaciones/instrumento/instrumento.page */ "./src/app/evaluaciones/instrumento/instrumento.page.ts");
/* harmony import */ var _list_list_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../list/list.page */ "./src/app/list/list.page.ts");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! jspdf */ "./node_modules/jspdf/dist/jspdf.min.js");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_8__);









let HomePage = class HomePage {
    constructor(router, userService, modalCtrl) {
        this.router = router;
        this.userService = userService;
        this.modalCtrl = modalCtrl;
        this.asignado = { name: 'Aun no asignado' };
        this.valorPersonalResult = 0;
        this.total = 1;
        this.tipoActual = "horizontalBar";
        this.isAdmin = false;
        this.usuarioActual = 0;
        this.tipos = ["bar", "horizontalBar", "line", "radar", "polarArea", "pie", "doughnut", "bubble"];
        this.usuario = { encuestas: [], evaluaciones: [], canjeables: [], permissionLevel: 5 };
        this.usuarios = [];
        this.slideOpts = {
            initialSlide: 1,
            speed: 400
        };
        var menu = document.querySelector('ion-menu');
        menu.hidden = false;
        this.getPersonalResults();
        this.datosMultiples();
        this.traerDatos(false);
    }
    random_rgba() {
        var o = Math.round, r = Math.random, s = 200;
        var rgb = 'rgba(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ',' + (r().toFixed(1) + 10) + ')';
        console.log(rgb);
        return rgb;
    }
    ngAfterViewInit() {
        console.log();
        this.graficarPersonalData();
    }
    ngOnInit() {
        var valorAsignado = JSON.parse(sessionStorage.getItem('asignado'));
        if (valorAsignado == false) {
            this.asignado = { name: 'Aun no asignado' };
        }
        else {
            this.asignado = valorAsignado[0];
        }
    }
    navegar(ruta) {
        this.router.navigate([ruta]);
    }
    graficarPersonalData() {
        let arr = [];
        let valores = [];
        let labels = [];
        let backgroundColors = [];
        let bordesColors = [];
        let background = ["rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)"];
        let bordes = ["rgba(255,99,132,1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)"];
        let evaluaciones = JSON.parse(sessionStorage.getItem('evaluaciones'));
        for (let i = evaluaciones.length; i > 0; i = i - 1) {
            if (evaluaciones[i - 1].estado > 0) {
                if (arr.length != 6) {
                    labels.push(evaluaciones[i - 1].instrumento.sigla);
                    arr.push(evaluaciones[i - 1]);
                    var valor = this.getPersonalResultsByEv(evaluaciones[i - 1]);
                    valores.push(Math.round(valor));
                    backgroundColors.push(background[backgroundColors.length]);
                    bordesColors.push(bordes[bordesColors.length]);
                }
            }
        }
        this.barChart = new chart_js__WEBPACK_IMPORTED_MODULE_2__["Chart"](this.barCanvas.nativeElement, {
            type: "horizontalBar",
            data: {
                labels: labels,
                datasets: [
                    {
                        label: "Evaluaciones",
                        data: valores,
                        backgroundColor: backgroundColors,
                        borderColor: bordesColors,
                        borderWidth: 2
                    }
                ]
            },
            options: {
                scales: {
                    yAxes: [
                        {
                            ticks: {
                                beginAtZero: true
                            }
                        }
                    ]
                }
            }
        });
    }
    traerDatos(evento) {
        var usuario = JSON.parse(sessionStorage.getItem('usuario'));
        this.usuario = usuario;
        console.log("usuario", usuario);
        let userId = sessionStorage.getItem('userId');
        let self = this;
        this.userService.gathering(userId).subscribe(datos => {
            usuario = datos;
            if (parseInt(datos.permissionLevel) > 4) {
                self.userService.listar().subscribe(usuarios => {
                    this.usuarios = usuarios;
                    if (parseInt(usuario.permissionLevel) <= 4) {
                        this.getPersonalResults();
                    }
                    else {
                        this.isAdmin = true;
                        this.getGeneralData();
                    }
                    console.log(usuarios);
                });
            }
            console.log(datos);
            sessionStorage.setItem('evaluaciones', JSON.stringify(datos.evaluaciones));
            if (evento) {
                evento.target.complete();
            }
        });
        this.datosMultiples();
    }
    datosMultiples() {
        this.userService.listar().subscribe(datos => {
            var labels = [];
            var datasets = [];
            var usuariosEvaluados = [];
            var agrupadosPorFecha = [];
            for (let i = 0; i < datos.length; i++) {
                let usuario = datos[i];
                for (let i = 0; i < usuario.evaluaciones.length; i++) {
                    let ev = usuario.evaluaciones[i];
                    if (ev.estado > 0) {
                        let percent = parseFloat(this.getPersonalPorcentByEv(ev));
                        if (Number.isNaN(percent)) {
                            percent = 0;
                        }
                        let key = usuario.firstName + " " + usuario.lastName;
                        let fecha = ev.fecha;
                        if (agrupadosPorFecha[fecha]) {
                            if (agrupadosPorFecha[fecha][key]) {
                                agrupadosPorFecha[fecha][key].push(percent);
                            }
                            else {
                                agrupadosPorFecha[fecha][key] = [];
                                agrupadosPorFecha[fecha][key].push(percent);
                            }
                        }
                        else {
                            agrupadosPorFecha[fecha] = [];
                            agrupadosPorFecha[fecha][key] = [];
                            agrupadosPorFecha[fecha][key].push(percent);
                        }
                        labels.indexOf(ev.instrumento.sigla) === -1 ? labels.push(ev.instrumento.sigla) : console.log("This item already exists");
                        if (usuariosEvaluados.indexOf(key) === -1)
                            usuariosEvaluados.push(key);
                    }
                }
            }
            var conjuntoDatos = [];
            var datasets = [];
            var indice = 0;
            for (let identificador in agrupadosPorFecha) {
                let datos = agrupadosPorFecha[identificador];
                var data = [];
                for (let i = 0; i < usuariosEvaluados.length; i++) {
                    let usr = usuariosEvaluados[i];
                    let cantidad = 0;
                    if (datos[usr]) {
                        cantidad = datos[usr];
                        cantidad = cantidad[0];
                    }
                    data.push(cantidad);
                }
                let info = {
                    label: labels[indice],
                    backgroundColor: this.random_rgba(),
                    data: data
                };
                datasets.push(info);
                indice += 1;
            }
            var barChartData = {
                labels: usuariosEvaluados,
                datasets: datasets
            };
            console.log(barChartData);
            if (this.doughnutChart) {
            }
            else {
                this.doughnutChart = new chart_js__WEBPACK_IMPORTED_MODULE_2__["Chart"](this.comparativeCanvas.nativeElement, {
                    type: "horizontalBar",
                    data: barChartData,
                    options: {
                        title: {
                            display: true,
                            text: 'Comparativa entre los distintos usuarios'
                        },
                        tooltips: {
                            mode: 'index',
                            intersect: false
                        },
                        responsive: true,
                        scales: {
                            xAxes: [{
                                    stacked: true,
                                }],
                            yAxes: [{
                                    stacked: true
                                }]
                        }
                    }
                });
            }
        });
    }
    verEvaluacion(evaluacion) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _evaluaciones_instrumento_instrumento_page__WEBPACK_IMPORTED_MODULE_4__["InstrumentoPage"],
                cssClass: 'modals',
                componentProps: {
                    'evaluacion': evaluacion.instrumento,
                    'noOcultar': false
                }
            });
            return yield modal.present();
        });
    }
    verEvaluaciones() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _list_list_page__WEBPACK_IMPORTED_MODULE_5__["ListPage"],
                cssClass: 'modals',
                componentProps: {
                    'tipo': 'Evaluaciones'
                }
            });
            return yield modal.present();
        });
    }
    verEncuestas() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _list_list_page__WEBPACK_IMPORTED_MODULE_5__["ListPage"],
                cssClass: 'modals',
                componentProps: {
                    'tipo': 'Encuestas'
                }
            });
            return yield modal.present();
        });
    }
    getPersonalEvaluation() {
        let evaluaciones = JSON.parse(sessionStorage.getItem('evaluaciones'));
        for (let i = evaluaciones.length; i > 0; i = i - 1) {
            if (evaluaciones[i - 1].estado > 0) {
                return evaluaciones[i - 1];
            }
        }
    }
    getPersonalPorcentByEv(evaluacion) {
        var instrumento = evaluacion.instrumento;
        var puntos = 0;
        for (let indice = 0; indice < instrumento.indicadores.length; indice++) {
            let indicador = instrumento.indicadores[indice];
            if (indicador.valor) {
                puntos += indicador.valor;
            }
        }
        return (puntos / instrumento.indicadores.length).toFixed(1);
    }
    getPersonalResultsByEv(evaluacion) {
        var instrumento = evaluacion.instrumento;
        var puntos = 0;
        for (let indice = 0; indice < instrumento.indicadores.length; indice++) {
            let indicador = instrumento.indicadores[indice];
            if (indicador.valor) {
                puntos += indicador.valor;
            }
        }
        return puntos / instrumento.indicadores.length;
    }
    obtenDatos() {
        var datos = this.personalResults / this.total;
        return datos.toFixed(1);
    }
    getPersonalResults() {
        if (this.valorPersonalResult > 0) {
            if (this.valorPersonalResult <= 100) {
                return this.valorPersonalResult;
            }
        }
        let evaluaciones = JSON.parse(sessionStorage.getItem('evaluaciones'));
        for (let i = evaluaciones.length; i > 0; i = i - 1) {
            if (evaluaciones[i - 1].estado > 0) {
                var instrumento = evaluaciones[i - 1].instrumento;
                var puntos = 0;
                var cantidad = 0;
                for (let indice = 0; indice < instrumento.indicadores.length; indice++) {
                    let indicador = instrumento.indicadores[indice];
                    if (indicador.valor) {
                        puntos += indicador.valor;
                        cantidad += 1;
                    }
                }
                console.log(puntos);
                this.valorPersonalResult = puntos;
                this.valorPersonalResult / cantidad;
                this.total = instrumento.indicadores.length;
                this.personalResults = puntos;
                return puntos;
            }
        }
    }
    getGeneralResults(evaluaciones) {
        for (let i = evaluaciones.length; i > 0; i = i - 1) {
            if (evaluaciones[i - 1].estado > 0) {
                var instrumento = evaluaciones[i - 1].instrumento;
                var puntos = 0;
                var cantidad = 0;
                for (let indice = 0; indice < instrumento.indicadores.length; indice++) {
                    let indicador = instrumento.indicadores[indice];
                    if (indicador.valor) {
                        puntos += indicador.valor;
                        cantidad += 1;
                    }
                }
                return (puntos / cantidad).toFixed(1);
                ;
            }
        }
    }
    getGeneralData() {
        var evaluados = 0;
        var puntaje = 0;
        for (let i = 0; i < this.usuarios.length; i++) {
            var ev = this.usuarios[i].evaluaciones;
            if (ev.length > 0) {
                evaluados++;
                var res = this.getGeneralResults(ev);
                if (parseInt(res) > 0) {
                    puntaje += parseFloat(res);
                }
                ;
            }
        }
        this.personalResults = puntaje;
        this.total = evaluados;
    }
    dibujarGrafico() {
        console.log(this.usuarioActual);
        let arr = [];
        let valores = [];
        let labels = [];
        let backgroundColors = [];
        let bordesColors = [];
        let background = ["rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)"];
        let bordes = ["rgba(255,99,132,1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)"];
        let evaluaciones = this.usuarios[this.usuarioActual].evaluaciones;
        if (!evaluaciones) {
            return;
        }
        for (let i = evaluaciones.length; i > 0; i = i - 1) {
            if (evaluaciones[i - 1].estado > 0) {
                if (arr.length != 6) {
                    labels.push(evaluaciones[i - 1].instrumento.sigla);
                    arr.push(evaluaciones[i - 1]);
                    valores.push(Math.round(this.getPersonalResultsByEv(evaluaciones[i - 1])));
                    backgroundColors.push(background[backgroundColors.length]);
                    bordesColors.push(bordes[bordesColors.length]);
                }
            }
        }
        for (let valor of valores) {
            valor = Math.round(valor);
        }
        if (this.radarChart) {
            this.radarChart.destroy();
        }
        this.radarChart = new chart_js__WEBPACK_IMPORTED_MODULE_2__["Chart"](this.radarCanvas.nativeElement, {
            type: this.tipoActual,
            data: {
                labels: labels,
                datasets: [
                    {
                        label: "Evaluaciones",
                        data: valores,
                        backgroundColor: backgroundColors,
                        borderColor: bordesColors,
                        borderWidth: 2
                    }
                ]
            },
            options: {
                scales: {
                    yAxes: [
                        {
                            ticks: {
                                beginAtZero: true
                            }
                        }
                    ]
                }
            }
        });
    }
    exportar(id) {
        var canvas = document.querySelector('#' + id);
        ;
        //creates image
        console.log(canvas);
        var canvasImg = canvas.toDataURL("image/png", 1.0);
        //creates PDF from img
        var doc = new jspdf__WEBPACK_IMPORTED_MODULE_8__('landscape');
        doc.addImage(canvasImg, 'PNG', 10, 10, 280, 150);
        //    doc.save('canvas.pdf');
        let pdfSalida = doc.output();
        let buffer = new ArrayBuffer(pdfSalida.length);
        let array = new Uint8Array(buffer);
        for (var i = 0; i < pdfSalida.length; i++) {
            array[i] = pdfSalida.charCodeAt(i);
        }
        let archivo = new Blob([array], { type: 'application/pdf' });
        var urlArchivo = URL.createObjectURL(archivo);
        window.open(urlArchivo);
    }
};
HomePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("barCanvas", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], HomePage.prototype, "barCanvas", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("doughnutCanvas", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], HomePage.prototype, "doughnutCanvas", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("radarCanvas", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], HomePage.prototype, "radarCanvas", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("polarCanvas", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], HomePage.prototype, "polarCanvas", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("bubbleCanvas", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], HomePage.prototype, "comparativeCanvas", void 0);
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
        styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
        _servicios_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map