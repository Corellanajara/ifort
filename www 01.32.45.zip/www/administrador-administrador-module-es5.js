(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["administrador-administrador-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/administrador/administrador.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/administrador/administrador.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Mantenedores permiso administrador</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-administrador\" src=\"https://image.flaticon.com/icons/png/512/554/554827.png\">\n  </div>\n  <ion-item (click)=\"navegar('usuarios')\">\n    <div class=\"contenedor-card\">\n      <img class=\"imagen-card\" src=\"https://image.flaticon.com/icons/png/512/554/554846.png\">\n    </div>\n    <ion-label>\n      Usuarios\n    </ion-label>\n  </ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/administrador/administrador-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/administrador/administrador-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: AdministradorPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministradorPageRoutingModule", function() { return AdministradorPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _administrador_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./administrador.page */ "./src/app/administrador/administrador.page.ts");




var routes = [
    {
        path: '',
        component: _administrador_page__WEBPACK_IMPORTED_MODULE_3__["AdministradorPage"]
    }
];
var AdministradorPageRoutingModule = /** @class */ (function () {
    function AdministradorPageRoutingModule() {
    }
    AdministradorPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], AdministradorPageRoutingModule);
    return AdministradorPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/administrador/administrador.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/administrador/administrador.module.ts ***!
  \*******************************************************/
/*! exports provided: AdministradorPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministradorPageModule", function() { return AdministradorPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _administrador_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./administrador-routing.module */ "./src/app/administrador/administrador-routing.module.ts");
/* harmony import */ var _administrador_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./administrador.page */ "./src/app/administrador/administrador.page.ts");







var AdministradorPageModule = /** @class */ (function () {
    function AdministradorPageModule() {
    }
    AdministradorPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _administrador_routing_module__WEBPACK_IMPORTED_MODULE_5__["AdministradorPageRoutingModule"]
            ],
            declarations: [_administrador_page__WEBPACK_IMPORTED_MODULE_6__["AdministradorPage"]]
        })
    ], AdministradorPageModule);
    return AdministradorPageModule;
}());



/***/ }),

/***/ "./src/app/administrador/administrador.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/administrador/administrador.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item-trn {\n  --color:#f5f5f5;\n}\n\n.item-no-background {\n  background-color: transparent !important;\n  background: transparent !important;\n  --background: #0000;\n  --border-color: #0000;\n}\n\n.icono-grande {\n  max-width: 35px;\n  max-height: 35px;\n  min-width: 35px;\n  min-height: 35px;\n}\n\n.item-fondo {\n  /** background **/\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n  --background:#f5f5f5\n     /** objetos del item **/\n  /** color del item (dentro objetos,letras) **/ ;\n}\n\n.margin-card {\n  margin-top: 4%;\n}\n\n.iconopx {\n  min-width: 30px;\n  min-height: 30px;\n}\n\n.contenedor-imagen {\n  background: #21ada1;\n  margin-bottom: 5%;\n}\n\n.imagen-administrador {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.contenedor-card {\n  --background: #21ada1;\n  --color: white !important;\n  margin-right: 5%;\n}\n\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n\nion-chip {\n  margin-left: 4%;\n  margin-right: 2%;\n  margin-bottom: 3%;\n  margin-top: 3%;\n}\n\nion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #21ada1;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  cursor: pointer;\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\n@media (min-width: 900px) {\n  ion-header {\n    display: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvYWRtaW5pc3RyYWRvci9hZG1pbmlzdHJhZG9yLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYWRtaW5pc3RyYWRvci9hZG1pbmlzdHJhZG9yLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNDLGVBQUE7QUNIRDs7QURNQTtFQUNFLHdDQUFBO0VBQ0Esa0NBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FDSEY7O0FET0E7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNKRjs7QURPQTtFQUNRLGlCQUFBO0VBQ0osNEJBQUE7RUFDQSwwQkFBQTtFQUNBOztpREFBQTtBQ0ZKOztBRFFBO0VBQ0UsY0FBQTtBQ0xGOztBRFFBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDTEY7O0FEUUE7RUFDRSxtQkFBQTtFQUNELGlCQUFBO0FDTEQ7O0FEUUE7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNMRjs7QURRQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtBQ0xGOztBRFFBO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNMRjs7QURRQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0xGOztBRFNBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNELHFCQUFBO0VBQ0Esa0JBQUE7QUNQRDs7QURVQTtFQUFTOzs7R0FBQTtFQUlQLGVBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0FDTkY7O0FEU0E7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNGRjs7QURTQTtFQUNFLG1CQUFBO0FDTkY7O0FEU0E7RUFDRSxvRkFBQTtBQ05GOztBRE9FO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNMRjs7QURTQTtFQUNFLCtGQUFBO0VBQ0EseUJBQUE7QUNORjs7QURTQTtFQUNDO0lBQ0MsYUFBQTtFQ05BO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9hZG1pbmlzdHJhZG9yL2FkbWluaXN0cmFkb3IucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG5cbn1cblxuLml0ZW0tdHJuIHtcblx0LS1jb2xvcjojZjVmNWY1O1xufVxuXG4uaXRlbS1uby1iYWNrZ3JvdW5ke1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICMwMDAwO1xuICAtLWJvcmRlci1jb2xvcjogIzAwMDA7XG5cbn1cblxuLmljb25vLWdyYW5kZXtcbiAgbWF4LXdpZHRoOiAgMzVweDtcbiAgbWF4LWhlaWdodDogMzVweDtcbiAgbWluLXdpZHRoOiAgMzVweDtcbiAgbWluLWhlaWdodDogMzVweDtcbn1cblxuLml0ZW0tZm9uZG97XG4gICAgICAgIC8qKiBiYWNrZ3JvdW5kICoqL1xuICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG4gICAgLS1iYWNrZ3JvdW5kOiNmNWY1ZjVcbiAgICAgIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuXG4gICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovXG59XG5cbi5tYXJnaW4tY2FyZHtcbiAgbWFyZ2luLXRvcDogNCU7XG59XG5cbi5pY29ub3B4e1xuICBtaW4td2lkdGg6IDMwcHg7XG4gIG1pbi1oZWlnaHQ6IDMwcHg7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgYmFja2dyb3VuZDogIzIxYWRhMTtcblx0bWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tYWRtaW5pc3RyYWRvcntcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uY29udGVuZWRvci1jYXJke1xuICAtLWJhY2tncm91bmQ6ICMyMWFkYTE7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG5cdFx0bWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuLmltYWdlbi1jYXJke1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luLWxlZnQ6IDAlO1xuICBtYXJnaW4tdG9wOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbmlvbi1jaGlwe1xuICBtYXJnaW4tbGVmdDogNCU7XG4gIG1hcmdpbi1yaWdodDogMiU7XG4gIG1hcmdpbi1ib3R0b206IDMlO1xuICBtYXJnaW4tdG9wOiAzJTtcbn1cblxuXG5pb24tdG9vbGJhcntcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuXG4gIC0tYmFja2dyb3VuZDogIzIxYWRhMTtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcblx0Zm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbmlvbi1pdGVtey8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgY3Vyc29yOiBwb2ludGVyO1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICBpb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1jb2xvcjogd2hpdGU7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4uY2FyZC1ncmFkaWVudGV7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcblx0aW9uLWhlYWRlcntcblx0XHRkaXNwbGF5OiBub25lO1xuXHR9XG59XG4iLCIuaXRlbS10cm4ge1xuICAtLWNvbG9yOiNmNWY1ZjU7XG59XG5cbi5pdGVtLW5vLWJhY2tncm91bmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICMwMDAwO1xuICAtLWJvcmRlci1jb2xvcjogIzAwMDA7XG59XG5cbi5pY29uby1ncmFuZGUge1xuICBtYXgtd2lkdGg6IDM1cHg7XG4gIG1heC1oZWlnaHQ6IDM1cHg7XG4gIG1pbi13aWR0aDogMzVweDtcbiAgbWluLWhlaWdodDogMzVweDtcbn1cblxuLml0ZW0tZm9uZG8ge1xuICAvKiogYmFja2dyb3VuZCAqKi9cbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6I2Y1ZjVmNTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZDojZjVmNWY1XG4gICAgIC8qKiBvYmpldG9zIGRlbCBpdGVtICoqL1xuICAvKiogY29sb3IgZGVsIGl0ZW0gKGRlbnRybyBvYmpldG9zLGxldHJhcykgKiovIDtcbn1cblxuLm1hcmdpbi1jYXJkIHtcbiAgbWFyZ2luLXRvcDogNCU7XG59XG5cbi5pY29ub3B4IHtcbiAgbWluLXdpZHRoOiAzMHB4O1xuICBtaW4taGVpZ2h0OiAzMHB4O1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICBiYWNrZ3JvdW5kOiAjMjFhZGExO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1hZG1pbmlzdHJhZG9yIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uY29udGVuZWRvci1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjFhZGExO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG4uaW1hZ2VuLWNhcmQge1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luLWxlZnQ6IDAlO1xuICBtYXJnaW4tdG9wOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbmlvbi1jaGlwIHtcbiAgbWFyZ2luLWxlZnQ6IDQlO1xuICBtYXJnaW4tcmlnaHQ6IDIlO1xuICBtYXJnaW4tYm90dG9tOiAzJTtcbiAgbWFyZ2luLXRvcDogMyU7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6ICMyMWFkYTE7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5oZWFkZXItY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKTtcbn1cbi5oZWFkZXItY2FyZCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi5jYXJkLWdyYWRpZW50ZSB7XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcbiAgaW9uLWhlYWRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/administrador/administrador.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/administrador/administrador.page.ts ***!
  \*****************************************************/
/*! exports provided: AdministradorPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministradorPage", function() { return AdministradorPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");




var AdministradorPage = /** @class */ (function () {
    function AdministradorPage(location, router) {
        this.location = location;
        this.router = router;
    }
    AdministradorPage.prototype.ngOnInit = function () {
    };
    AdministradorPage.prototype.navegar = function (link) {
        this.router.navigate([link]);
    };
    AdministradorPage.prototype.dismiss = function () {
        this.location.back();
    };
    AdministradorPage.ctorParameters = function () { return [
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    AdministradorPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-administrador',
            template: __webpack_require__(/*! raw-loader!./administrador.page.html */ "./node_modules/raw-loader/index.js!./src/app/administrador/administrador.page.html"),
            styles: [__webpack_require__(/*! ./administrador.page.scss */ "./src/app/administrador/administrador.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AdministradorPage);
    return AdministradorPage;
}());



/***/ })

}]);
//# sourceMappingURL=administrador-administrador-module-es5.js.map