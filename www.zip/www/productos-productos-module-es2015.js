(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["productos-productos-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/productos/productos.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/productos/productos.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Productos</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerDatos($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-producto\" src=\"https://image.flaticon.com/icons/png/512/1260/1260185.png\">\n  </div>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"!verAgregar\">\n    <ion-fab-button class=\"ion-fab\">\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n\n         <ion-fab-button (click)=\"redefinirProducto();verAgregar = true;\" *ngIf=\"!verAgregar\">\n           <ion-icon name=\"add\" ></ion-icon>\n         </ion-fab-button>\n\n    </ion-fab-list>\n\n  </ion-fab>\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"verAgregar\">\n    <ion-fab-button class=\"ion-fab\" (click)=\"redefinirProducto();verAgregar = false;\" >\n      <ion-icon name=\"remove\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <br>\n\n  <div *ngIf=\"verAgregar\">\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Titulo</ion-label>\n      <ion-input [(ngModel)]=\"producto.titulo\" ></ion-input>\n    </ion-item>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Descripción</ion-label>\n      <ion-input [(ngModel)]=\"producto.descripcion\" ></ion-input>\n    </ion-item>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">URL</ion-label>\n      <ion-input [(ngModel)]=\"producto.url\" ></ion-input>\n    </ion-item>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Puntos</ion-label>\n      <ion-input [(ngModel)]=\"producto.puntos\" ></ion-input>\n    </ion-item>\n    <br>\n    <br>\n    <ion-item-divider mode=\"md\">\n\n    </ion-item-divider>\n    <ion-button class=\"ion-button\" *ngIf=\"producto.id == '' \" [disabled]=\" producto.titulo == '' || producto.puntos == 0\"  size=\"medium\" (click)=\"confirmar()\">Guardar</ion-button>\n    <ion-button class=\"ion-button\" *ngIf=\"producto.id != ''\" [disabled]=\" producto.titulo == '' || producto.puntos == 0\"   size=\"medium\" (click)=\"actualizarProducto();verAgregar = false\">Actualizar</ion-button>\n\n  </div>\n\n   <br>\n\n   <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n     <b>Lista de Productos</b>\n   </ion-item-divider>\n\n   <ion-list>\n\n     <ion-item-sliding  *ngFor=\"let producto of productos;index as i\" #slidingItem  >\n      <ion-item-options side=\"start\">\n        <ion-item-option color=\"danger\" expandable (click)=\"eliminar(ev,slidingItem)\">\n          <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n\n      <ion-item>\n        <ion-label (click)=\"visualizar(producto,slidingItem);verAgregar = true\">{{producto.titulo}}</ion-label>\n      </ion-item>\n\n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"secondary\"expandable (click)=\"visualizar(producto,slidingItem);verAgregar = true;\">\n          <ion-icon  slot=\"icon-only\" name=\"eye\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n\n\n   </ion-list>\n   \n</ion-content>\n"

/***/ }),

/***/ "./src/app/administrador/usuarios/productos/productos-routing.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/administrador/usuarios/productos/productos-routing.module.ts ***!
  \******************************************************************************/
/*! exports provided: ProductosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductosPageRoutingModule", function() { return ProductosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _productos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./productos.page */ "./src/app/administrador/usuarios/productos/productos.page.ts");




const routes = [
    {
        path: '',
        component: _productos_page__WEBPACK_IMPORTED_MODULE_3__["ProductosPage"]
    }
];
let ProductosPageRoutingModule = class ProductosPageRoutingModule {
};
ProductosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductosPageRoutingModule);



/***/ }),

/***/ "./src/app/administrador/usuarios/productos/productos.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/administrador/usuarios/productos/productos.module.ts ***!
  \**********************************************************************/
/*! exports provided: ProductosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductosPageModule", function() { return ProductosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _productos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./productos-routing.module */ "./src/app/administrador/usuarios/productos/productos-routing.module.ts");
/* harmony import */ var _productos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./productos.page */ "./src/app/administrador/usuarios/productos/productos.page.ts");







let ProductosPageModule = class ProductosPageModule {
};
ProductosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _productos_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductosPageRoutingModule"]
        ],
        declarations: [_productos_page__WEBPACK_IMPORTED_MODULE_6__["ProductosPage"]]
    })
], ProductosPageModule);



/***/ }),

/***/ "./src/app/productos/productos-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/productos/productos-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: ProductosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductosPageRoutingModule", function() { return ProductosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _productos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./productos.page */ "./src/app/productos/productos.page.ts");




const routes = [
    {
        path: '',
        component: _productos_page__WEBPACK_IMPORTED_MODULE_3__["ProductosPage"]
    }
];
let ProductosPageRoutingModule = class ProductosPageRoutingModule {
};
ProductosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductosPageRoutingModule);



/***/ }),

/***/ "./src/app/productos/productos.module.ts":
/*!***********************************************!*\
  !*** ./src/app/productos/productos.module.ts ***!
  \***********************************************/
/*! exports provided: ProductosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductosPageModule", function() { return ProductosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _productos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./productos-routing.module */ "./src/app/productos/productos-routing.module.ts");
/* harmony import */ var _productos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./productos.page */ "./src/app/productos/productos.page.ts");







let ProductosPageModule = class ProductosPageModule {
};
ProductosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _productos_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductosPageRoutingModule"]
        ],
        declarations: [_productos_page__WEBPACK_IMPORTED_MODULE_6__["ProductosPage"]]
    })
], ProductosPageModule);



/***/ }),

/***/ "./src/app/productos/productos.page.scss":
/*!***********************************************!*\
  !*** ./src/app/productos/productos.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  text-align: center;\n  --background: #b5f7cf;\n  --color:white;\n}\n\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n\n.imagen-producto {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.imagen-card {\n  width: 50px;\n  margin-left: 0%;\n  margin-top: 0%;\n  margin-bottom: 0%;\n}\n\n.contenedor-descripcion {\n  text-align: center;\n  width: 90%;\n  margin-top: 5%;\n  margin-left: 5%;\n  margin-bottom: 5%;\n}\n\n.seccion-secciones {\n  display: -webkit-box;\n  display: flex;\n  margin-top: 2.5%;\n}\n\n.seccion-preguntas {\n  width: 70%;\n}\n\n.pregunta {\n  margin-left: 5% !important;\n}\n\n.seccion-estrellas {\n  width: 30%;\n}\n\n.seccion-estrellas ion-badge {\n  margin-left: 1.5%;\n  --background: transparent;\n  --color: #424242;\n}\n\n.seccion-estrellas .icono {\n  width: 25px;\n  height: 25px;\n}\n\n.seccion-estrellas .cambiador {\n  color: #ffd600;\n}\n\n.ion-item {\n  --border-color: transparent;\n}\n\n.ion-fab {\n  --background: #a5e2bd;\n  --background-hover: #a5e2bd;\n  --background-activated: #a5e2bd;\n  --background-focused: #a5e2bd;\n}\n\n.ion-button {\n  --background: #b5f7cf;\n  --background-activated: #b5f7cf;\n  --background-hover: #b5f7cf;\n  width: 70% !important;\n  margin-left: 15% !important;\n  margin-top: 10%;\n  margin-bottom: 10%;\n}\n\n@media (max-width: 550px) {\n  .seccion-secciones {\n    display: inline !important;\n    margin-top: 2.5%;\n  }\n\n  .seccion-preguntas {\n    margin-top: 5%;\n    margin-left: 0% !important;\n    width: 100%;\n    text-align: center !important;\n  }\n\n  .pregunta {\n    margin-top: 10% !important;\n    margin-left: 0% !important;\n  }\n\n  .seccion-estrellas {\n    margin-top: 5%;\n    width: 50% !important;\n    margin-left: 25%;\n  }\n  .seccion-estrellas ion-badge {\n    margin-left: 1.5%;\n    margin-left: 1.5%;\n    --background: transparent;\n    --color: #424242;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvcHJvZHVjdG9zL3Byb2R1Y3Rvcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3Byb2R1Y3Rvcy9wcm9kdWN0b3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7QUNDSjs7QURDRTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNFSDs7QURDRTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0VKOztBREFFO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNHSjs7QURERTtFQUVFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNHSjs7QURJRTtFQUNFLG9CQUFBO0VBQUEsYUFBQTtFQUNBLGdCQUFBO0FDREo7O0FER0U7RUFDRSxVQUFBO0FDQUo7O0FER0U7RUFDRSwwQkFBQTtBQ0FKOztBREdFO0VBQ0UsVUFBQTtBQ0FKOztBRENJO0VBQ0UsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FDQ047O0FERUk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ0FOOztBREdJO0VBQ0UsY0FBQTtBQ0ROOztBRE1FO0VBQ0UsMkJBQUE7QUNISjs7QURNRTtFQUNFLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0FDSEo7O0FETUU7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDSEo7O0FETUU7RUFFRTtJQUNFLDBCQUFBO0lBQ0EsZ0JBQUE7RUNKSjs7RURPRTtJQUNFLGNBQUE7SUFDQSwwQkFBQTtJQUNBLFdBQUE7SUFDQSw2QkFBQTtFQ0pKOztFRE9FO0lBQ0UsMEJBQUE7SUFDQSwwQkFBQTtFQ0pKOztFRE9FO0lBQ0UsY0FBQTtJQUNBLHFCQUFBO0lBQ0EsZ0JBQUE7RUNKSjtFREtJO0lBQ0UsaUJBQUE7SUFDQSxpQkFBQTtJQUNBLHlCQUFBO0lBQ0EsZ0JBQUE7RUNITjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvcHJvZHVjdG9zL3Byb2R1Y3Rvcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAgIC0tY29sb3I6d2hpdGU7XG4gIH1cbiAgLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICAgIGJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIFx0bWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cblxuICAuaW1hZ2VuLXByb2R1Y3Rve1xuICAgIHdpZHRoOiAyMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBtYXJnaW4tYm90dG9tOiA1JTtcbiAgfVxuICAuaW1hZ2VuLWNhcmR7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi10b3A6IDAlO1xuICAgIG1hcmdpbi1ib3R0b206IDAlO1xuICB9XG4gIC5jb250ZW5lZG9yLWRlc2NyaXBjaW9uXG4gIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBtYXJnaW4tbGVmdDogNSU7XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cblxuICAuZGVzY3JpcGNpb257XG5cbiAgfVxuXG4gIC5zZWNjaW9uLXNlY2Npb25lc3tcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIG1hcmdpbi10b3A6IDIuNSU7XG4gIH1cbiAgLnNlY2Npb24tcHJlZ3VudGFze1xuICAgIHdpZHRoOiA3MCU7XG4gIH1cblxuICAucHJlZ3VudGF7XG4gICAgbWFyZ2luLWxlZnQ6IDUlICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuc2VjY2lvbi1lc3RyZWxsYXN7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBpb24tYmFkZ2V7XG4gICAgICBtYXJnaW4tbGVmdDogMS41JTtcbiAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAtLWNvbG9yOiAjNDI0MjQyO1xuICAgIH1cblxuICAgIC5pY29ub3tcbiAgICAgIHdpZHRoOiAyNXB4O1xuICAgICAgaGVpZ2h0OiAyNXB4O1xuICAgIH1cblxuICAgIC5jYW1iaWFkb3J7XG4gICAgICBjb2xvcjogI2ZmZDYwMDtcbiAgICB9XG5cbiAgfVxuXG4gIC5pb24taXRlbXtcbiAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIH1cblxuICAuaW9uLWZhYntcbiAgICAtLWJhY2tncm91bmQ6ICNhNWUyYmQ7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYTVlMmJkO1xuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICNhNWUyYmQ7XG4gICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICNhNWUyYmQ7XG4gIH1cblxuICAuaW9uLWJ1dHRvbntcbiAgICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6ICNiNWY3Y2Y7XG4gICAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tdG9wOiAxMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogMTAlO1xuICB9XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU1MHB4KSB7XG5cbiAgICAuc2VjY2lvbi1zZWNjaW9uZXN7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUgIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi10b3A6IDIuNSU7XG4gICAgfVxuXG4gICAgLnNlY2Npb24tcHJlZ3VudGFze1xuICAgICAgbWFyZ2luLXRvcDogNSU7XG4gICAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgLnByZWd1bnRhe1xuICAgICAgbWFyZ2luLXRvcDogMTAlICFpbXBvcnRhbnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCUgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuc2VjY2lvbi1lc3RyZWxsYXN7XG4gICAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICAgIHdpZHRoOiA1MCUgIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAyNSU7XG4gICAgICBpb24tYmFkZ2V7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxLjUlO1xuICAgICAgICBtYXJnaW4tbGVmdDogMS41JTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1jb2xvcjogIzQyNDI0MjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiIsImlvbi10b29sYmFyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIC0tY29sb3I6d2hpdGU7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbiB7XG4gIGJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLXByb2R1Y3RvIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4uaW1hZ2VuLWNhcmQge1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luLWxlZnQ6IDAlO1xuICBtYXJnaW4tdG9wOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMCU7XG59XG5cbi5jb250ZW5lZG9yLWRlc2NyaXBjaW9uIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB3aWR0aDogOTAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLnNlY2Npb24tc2VjY2lvbmVzIHtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLXRvcDogMi41JTtcbn1cblxuLnNlY2Npb24tcHJlZ3VudGFzIHtcbiAgd2lkdGg6IDcwJTtcbn1cblxuLnByZWd1bnRhIHtcbiAgbWFyZ2luLWxlZnQ6IDUlICFpbXBvcnRhbnQ7XG59XG5cbi5zZWNjaW9uLWVzdHJlbGxhcyB7XG4gIHdpZHRoOiAzMCU7XG59XG4uc2VjY2lvbi1lc3RyZWxsYXMgaW9uLWJhZGdlIHtcbiAgbWFyZ2luLWxlZnQ6IDEuNSU7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tY29sb3I6ICM0MjQyNDI7XG59XG4uc2VjY2lvbi1lc3RyZWxsYXMgLmljb25vIHtcbiAgd2lkdGg6IDI1cHg7XG4gIGhlaWdodDogMjVweDtcbn1cbi5zZWNjaW9uLWVzdHJlbGxhcyAuY2FtYmlhZG9yIHtcbiAgY29sb3I6ICNmZmQ2MDA7XG59XG5cbi5pb24taXRlbSB7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmlvbi1mYWIge1xuICAtLWJhY2tncm91bmQ6ICNhNWUyYmQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogI2E1ZTJiZDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2E1ZTJiZDtcbiAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICNhNWUyYmQ7XG59XG5cbi5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjYjVmN2NmO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICNiNWY3Y2Y7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiAxMCU7XG4gIG1hcmdpbi1ib3R0b206IDEwJTtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDU1MHB4KSB7XG4gIC5zZWNjaW9uLXNlY2Npb25lcyB7XG4gICAgZGlzcGxheTogaW5saW5lICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLXRvcDogMi41JTtcbiAgfVxuXG4gIC5zZWNjaW9uLXByZWd1bnRhcyB7XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgbWFyZ2luLWxlZnQ6IDAlICFpbXBvcnRhbnQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gIH1cblxuICAucHJlZ3VudGEge1xuICAgIG1hcmdpbi10b3A6IDEwJSAhaW1wb3J0YW50O1xuICAgIG1hcmdpbi1sZWZ0OiAwJSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnNlY2Npb24tZXN0cmVsbGFzIHtcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICB3aWR0aDogNTAlICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDI1JTtcbiAgfVxuICAuc2VjY2lvbi1lc3RyZWxsYXMgaW9uLWJhZGdlIHtcbiAgICBtYXJnaW4tbGVmdDogMS41JTtcbiAgICBtYXJnaW4tbGVmdDogMS41JTtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIC0tY29sb3I6ICM0MjQyNDI7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/productos/productos.page.ts":
/*!*********************************************!*\
  !*** ./src/app/productos/productos.page.ts ***!
  \*********************************************/
/*! exports provided: ProductosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductosPage", function() { return ProductosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_servicios/encuestas.service */ "./src/app/_servicios/encuestas.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




let ProductosPage = class ProductosPage {
    constructor(toastController, alertController, productoService) {
        this.toastController = toastController;
        this.alertController = alertController;
        this.productoService = productoService;
        this.producto = { titulo: '', descripcion: '', url: '', puntos: 0, id: '', fecha: new Date(), empresaId: '' };
        this.verAgregar = false;
        this.activos = [];
        this.usuarios = [];
        this.mensaje = "";
        this.sucursal = "";
        this.indice = 0;
        this.puntos = 0;
        this.pasos = [];
        this.inputs = [];
        this.porcentaje = 0;
        this.productos = [];
        this.jerarquia = [];
        this.arbol = [];
        this.count = 0;
    }
    ngOnInit() {
        this.traerDatos();
    }
    traerDatos() {
        this.productoService.listar().subscribe(datos => {
            console.log(datos);
            this.productos = datos;
        });
    }
    visualizar(producto, slide) {
        console.log(producto);
        this.producto = producto;
        slide.close();
    }
    redefinirProducto() {
        this.producto = { titulo: '', descripcion: '', url: '', puntos: 0, id: '', fecha: new Date(), empresaId: '' };
    }
    confirmar() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Favor confirmar!',
                message: 'Estas a punto de <br><strong>CREAR UN PRODUCTO</strong>!!!',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Cancelado');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            this.guardarProducto();
                            this.verAgregar = false;
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    guardarProducto() {
        this.productoService.insertar(this.producto).subscribe(data => {
            console.log(data);
        });
        this.producto = { titulo: '', descripcion: '', url: '', puntos: 0, id: '', fecha: new Date(), empresaId: '' };
        this.traerDatos();
    }
    actualizarProducto() {
        this.productoService.actualizar(this.producto.id, this.producto).subscribe(data => {
            console.log(data);
        });
        this.producto = { titulo: '', descripcion: '', url: '', puntos: 0, id: '', fecha: new Date(), empresaId: '' };
        this.traerDatos();
    }
    alertBorrar(ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Favor confirmar!',
                message: 'Estas a punto de <br><strong>BORRAR UN PRODUCTO</strong>!!!',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Cancelado');
                        }
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            this.borrarProducto(ev);
                            this.verAgregar = false;
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    eliminar(ev, slide) {
        this.alertBorrar(ev);
        slide.close();
    }
    borrarProducto(ev) {
        this.productoService.borrar(ev.id).subscribe(dato => {
            console.log(dato);
            this.ngOnInit();
        });
    }
};
ProductosPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_2__["ProductoService"] }
];
ProductosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-productos',
        template: __webpack_require__(/*! raw-loader!./productos.page.html */ "./node_modules/raw-loader/index.js!./src/app/productos/productos.page.html"),
        styles: [__webpack_require__(/*! ./productos.page.scss */ "./src/app/productos/productos.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
        _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_2__["ProductoService"]])
], ProductosPage);



/***/ })

}]);
//# sourceMappingURL=productos-productos-module-es2015.js.map