(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pregunta-pregunta-module"],{

/***/ "./src/app/encuestas/pregunta/pregunta-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/encuestas/pregunta/pregunta-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: PreguntaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreguntaPageRoutingModule", function() { return PreguntaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _pregunta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pregunta.page */ "./src/app/encuestas/pregunta/pregunta.page.ts");




const routes = [
    {
        path: '',
        component: _pregunta_page__WEBPACK_IMPORTED_MODULE_3__["PreguntaEncuestaPage"]
    },
    {
        path: 'crud-encuesta',
        loadChildren: () => __webpack_require__.e(/*! import() | crud-encuesta-crud-encuesta-module */ "crud-encuesta-crud-encuesta-module").then(__webpack_require__.bind(null, /*! ./crud-encuesta/crud-encuesta.module */ "./src/app/encuestas/pregunta/crud-encuesta/crud-encuesta.module.ts")).then(m => m.CrudEncuestaPageModule)
    }
];
let PreguntaPageRoutingModule = class PreguntaPageRoutingModule {
};
PreguntaPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PreguntaPageRoutingModule);



/***/ }),

/***/ "./src/app/encuestas/pregunta/pregunta.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/encuestas/pregunta/pregunta.module.ts ***!
  \*******************************************************/
/*! exports provided: PreguntaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreguntaPageModule", function() { return PreguntaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pregunta_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pregunta-routing.module */ "./src/app/encuestas/pregunta/pregunta-routing.module.ts");
/* harmony import */ var _pregunta_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pregunta.page */ "./src/app/encuestas/pregunta/pregunta.page.ts");







let PreguntaPageModule = class PreguntaPageModule {
};
PreguntaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _pregunta_routing_module__WEBPACK_IMPORTED_MODULE_5__["PreguntaPageRoutingModule"]
        ],
        declarations: [_pregunta_page__WEBPACK_IMPORTED_MODULE_6__["PreguntaEncuestaPage"]]
    })
], PreguntaPageModule);



/***/ })

}]);
//# sourceMappingURL=pregunta-pregunta-module-es2015.js.map