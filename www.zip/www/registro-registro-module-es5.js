(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["registro-registro-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/registro/registro.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/registro/registro.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>registro</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content  color=\"primary\">\n  <form  #form=\"ngForm\" (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <div text-center>\n            <h3>Create your account!</h3>\n          </div>\n          <div padding>\n            <ion-item>\n              <ion-input  name=\"name\" type=\"text\" placeholder=\"Name\" ngModel required></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-input  name=\"lastname\" type=\"text\" placeholder=\"lastName\" ngModel required></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-input name=\"email\" type=\"email\" placeholder=\"your@email.com\" ngModel required></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-input name=\"password\" type=\"password\" placeholder=\"Password\" ngModel required></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-input name=\"confirm\" type=\"password\" placeholder=\"Password again\" ngModel required></ion-input>\n            </ion-item>\n          </div>\n          <div padding>\n            <ion-button  size=\"medium\" type=\"submit\" [disabled]=\"form.invalid\" expand=\"block\">Register</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/registro/registro-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/registro/registro-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: RegistroPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistroPageRoutingModule", function() { return RegistroPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _registro_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./registro.page */ "./src/app/registro/registro.page.ts");




var routes = [
    {
        path: '',
        component: _registro_page__WEBPACK_IMPORTED_MODULE_3__["RegistroPage"]
    }
];
var RegistroPageRoutingModule = /** @class */ (function () {
    function RegistroPageRoutingModule() {
    }
    RegistroPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], RegistroPageRoutingModule);
    return RegistroPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/registro/registro.module.ts":
/*!*********************************************!*\
  !*** ./src/app/registro/registro.module.ts ***!
  \*********************************************/
/*! exports provided: RegistroPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistroPageModule", function() { return RegistroPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _registro_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./registro-routing.module */ "./src/app/registro/registro-routing.module.ts");
/* harmony import */ var _registro_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./registro.page */ "./src/app/registro/registro.page.ts");







var RegistroPageModule = /** @class */ (function () {
    function RegistroPageModule() {
    }
    RegistroPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _registro_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegistroPageRoutingModule"]
            ],
            declarations: [_registro_page__WEBPACK_IMPORTED_MODULE_6__["RegistroPage"]]
        })
    ], RegistroPageModule);
    return RegistroPageModule;
}());



/***/ }),

/***/ "./src/app/registro/registro.page.scss":
/*!*********************************************!*\
  !*** ./src/app/registro/registro.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n  --color: white !important;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\n.header-card {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%);\n}\n\n.header-card ion-item {\n  --background: transparent;\n  --color: white;\n  --border-color: transparent;\n}\n\n.card-gradiente {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white !important;\n}\n\nion-fab-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --color: white;\n}\n\nion-button {\n  --background: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-activated: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  --background-hover: linear-gradient(90deg, rgba(3,169,244,1) 0%, rgba(128,222,234,1) 100%) !important;\n  width: 60% !important;\n  margin-left: 20% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvcmVnaXN0cm8vcmVnaXN0cm8ucGFnZS5zY3NzIiwic3JjL2FwcC9yZWdpc3Ryby9yZWdpc3Ryby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRTs7O0dBQUE7RUFLQSxvRkFBQTtFQUNBLHlCQUFBO0FDQUY7O0FER0E7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNLRjs7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxvRkFBQTtBQ0NGOztBREFFO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUNFRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUJBQUE7QUNDRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLCtGQUFBO0VBQ0EseUdBQUE7RUFDQSxxR0FBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdHJvL3JlZ2lzdHJvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbXsvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLmhlYWRlci1jYXJke1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIGlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbi5jYXJkLWdyYWRpZW50ZXtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mYWItYnV0dG9ue1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMywxNjksMjQ0LDEpIDAlLCByZ2JhKDEyOCwyMjIsMjM0LDEpIDEwMCUpICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICB3aWR0aDogNjAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAyMCUgIWltcG9ydGFudDtcbn1cbiIsImlvbi10b29sYmFyIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG4uaGVhZGVyLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSk7XG59XG4uaGVhZGVyLWNhcmQgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY2FyZC1ncmFkaWVudGUge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDMsMTY5LDI0NCwxKSAwJSwgcmdiYSgxMjgsMjIyLDIzNCwxKSAxMDAlKSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgzLDE2OSwyNDQsMSkgMCUsIHJnYmEoMTI4LDIyMiwyMzQsMSkgMTAwJSkgIWltcG9ydGFudDtcbiAgd2lkdGg6IDYwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMjAlICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/registro/registro.page.ts":
/*!*******************************************!*\
  !*** ./src/app/registro/registro.page.ts ***!
  \*******************************************/
/*! exports provided: RegistroPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistroPage", function() { return RegistroPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var RegistroPage = /** @class */ (function () {
    function RegistroPage() {
    }
    RegistroPage.prototype.ngOnInit = function () {
    };
    RegistroPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-registro',
            template: __webpack_require__(/*! raw-loader!./registro.page.html */ "./node_modules/raw-loader/index.js!./src/app/registro/registro.page.html"),
            styles: [__webpack_require__(/*! ./registro.page.scss */ "./src/app/registro/registro.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], RegistroPage);
    return RegistroPage;
}());



/***/ })

}]);
//# sourceMappingURL=registro-registro-module-es5.js.map