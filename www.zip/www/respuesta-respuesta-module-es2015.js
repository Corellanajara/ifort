(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["respuesta-respuesta-module"],{

/***/ "./src/app/evaluaciones/instrumento/respuesta/respuesta-routing.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/evaluaciones/instrumento/respuesta/respuesta-routing.module.ts ***!
  \********************************************************************************/
/*! exports provided: RespuestaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RespuestaPageRoutingModule", function() { return RespuestaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _respuesta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./respuesta.page */ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.ts");




const routes = [
    {
        path: '',
        component: _respuesta_page__WEBPACK_IMPORTED_MODULE_3__["RespuestaPage"]
    }
];
let RespuestaPageRoutingModule = class RespuestaPageRoutingModule {
};
RespuestaPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RespuestaPageRoutingModule);



/***/ }),

/***/ "./src/app/evaluaciones/instrumento/respuesta/respuesta.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/evaluaciones/instrumento/respuesta/respuesta.module.ts ***!
  \************************************************************************/
/*! exports provided: RespuestaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RespuestaPageModule", function() { return RespuestaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _respuesta_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./respuesta-routing.module */ "./src/app/evaluaciones/instrumento/respuesta/respuesta-routing.module.ts");
/* harmony import */ var _respuesta_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./respuesta.page */ "./src/app/evaluaciones/instrumento/respuesta/respuesta.page.ts");







let RespuestaPageModule = class RespuestaPageModule {
};
RespuestaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _respuesta_routing_module__WEBPACK_IMPORTED_MODULE_5__["RespuestaPageRoutingModule"]
        ],
        declarations: [_respuesta_page__WEBPACK_IMPORTED_MODULE_6__["RespuestaPage"]]
    })
], RespuestaPageModule);



/***/ })

}]);
//# sourceMappingURL=respuesta-respuesta-module-es2015.js.map