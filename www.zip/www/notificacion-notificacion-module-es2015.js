(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["notificacion-notificacion-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/notificacion/notificacion.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/notificacion/notificacion.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Notificaciones</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerDatos($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-notificacion\" src=\"https://image.flaticon.com/icons/png/512/1260/1260185.png\">\n  </div>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"!verAgregar\">\n    <ion-fab-button>\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n\n         <ion-fab-button (click)=\"abrirImportar();verAgregar = false;\" >\n           <ion-icon name=\"document\" ></ion-icon>\n         </ion-fab-button>\n\n         <ion-fab-button (click)=\"redefinirnotificacion();verAgregar = true;\" *ngIf=\"!verAgregar\">\n           <ion-icon name=\"add\" ></ion-icon>\n         </ion-fab-button>\n\n    </ion-fab-list>\n\n  </ion-fab>\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"verAgregar\">\n    <ion-fab-button (click)=\"redefinirnotificacion();verAgregar = false;\" >\n      <ion-icon name=\"remove\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <br>\n  <div *ngIf=\"verAgregar\">\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Titulo</ion-label>\n      <ion-input [(ngModel)]=\"notificacion.titulo\" ></ion-input>\n    </ion-item>\n    <br>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Descripción</ion-label>\n      <ion-textarea [(ngModel)]=\"notificacion.descripcion\" ></ion-textarea>\n    </ion-item>\n    <br>\n    <ion-item-divider mode=\"md\">\n\n    </ion-item-divider>\n\n    <ion-button class=\"ion-button\" *ngIf=\"notificacion.id == '' \" [disabled]=\" notificacion.titulo == '' \"  size=\"medium\" (click)=\"confirmar();verAgregar = false;\">Guardar</ion-button>\n    <ion-button class=\"ion-button\" *ngIf=\"notificacion.id != ''\" [disabled]=\" notificacion.titulo == '' \"   size=\"medium\" (click)=\"actualizarnotificacion();verAgregar = false\">Actualizar</ion-button>\n\n  </div>\n  <p style=\"text-align:center\" *ngIf=\"notificacion.id != '' && !verAgregar\">\n    notificacion \" {{notificacion.titulo}} \"\n  </p>\n   <br>\n\n   <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n     <b>Lista de notificaciones</b>\n   </ion-item-divider>\n\n   <ion-list>\n\n     <ion-item-sliding  *ngFor=\"let notificacion of notificaciones;index as i\" #slidingItem  >\n      <ion-item-options side=\"start\">\n        <ion-item-option color=\"danger\" expandable (click)=\"eliminar(ev)\">\n          <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n\n      <ion-item>\n        <ion-label (click)=\"visualizar(ev,slidingItem);verAgregar = true\">{{notificacion.titulo}}</ion-label>\n      </ion-item>\n\n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"secondary\"expandable (click)=\"visualizar(notificacion,slidingItem);verAgregar = true;\">\n          <ion-icon  slot=\"icon-only\" name=\"eye\"></ion-icon>\n        </ion-item-option>\n        <ion-item-option color=\"secondary\"expandable (click)=\"visualizar(notificacion,slidingItem);verAgregar = false;\">\n          <ion-icon name=\"checkmark\" style=\"font-size:20px\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n\n\n   </ion-list>\n\n    <div class=\"seleccionable-evaluacion\" *ngIf=\"notificacion.id != ''\" >\n      <ion-toolbar >\n        <ion-segment scrollable  color=\"secondary\">\n          <ion-segment-button *ngIf=\"this.pasos.length > 0\">\n            <ion-icon name=\"arrow-back\" style=\"font-size:25px;\"  (click)=\"volver()\"></ion-icon>\n          </ion-segment-button>\n\n          <ion-segment-button value=\"{{nodo.name}}\" *ngFor=\"let nodo of arbol;index as index\" (click)=\"seleccionaNodo(nodo,indice)\" (dblclick)=\"navegaNodo(nodo,index,true)\">\n            <ion-label color=\"blanco\">{{nodo.name}}</ion-label>\n          </ion-segment-button>\n        </ion-segment>\n      </ion-toolbar>\n   </div>\n   <h3 class=\"mensaje\">{{mensaje}}</h3>\n\n   <ion-button  class=\"ion-button\" [disabled]=\"!nodo \" size=\"medium\" (click)=\"enviarnotificacion()\">Enviar notificación</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/notificacion/notificacion-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/notificacion/notificacion-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: NotificacionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacionPageRoutingModule", function() { return NotificacionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _notificacion_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./notificacion.page */ "./src/app/notificacion/notificacion.page.ts");




const routes = [
    {
        path: '',
        component: _notificacion_page__WEBPACK_IMPORTED_MODULE_3__["NotificacionPage"]
    }
];
let NotificacionPageRoutingModule = class NotificacionPageRoutingModule {
};
NotificacionPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NotificacionPageRoutingModule);



/***/ }),

/***/ "./src/app/notificacion/notificacion.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/notificacion/notificacion.module.ts ***!
  \*****************************************************/
/*! exports provided: NotificacionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacionPageModule", function() { return NotificacionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notificacion_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notificacion-routing.module */ "./src/app/notificacion/notificacion-routing.module.ts");
/* harmony import */ var _notificacion_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notificacion.page */ "./src/app/notificacion/notificacion.page.ts");







let NotificacionPageModule = class NotificacionPageModule {
};
NotificacionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _notificacion_routing_module__WEBPACK_IMPORTED_MODULE_5__["NotificacionPageRoutingModule"]
        ],
        declarations: [_notificacion_page__WEBPACK_IMPORTED_MODULE_6__["NotificacionPage"]]
    })
], NotificacionPageModule);



/***/ }),

/***/ "./src/app/notificacion/notificacion.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/notificacion/notificacion.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #b5f7cf;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n\n.imagen-notificacion {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.mensaje {\n  text-align: center;\n  margin-top: 5%;\n  margin-bottom: 10;\n  color: #29b6f6;\n  font-style: bold;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n\nion-fab-button {\n  --background: #b5f7cf;\n  --background-activated: #b5f7cf;\n  --background-hover: #b5f7cf;\n  --color: white;\n}\n\n.ion-button {\n  --background: #b5f7cf;\n  --background-activated: #b5f7cf;\n  --background-hover: #b5f7cf;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n.ion-button-indicador {\n  --background: #80deea;\n  --background-activated: #80deea;\n  --background-hover: #80deea;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n@media (min-width: 900px) {\n  ion-header {\n    display: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvbm90aWZpY2FjaW9uL25vdGlmaWNhY2lvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL25vdGlmaWNhY2lvbi9ub3RpZmljYWNpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFFQSxxQkFBQTtFQUNBLGtCQUFBO0FDREY7O0FESUE7RUFDRSxtQkFBQTtFQUNELGlCQUFBO0FDREQ7O0FESUE7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNERjs7QURJQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDREY7O0FER0E7RUFBUzs7O0dBQUE7RUFJUCw0QkFBQTtFQUNBLDBCQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBOzs7O0dBQUE7QUNLRjs7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxpQ0FBQTtBQ0NGOztBREVBO0VBQ0UscUJBQUE7RUFDQSwrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UscUJBQUE7RUFDQSwrQkFBQTtFQUNBLDJCQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtBQ0NGOztBREVBO0VBQ0UscUJBQUE7RUFDQSwrQkFBQTtFQUNBLDJCQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtBQ0NGOztBREVBO0VBRUU7SUFDRSxhQUFBO0VDQUY7QUFDRiIsImZpbGUiOiJzcmMvYXBwL25vdGlmaWNhY2lvbi9ub3RpZmljYWNpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJ7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cblxuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIC8vLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb250ZW5lZG9yLWltYWdlbntcbiAgYmFja2dyb3VuZDogI2I1ZjdjZjtcblx0bWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tbm90aWZpY2FjaW9ue1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5tZW5zYWple1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7O1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogMTA7XG4gIGNvbG9yOiAjMjliNmY2O1xuICBmb250LXN0eWxlOiBib2xkO1xufVxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbmlvbi1mYWJ7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1idXR0b24taW5kaWNhZG9ye1xuICAtLWJhY2tncm91bmQ6ICM4MGRlZWE7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICM4MGRlZWE7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzgwZGVlYTtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5MDBweCkge1xuXG4gIGlvbi1oZWFkZXJ7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxufVxuIiwiLnRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tbm90aWZpY2FjaW9uIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4ubWVuc2FqZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDEwO1xuICBjb2xvcjogIzI5YjZmNjtcbiAgZm9udC1zdHlsZTogYm9sZDtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbmlvbi1mYWIge1xuICAtLWJhY2tncm91bmQ6IHJnYmEoMTI4LDIyMiwyMzQsMSk7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjYjVmN2NmO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjYjVmN2NmO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICNiNWY3Y2Y7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG4uaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1idXR0b24taW5kaWNhZG9yIHtcbiAgLS1iYWNrZ3JvdW5kOiAjODBkZWVhO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjODBkZWVhO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM4MGRlZWE7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogOTAwcHgpIHtcbiAgaW9uLWhlYWRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/notificacion/notificacion.page.ts":
/*!***************************************************!*\
  !*** ./src/app/notificacion/notificacion.page.ts ***!
  \***************************************************/
/*! exports provided: NotificacionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacionPage", function() { return NotificacionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_servicios/encuestas.service */ "./src/app/_servicios/encuestas.service.ts");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");





let NotificacionPage = class NotificacionPage {
    constructor(toastController, alertController, nService, userService, modalCtrl) {
        this.toastController = toastController;
        this.alertController = alertController;
        this.nService = nService;
        this.userService = userService;
        this.modalCtrl = modalCtrl;
        this.notificaciones = [];
        this.verAgregar = false;
        this.usuarios = [];
        this.notificacion = { id: '', titulo: '', descripcion: '' };
        this.mensaje = "";
        this.sucursal = "";
        this.indice = 0;
        this.puntos = 0;
        this.pasos = [];
        this.inputs = [];
        this.porcentaje = 0;
        this.jerarquia = [];
        this.arbol = [];
        this.count = 0;
    }
    ngOnInit() {
        this.jerarquia = JSON.parse(sessionStorage.getItem('jerarquia'));
        var arbol = JSON.parse(sessionStorage.getItem('jerarquia')).toString();
        this.arbol = JSON.parse(arbol);
        console.log(this.arbol);
        this.userService.listar().subscribe(usuarios => {
            console.log(usuarios);
            this.usuarios = usuarios;
        });
        this.traerDatos(false);
    }
    traerDatos(evento) {
        this.nService.listar().subscribe(datos => {
            console.log(datos);
            this.notificaciones = datos;
            if (evento) {
                evento.target.complete();
            }
        });
    }
    confirmar() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Favor confirmar!',
                message: 'Estas a punto de <br><strong>CREAR UNA NOTIFICACIÓN</strong>!!!',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Cancelado');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            this.guardarNotificacion();
                            this.verAgregar = false;
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    redefinirnotificacion() {
        this.notificacion = { id: '', titulo: '', descripcion: '' };
    }
    guardarNotificacion() {
        this.nService.insertar(this.notificacion).subscribe(data => {
            console.log(data);
            this.traerDatos(false);
            this.notificacion = { id: '', titulo: '', descripcion: '' };
        });
    }
    visualizar(notificacion, slide) {
        this.notificacion = notificacion;
        slide.close();
    }
    volver() {
        console.log(this.pasos);
        this.pasos.pop();
        console.log(this.pasos);
        var arbol = JSON.parse(sessionStorage.getItem('jerarquia')).toString();
        this.arbol = JSON.parse(arbol);
        for (let i = 0; i < this.pasos.length; i++) {
            this.navegaNodo(this.arbol[this.pasos[i]], this.pasos[i], false);
        }
        this.nodo = undefined;
        this.mensaje = "Seleciona ";
    }
    seleccionaNodo(nodo, indice) {
        console.log("selecciona nodo");
        this.count++;
        setTimeout(() => {
            if (this.count == 1) {
                this.count = 0;
                console.log("hice click en selecciona", nodo);
                this.mensaje = "Seleccionado " + nodo.name;
                this.nodo = nodo;
                this.sucursal = nodo.id;
            }
            if (this.count > 1) {
                console.log("hice click en navega", nodo);
                this.count = 0;
                this.navegaNodo(nodo, indice, true);
            }
        }, 250);
    }
    navegaNodo(nodo, indice, aumentaConteo) {
        console.log(this.arbol);
        console.log(indice);
        if (this.arbol[indice].childrens.length > 0) {
            console.log("navegado");
            this.indice++;
            this.arbol = this.arbol[indice].childrens;
            if (aumentaConteo) {
                this.pasos.push(indice);
            }
            console.log("indice", this.pasos);
        }
        else {
            this.seleccionaNodo(nodo, indice);
        }
    }
    enviarnotificacion() {
        for (let i = 0; i < this.usuarios.length; i++) {
            let usuario = this.usuarios[i];
            var asignado = undefined;
            if (usuario.asignado && usuario.asignado.length > 0) {
                asignado = usuario.asignado[0];
                if (this.encontrarEnNodo(asignado, this.nodo)) {
                    console.log("este usuario existe en el nodo o subsecuentes", usuario);
                    usuario.password = undefined;
                    if (!usuario.notificaciones) {
                        usuario.notificaciones = [];
                    }
                    usuario.notificaciones.push(this.notificacion);
                }
            }
        }
        var usuariosCambiados = [];
        for (let i = 0; i < this.usuarios.length; i++) {
            let usuario = this.usuarios[i];
            var asignado = undefined;
            if (usuario.asignado && usuario.asignado.length > 0) {
                asignado = usuario.asignado[0];
                if (this.encontrarEnNodo(asignado, this.nodo)) {
                    usuariosCambiados.push(usuario);
                    usuario.password = undefined;
                    this.userService.actualizar(usuario.id, usuario).subscribe(data => {
                        console.log(usuario);
                        this.mostrarToast();
                    });
                }
            }
        }
    }
    encontrarEnNodo(asignado, nodo) {
        var quedanHijos = true;
        if (!nodo.childrens) {
            quedanHijos = false;
        }
        if (JSON.stringify(asignado) == JSON.stringify(nodo)) {
            return true;
        }
        else {
            console.log(nodo);
            if (!quedanHijos) {
                return false;
            }
            else {
                for (let i = 0; i < nodo.childrens.length; i++) {
                    let nuevoNodo = nodo.childrens[i];
                    if (JSON.stringify(asignado) == JSON.stringify(nuevoNodo)) {
                        return true;
                    }
                }
            }
            return false;
        }
    }
    mostrarToast() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Las Notificaciones han sido asignadas',
                duration: 2000
            });
            toast.present();
        });
    }
};
NotificacionPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_3__["NotificacionesService"] },
    { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
NotificacionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-notificacion',
        template: __webpack_require__(/*! raw-loader!./notificacion.page.html */ "./node_modules/raw-loader/index.js!./src/app/notificacion/notificacion.page.html"),
        styles: [__webpack_require__(/*! ./notificacion.page.scss */ "./src/app/notificacion/notificacion.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_3__["NotificacionesService"],
        _servicios_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
], NotificacionPage);



/***/ })

}]);
//# sourceMappingURL=notificacion-notificacion-module-es2015.js.map