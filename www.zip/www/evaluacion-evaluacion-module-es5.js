(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["evaluacion-evaluacion-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluacion/evaluacion.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluacion/evaluacion.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Instrumento</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerDatos($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-evaluacion\" src=\"https://image.flaticon.com/icons/png/512/1260/1260185.png\">\n  </div>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"!verAgregar\">\n    <ion-fab-button>\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n\n         <ion-fab-button (click)=\"abrirImportar();verAgregar = false;\" >\n           <ion-icon name=\"document\" ></ion-icon>\n         </ion-fab-button>\n\n         <ion-fab-button (click)=\"redefinirEvaluacion();verAgregar = true;\" *ngIf=\"!verAgregar\">\n           <ion-icon name=\"add\" ></ion-icon>\n         </ion-fab-button>\n\n    </ion-fab-list>\n\n  </ion-fab>\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"verAgregar\">\n    <ion-fab-button (click)=\"redefinirEvaluacion();verAgregar = false;\" >\n      <ion-icon name=\"remove\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n<!--\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\" (click)=\"redefinirEvaluacion();verAgregar = true;\" *ngIf=\"!verAgregar\">\n     <ion-fab-button>\n       <ion-icon name=\"add\" ></ion-icon>\n     </ion-fab-button>\n   </ion-fab>\n   <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\" (click)=\"redefinirEvaluacion();verAgregar = false;\" *ngIf=\"verAgregar\">\n      <ion-fab-button>\n        <ion-icon name=\"remove\" ></ion-icon>\n      </ion-fab-button>\n    </ion-fab>-->\n  <br>\n  <div *ngIf=\"verAgregar\">\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Siglas</ion-label>\n      <ion-input [(ngModel)]=\"evaluacion.sigla\" maxlength=\"5\" ></ion-input>\n    </ion-item>\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Nombre</ion-label>\n      <ion-input [(ngModel)]=\"evaluacion.nombre\" ></ion-input>\n    </ion-item>\n    <br>\n    <br>\n    <ion-item-divider mode=\"md\">\n\n    </ion-item-divider>\n    <ion-button class=\"ion-button-indicador\" (click)=\"abrirPreguntas()\" size=\"medium\" [disabled]=\" evaluacion.nombre == '' \">Ver/Agregar indicador <span *ngIf=\"evaluacion.indicadores\"> ({{getIndicadores(evaluacion.indicadores)}})</span></ion-button>\n    <ion-button class=\"ion-button\" *ngIf=\"evaluacion.id == '' \" [disabled]=\" evaluacion.nombre == '' \"  size=\"medium\" (click)=\"confirmar()\">Guardar</ion-button>\n    <ion-button class=\"ion-button\" *ngIf=\"evaluacion.id != ''\" [disabled]=\" evaluacion.nombre == '' \"   size=\"medium\" (click)=\"actualizarEvaluacion();verAgregar = false\">Actualizar</ion-button>\n\n  </div>\n\n   <br>\n\n   <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n     <b>Lista de evaluaciones</b>\n   </ion-item-divider>\n\n   <ion-list>\n\n     <ion-item-sliding  *ngFor=\"let ev of cantidadInputs(evaluaciones);index as i\" #slidingItem  >\n      <ion-item-options side=\"start\">\n        <ion-item-option color=\"danger\" expandable (click)=\"eliminar(ev,slidingItem)\">\n          <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n\n      <ion-item>\n        <ion-checkbox slot=\"start\"  (ionChange)=\"recalcular()\" [(ngModel)]=\"activos[i]\"></ion-checkbox>\n        <ion-label (click)=\"visualizar(ev,slidingItem);verAgregar = true\">{{ev.nombre}}</ion-label>\n        <ion-input slot=\"end\" type=\"number\" (ionChange)=\"recalcular()\" placeholder=\"%\" [(ngModel)]=\"inputs[i]\" name=\"input{{i}}\"></ion-input>\n      </ion-item>\n\n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"secondary\"expandable (click)=\"visualizar(ev,slidingItem);verAgregar = true;\">\n          <ion-icon  slot=\"icon-only\" name=\"eye\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n\n    <h3 *ngIf=\"evaluaciones.length == 0\">No hay evaluaciones disponibles</h3>\n    <p *ngIf=\"porcentaje>100\" style=\"color:red\">{{porcentaje}}%</p>\n    <ion-item *ngIf=\"porcentaje==100\" style=\"color:green\">\n      <ion-icon name=\"grid\" slot=\"start\"></ion-icon>\n      <ion-label>Equivale a (Puntos)</ion-label>\n      <ion-input slot=\"end\" type=\"number\" placeholder=\"puntos\" [(ngModel)]=\"puntos\" name=\"puntos\"></ion-input>\n    </ion-item>\n    <p *ngIf=\"porcentaje<100\" style=\"color:blue\">{{porcentaje}}%</p>\n   </ion-list>\n\n   <div class=\"\" *ngIf=\"porcentaje == 100\">\n     <ion-toolbar class=\"toolbar\">\n       <ion-segment scrollable  color=\"secondary\">\n         <ion-segment-button *ngIf=\"this.pasos.length > 0\" (click)=\"volver()\">\n           <ion-icon name=\"arrow-back\" style=\"font-size:25px;\"  ></ion-icon>\n         </ion-segment-button>\n\n         <ion-segment-button value=\"{{nodo.name}}\" *ngFor=\"let nodo of arbol;index as index\" (click)=\"seleccionaNodo(nodo,indice)\" (dblclick)=\"navegaNodo(nodo,index,true)\">\n           <ion-label color=\"blanco\">{{nodo.name}}</ion-label>\n         </ion-segment-button>\n\n         <ion-segment-button (click)=\"elegirPersonas()\">\n           <ion-icon name=\"add-circle-outline\"></ion-icon>\n         </ion-segment-button>\n       </ion-segment>\n     </ion-toolbar>\n   </div>\n   <h3 class=\"mensaje\">{{mensaje}}</h3>\n\n   <ion-button  class=\"ion-button\" [disabled]=\"!nodo || revisarActivoVacio()\" *ngIf=\" usuariosAsignados.length == 0\" size=\"medium\" (click)=\"enviarEvaluacion()\">Enviar evaluación</ion-button>\n   <ion-button  class=\"ion-button\" [disabled]=\"revisarActivoVacio() \" *ngIf=\" usuariosAsignados.length > 0\"  size=\"medium\" (click)=\"enviarEvaluacionUsuarios()\">Enviar evaluación a usuarios asignados</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/evaluacion/evaluacion-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/evaluacion/evaluacion-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: EvaluacionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionPageRoutingModule", function() { return EvaluacionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _evaluacion_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./evaluacion.page */ "./src/app/evaluacion/evaluacion.page.ts");




var routes = [
    {
        path: '',
        component: _evaluacion_page__WEBPACK_IMPORTED_MODULE_3__["EvaluacionPage"]
    },
    {
        path: 'escojer',
        loadChildren: function () { return __webpack_require__.e(/*! import() | escojer-escojer-module */ "escojer-escojer-module").then(__webpack_require__.bind(null, /*! ./escojer/escojer.module */ "./src/app/evaluacion/escojer/escojer.module.ts")).then(function (m) { return m.EscojerPageModule; }); }
    }
];
var EvaluacionPageRoutingModule = /** @class */ (function () {
    function EvaluacionPageRoutingModule() {
    }
    EvaluacionPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], EvaluacionPageRoutingModule);
    return EvaluacionPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/evaluacion/evaluacion.module.ts":
/*!*************************************************!*\
  !*** ./src/app/evaluacion/evaluacion.module.ts ***!
  \*************************************************/
/*! exports provided: EvaluacionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionPageModule", function() { return EvaluacionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _evaluacion_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./evaluacion-routing.module */ "./src/app/evaluacion/evaluacion-routing.module.ts");
/* harmony import */ var _evaluacion_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./evaluacion.page */ "./src/app/evaluacion/evaluacion.page.ts");







var EvaluacionPageModule = /** @class */ (function () {
    function EvaluacionPageModule() {
    }
    EvaluacionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _evaluacion_routing_module__WEBPACK_IMPORTED_MODULE_5__["EvaluacionPageRoutingModule"]
            ],
            declarations: [_evaluacion_page__WEBPACK_IMPORTED_MODULE_6__["EvaluacionPage"]],
        })
    ], EvaluacionPageModule);
    return EvaluacionPageModule;
}());



/***/ }),

/***/ "./src/app/evaluacion/evaluacion.page.scss":
/*!*************************************************!*\
  !*** ./src/app/evaluacion/evaluacion.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --color:white;\n  --background: #b5f7cf;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #b5f7cf;\n  margin-bottom: 5%;\n}\n\n.imagen-evaluacion {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.mensaje {\n  text-align: center;\n  margin-top: 5%;\n  margin-bottom: 10;\n  color: #29b6f6;\n  font-style: bold;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n\nion-fab-button {\n  --background: #b5f7cf;\n  --background-activated: #b5f7cf;\n  --background-hover: #b5f7cf;\n  --color: white;\n}\n\n.ion-button {\n  --background: #b5f7cf;\n  --background-activated: #b5f7cf;\n  --background-hover: #b5f7cf;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n.ion-button-indicador {\n  --background: #80deea;\n  --background-activated: #80deea;\n  --background-hover: #80deea;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n@media (min-width: 900px) {\n  ion-header {\n    display: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZXZhbHVhY2lvbi9ldmFsdWFjaW9uLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZXZhbHVhY2lvbi9ldmFsdWFjaW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFOzs7R0FBQTtFQUlBLGFBQUE7RUFDQSxxQkFBQTtFQUVBLHFCQUFBO0VBQ0Esa0JBQUE7QUNBRjs7QURHQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNBRDs7QURHQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNBRjs7QURFQTtFQUFTOzs7R0FBQTtFQUlQLDRCQUFBO0VBQ0EsMEJBQUE7QUNFRjs7QURDQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQ01GOztBRENBO0VBQ0UsbUJBQUE7QUNFRjs7QURDQTtFQUNFLGlDQUFBO0FDRUY7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxjQUFBO0FDRUY7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDRUY7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDRUY7O0FEQ0E7RUFFRTtJQUNFLGFBQUE7RUNDRjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvZXZhbHVhY2lvbi9ldmFsdWFjaW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLy8tLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICBiYWNrZ3JvdW5kOiAjYjVmN2NmO1xuXHRtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1ldmFsdWFjaW9ue1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5tZW5zYWple1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7O1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogMTA7XG4gIGNvbG9yOiAjMjliNmY2O1xuICBmb250LXN0eWxlOiBib2xkO1xufVxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbmlvbi1mYWJ7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1idXR0b24taW5kaWNhZG9ye1xuICAtLWJhY2tncm91bmQ6ICM4MGRlZWE7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICM4MGRlZWE7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzgwZGVlYTtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5MDBweCkge1xuXG4gIGlvbi1oZWFkZXJ7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxufVxuIiwiLnRvb2xiYXIge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2VuIHtcbiAgYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5pbWFnZW4tZXZhbHVhY2lvbiB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLm1lbnNhamUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDUlO1xuICBtYXJnaW4tYm90dG9tOiAxMDtcbiAgY29sb3I6ICMyOWI2ZjY7XG4gIGZvbnQtc3R5bGU6IGJvbGQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgLypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG5pb24tZmFiIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDEyOCwyMjIsMjM0LDEpO1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI2I1ZjdjZjtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjYjVmN2NmO1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICNiNWY3Y2Y7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICNiNWY3Y2Y7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogI2I1ZjdjZjtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG5cbi5pb24tYnV0dG9uLWluZGljYWRvciB7XG4gIC0tYmFja2dyb3VuZDogIzgwZGVlYTtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzgwZGVlYTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjODBkZWVhO1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDkwMHB4KSB7XG4gIGlvbi1oZWFkZXIge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/evaluacion/evaluacion.page.ts":
/*!***********************************************!*\
  !*** ./src/app/evaluacion/evaluacion.page.ts ***!
  \***********************************************/
/*! exports provided: EvaluacionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluacionPage", function() { return EvaluacionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pregunta/pregunta.page */ "./src/app/evaluacion/pregunta/pregunta.page.ts");
/* harmony import */ var _importar_importar_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./importar/importar.page */ "./src/app/evaluacion/importar/importar.page.ts");
/* harmony import */ var _escojer_escojer_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./escojer/escojer.page */ "./src/app/evaluacion/escojer/escojer.page.ts");
/* harmony import */ var _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../_servicios/evaluaciones.service */ "./src/app/_servicios/evaluaciones.service.ts");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");








var EvaluacionPage = /** @class */ (function () {
    function EvaluacionPage(toastController, userService, evaluacionesService, alertController, modalCtrl) {
        var _this = this;
        this.toastController = toastController;
        this.userService = userService;
        this.evaluacionesService = evaluacionesService;
        this.alertController = alertController;
        this.modalCtrl = modalCtrl;
        this.tiposDeEvaluacion = ["Cuestionario", "Evaluación"];
        this.evaluacion = { sigla: '', nombre: "", tipo: "", indicadores: [], id: '', fecha: new Date() };
        this.verAgregar = false;
        this.activos = [];
        this.usuarios = [];
        this.mensaje = "";
        this.sucursal = "";
        this.indice = 0;
        this.puntos = 0;
        this.pasos = [];
        this.evaluaciones = [];
        this.inputs = [];
        this.porcentaje = 0;
        this.jerarquia = [];
        this.arbol = [];
        this.count = 0;
        this.usuariosAsignados = [];
        console.log(sessionStorage);
        this.jerarquia = JSON.parse(sessionStorage.getItem('jerarquia'));
        var arbol = JSON.parse(sessionStorage.getItem('jerarquia')).toString();
        this.arbol = JSON.parse(arbol);
        userService.listar().subscribe(function (usuarios) {
            console.log(usuarios);
            _this.usuarios = usuarios;
        });
    }
    EvaluacionPage.prototype.ngOnInit = function () {
        var _this = this;
        this.evaluacionesService.listar().subscribe(function (evaluaciones) {
            _this.evaluaciones = evaluaciones;
        });
    };
    EvaluacionPage.prototype.recalcular = function () {
        var total = 0;
        for (var i = 0; i < this.activos.length; i++) {
            if (this.activos[i]) {
                var cantidad = parseInt((this.inputs[i] || 0));
                total += cantidad;
            }
        }
        this.porcentaje = total;
    };
    EvaluacionPage.prototype.cantidadInputs = function (cantidad) {
        var dif = cantidad.length - this.inputs.length;
        for (var i = 0; i < dif; i++) {
            this.inputs.push("");
            this.activos.push(false);
        }
        return cantidad;
    };
    EvaluacionPage.prototype.guardarEvaluacion = function () {
        //this.evaluacion.id = ""+(this.evaluaciones.length + 1);
        console.table(this.evaluacion);
        this.evaluacionesService.insertar(this.evaluacion).subscribe(function (data) {
            console.log(data);
        });
        this.evaluaciones.push(this.evaluacion);
        this.evaluacion = { sigla: '', nombre: "", indicadores: [], tipo: "", id: "", fecha: new Date() };
    };
    EvaluacionPage.prototype.actualizarEvaluacion = function () {
        this.evaluacionesService.actualizar(this.evaluacion.id, this.evaluacion).subscribe(function (data) {
            console.log(data);
        });
        this.redefinirEvaluacion();
    };
    EvaluacionPage.prototype.abrirPreguntas = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(this.evaluacion);
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_3__["PreguntaPage"],
                                cssClass: 'modals',
                                componentProps: {
                                    'evaluacion': this.evaluacion,
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log("indicadores conseguidas", modal.data);
                                var indicadores = [];
                                for (var key in modal.data) {
                                    var datos = modal.data[key];
                                    for (var i = 0; i < datos.length; i++) {
                                        datos[i].categoria = key;
                                        indicadores.push(datos[i]);
                                    }
                                }
                                _this.evaluacion.indicadores = indicadores;
                            }
                            console.log("indicadores conseguidas", modal.data);
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EvaluacionPage.prototype.confirmar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(this.evaluacion);
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Favor confirmar!',
                                message: 'Estas a punto de <br><strong>CREAR UNA EVALUACIÓN</strong>!!!',
                                buttons: [
                                    {
                                        text: 'Cancelar',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                        handler: function (blah) {
                                            console.log('Cancelado');
                                        }
                                    }, {
                                        text: 'Okay',
                                        handler: function () {
                                            _this.guardarEvaluacion();
                                            _this.verAgregar = false;
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EvaluacionPage.prototype.alertBorrar = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(this.evaluacion);
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Favor confirmar!',
                                message: 'Estas a punto de <br><strong>BORRAR UNA EVALUACIÓN</strong>!!!',
                                buttons: [
                                    {
                                        text: 'Cancelar',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                        handler: function (blah) {
                                            console.log('Cancelado');
                                        }
                                    }, {
                                        text: 'Confirmar',
                                        handler: function () {
                                            _this.borrarEvaluacion(ev);
                                            _this.verAgregar = false;
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EvaluacionPage.prototype.eliminar = function (ev, slide) {
        this.alertBorrar(ev);
        slide.close();
    };
    EvaluacionPage.prototype.borrarEvaluacion = function (ev) {
        var _this = this;
        this.evaluacionesService.borrar(ev.id).subscribe(function (dato) {
            console.log(dato);
            _this.ngOnInit();
        });
    };
    EvaluacionPage.prototype.visualizar = function (evaluacion, slide) {
        console.log(evaluacion);
        this.evaluacion = evaluacion;
        slide.close();
    };
    EvaluacionPage.prototype.traerDatos = function (evento) {
        var _this = this;
        var userId = sessionStorage.getItem('userId');
        this.evaluacionesService.listar().subscribe(function (evaluaciones) {
            _this.evaluaciones = evaluaciones;
            if (evento) {
                evento.target.complete();
            }
        });
    };
    EvaluacionPage.prototype.elegirPersonas = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _escojer_escojer_page__WEBPACK_IMPORTED_MODULE_5__["EscojerPage"],
                            cssClass: 'modals',
                            componentProps: {
                                'usuarios': this.usuarios,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log(modal.data);
                                _this.usuariosAsignados = modal.data;
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EvaluacionPage.prototype.abrirImportar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal, self;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _importar_importar_page__WEBPACK_IMPORTED_MODULE_4__["ImportarPageEvaluacion"],
                            cssClass: 'modals',
                            componentProps: {
                                'evaluacion': this.evaluacion,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        self = this;
                        modal.onDidDismiss().then(function (modal) {
                            console.log(modal.data);
                            var timestamp = new Date();
                            var evaluacion = undefined;
                            if (modal.data) {
                                evaluacion = { sigla: modal.data.sigla, nombre: modal.data.nombre, categorias: modal.data.categorias, tipo: "", id: "", fecha: timestamp };
                                console.log(evaluacion);
                                var indicadores = [];
                                for (var key in modal.data.categorias) {
                                    var datos = modal.data.categorias[key];
                                    for (var i = 0; i < datos.length; i++) {
                                        datos[i].categoria = key;
                                        indicadores.push(datos[i]);
                                    }
                                }
                                var ev = { sigla: modal.data.sigla, nombre: modal.data.nombre, indicadores: indicadores, fecha: timestamp };
                                _this.evaluacionesService.insertar(ev).subscribe(function (data) {
                                    console.log(data);
                                    self.ngOnInit();
                                });
                            }
                            /*
                            let evaluacion = modal.data.evaluacion;
                            this.evaluacionesService.insertar(evaluacion).subscribe(data=>{
                              console.log(data);
                            })
                            */
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EvaluacionPage.prototype.redefinirEvaluacion = function () {
        this.evaluacion = { sigla: '', nombre: "", indicadores: [], tipo: "", id: "", fecha: new Date() };
    };
    EvaluacionPage.prototype.volver = function () {
        console.log(this.pasos);
        this.pasos.pop();
        console.log(this.pasos);
        var arbol = JSON.parse(sessionStorage.getItem('jerarquia')).toString();
        this.arbol = JSON.parse(arbol);
        for (var i = 0; i < this.pasos.length; i++) {
            this.navegaNodo(this.arbol[this.pasos[i]], this.pasos[i], false);
        }
        this.nodo = undefined;
        this.mensaje = "Seleciona ";
    };
    EvaluacionPage.prototype.seleccionaNodo = function (nodo, indice) {
        var _this = this;
        console.log("selecciona nodo");
        this.count++;
        setTimeout(function () {
            if (_this.count == 1) {
                _this.count = 0;
                console.log("hice click en selecciona", nodo);
                _this.mensaje = "Seleccionado " + nodo.name;
                _this.nodo = nodo;
                _this.sucursal = nodo.id;
            }
            if (_this.count > 1) {
                console.log("hice click en navega", nodo);
                _this.count = 0;
                _this.navegaNodo(nodo, indice, true);
            }
        }, 250);
    };
    EvaluacionPage.prototype.navegaNodo = function (nodo, indice, aumentaConteo) {
        console.log(this.arbol);
        console.log(indice);
        if (this.arbol[indice].childrens.length > 0) {
            console.log("navegado");
            this.indice++;
            this.arbol = this.arbol[indice].childrens;
            if (aumentaConteo) {
                this.pasos.push(indice);
            }
            console.log("indice", this.pasos);
        }
        else {
            this.seleccionaNodo(nodo, indice);
        }
    };
    EvaluacionPage.prototype.revisarActivoVacio = function () {
        for (var i = 0; i < this.activos.length; i++) {
            if (this.activos[i]) {
                var cantidad = parseInt((this.inputs[i] || 0));
                if (cantidad == 0) {
                    return true;
                }
            }
        }
        return false;
    };
    EvaluacionPage.prototype.asignarEvaluacion = function (evaluaciones) {
        var _this = this;
        console.log(evaluaciones);
        for (var indice = 0; indice < evaluaciones.length; indice++) {
            for (var i = 0; i < this.usuarios.length; i++) {
                var usuario = this.usuarios[i];
                var asignado = undefined;
                if (usuario.asignado && usuario.asignado.length > 0) {
                    asignado = usuario.asignado[0];
                    if (this.encontrarEnNodo(asignado, this.nodo)) {
                        console.log("este usuario existe en el nodo o subsecuentes", usuario);
                        usuario.password = undefined;
                        usuario.evaluaciones.push(evaluaciones[indice]);
                    }
                }
            }
        }
        var usuariosCambiados = [];
        var _loop_1 = function (i) {
            var usuario = this_1.usuarios[i];
            asignado = undefined;
            if (usuario.asignado && usuario.asignado.length > 0) {
                asignado = usuario.asignado[0];
                if (this_1.encontrarEnNodo(asignado, this_1.nodo)) {
                    usuariosCambiados.push(usuario);
                    this_1.userService.actualizar(usuario.id, usuario).subscribe(function (data) {
                        console.log(usuario);
                        _this.mostrarToast();
                    });
                }
            }
        };
        var this_1 = this, asignado;
        for (var i = 0; i < this.usuarios.length; i++) {
            _loop_1(i);
        }
        console.log(usuariosCambiados);
    };
    EvaluacionPage.prototype.encontrarEnNodo = function (asignado, nodo) {
        var quedanHijos = true;
        if (!nodo.childrens) {
            quedanHijos = false;
        }
        if (JSON.stringify(asignado) == JSON.stringify(nodo)) {
            return true;
        }
        else {
            console.log(nodo);
            if (!quedanHijos) {
                return false;
            }
            else {
                for (var i = 0; i < nodo.childrens.length; i++) {
                    var nuevoNodo = nodo.childrens[i];
                    if (JSON.stringify(asignado) == JSON.stringify(nuevoNodo)) {
                        return true;
                    }
                }
            }
            return false;
        }
    };
    EvaluacionPage.prototype.mostrarToast = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: 'Los instrumentos han sido asignados',
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    EvaluacionPage.prototype.enviarEvaluacionUsuarios = function () {
        var _this = this;
        var evaluaciones = [];
        var timestamp = new Date().getTime();
        for (var activo = 0; activo < this.activos.length; activo++) {
            if (this.activos[activo]) {
                var puntos = (this.puntos * this.inputs[activo]) / 100;
                var ifortEv = { instrumento: this.evaluaciones[activo], porcentaje: this.inputs[activo], puntos: puntos, estado: 0, fecha: timestamp };
                evaluaciones.push(ifortEv);
            }
        }
        var self = this;
        for (var indice = 0; indice < evaluaciones.length; indice++) {
            for (var _i = 0, _a = this.usuariosAsignados; _i < _a.length; _i++) {
                var usuario = _a[_i];
                usuario.evaluaciones.push(evaluaciones[indice]);
            }
        }
        for (var _b = 0, _c = this.usuariosAsignados; _b < _c.length; _b++) {
            usuario = _c[_b];
            usuario.password = undefined;
            self.userService.actualizar(usuario.id, usuario).subscribe(function (data) {
                console.log(usuario);
                _this.mostrarToast();
            });
        }
    };
    EvaluacionPage.prototype.enviarEvaluacion = function () {
        var evaluaciones = [];
        var timestamp = new Date().getTime();
        for (var activo = 0; activo < this.activos.length; activo++) {
            if (this.activos[activo]) {
                var puntos = (this.puntos * this.inputs[activo]) / 100;
                var ifortEv = { instrumento: this.evaluaciones[activo], porcentaje: this.inputs[activo], puntos: puntos, estado: 0, fecha: timestamp };
                evaluaciones.push(ifortEv);
            }
        }
        this.asignarEvaluacion(evaluaciones);
    };
    EvaluacionPage.prototype.getIndicadores = function (obj) {
        if (obj.length > 0) {
            return obj.length;
        }
        var cantidad = 0;
        for (var key in obj) {
            var categoria = obj[key];
            for (var i = 0; i < categoria.length; i++) {
                cantidad += 1;
            }
        }
        return cantidad;
    };
    EvaluacionPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"] },
        { type: _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_6__["EvaluacionesService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    EvaluacionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-evaluacion',
            template: __webpack_require__(/*! raw-loader!./evaluacion.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluacion/evaluacion.page.html"),
            styles: [__webpack_require__(/*! ./evaluacion.page.scss */ "./src/app/evaluacion/evaluacion.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"],
            _servicios_evaluaciones_service__WEBPACK_IMPORTED_MODULE_6__["EvaluacionesService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], EvaluacionPage);
    return EvaluacionPage;
}());



/***/ })

}]);
//# sourceMappingURL=evaluacion-evaluacion-module-es5.js.map