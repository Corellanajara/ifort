(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["encuestas-encuestas-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/encuestas/encuestas.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/encuestas/encuestas.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Encuestas</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"traerDatos($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"contenedor-imagen\">\n    <img class=\"imagen-evaluacion\" src=\"https://image.flaticon.com/icons/png/512/1260/1260185.png\">\n  </div>\n\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"!verAgregar\">\n    <ion-fab-button>\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n\n         <ion-fab-button (click)=\"abrirAyuda()\" *ngIf=\"!verAgregar\">\n           <ion-icon name=\"help\" ></ion-icon>\n         </ion-fab-button>\n\n         <ion-fab-button (click)=\"abrirImportar();verAgregar = false;\" >\n           <ion-icon name=\"document\" ></ion-icon>\n         </ion-fab-button>\n\n         <ion-fab-button (click)=\"redefinirEncuesta();verAgregar = true;\" *ngIf=\"!verAgregar\">\n           <ion-icon name=\"add\" ></ion-icon>\n         </ion-fab-button>\n\n    </ion-fab-list>\n\n  </ion-fab>\n  <ion-fab vertical=\"top\" horizontal=\"end\" *ngIf=\"verAgregar\">\n    <ion-fab-button (click)=\"redefinirEncuesta();verAgregar = false;\" >\n      <ion-icon name=\"remove\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <br>\n  <div *ngIf=\"verAgregar\">\n    <ion-item style=\"padding-top: 20px\">\n      <ion-label position=\"floating\" style=\"font-size: 20px;color:black\">Titulo</ion-label>\n      <ion-input [(ngModel)]=\"encuesta.titulo\" ></ion-input>\n    </ion-item>\n    <br>\n    <br>\n    <ion-item-divider mode=\"md\">\n\n    </ion-item-divider>\n    <ion-button class=\"ion-button-indicador\" (click)=\"abrirPreguntas()\" size=\"medium\" [disabled]=\" encuesta.titulo == '' \">Ver/Agregar afirmaciones <span *ngIf=\"encuesta.preguntas\"> ({{getPreguntas(encuesta.preguntas)}})</span></ion-button>\n    <ion-button class=\"ion-button\" *ngIf=\"encuesta.id == '' \" [disabled]=\" encuesta.titulo == '' \"  size=\"medium\" (click)=\"confirmar()\">Guardar</ion-button>\n    <ion-button class=\"ion-button\" *ngIf=\"encuesta.id != ''\" [disabled]=\" encuesta.titulo == '' \"   size=\"medium\" (click)=\"actualizarEncuesta();verAgregar = false\">Actualizar</ion-button>\n\n  </div>\n  <p style=\"text-align:center\" *ngIf=\"encuesta.id != '' && !verAgregar\">\n    Encuesta \" {{encuesta.titulo}} \"\n  </p>\n   <br>\n\n   <ion-item-divider mode=\"md\" style=\"text-align:center;font-size: 20px;\">\n     <b>Lista de encuestas</b>\n   </ion-item-divider>\n\n   <ion-list>\n\n     <ion-item-sliding  *ngFor=\"let encuesta of encuestas;index as i\" #slidingItem  >\n      <ion-item-options side=\"start\">\n        <ion-item-option color=\"danger\" expandable (click)=\"eliminar(ev)\">\n          <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n\n      <ion-item>\n        <ion-label (click)=\"visualizar(ev,slidingItem);verAgregar = true\">{{encuesta.titulo}}</ion-label>\n      </ion-item>\n\n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"secondary\"expandable (click)=\"visualizar(encuesta,slidingItem);verAgregar = true;\">\n          <ion-icon  slot=\"icon-only\" name=\"eye\"></ion-icon>\n        </ion-item-option>\n        <ion-item-option color=\"secondary\"expandable (click)=\"visualizar(encuesta,slidingItem);verAgregar = false;\">\n          <ion-icon name=\"checkmark\" style=\"font-size:20px\"></ion-icon>\n        </ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n\n\n   </ion-list>\n\n    <div class=\"seleccionable-evaluacion\" *ngIf=\"encuesta.id != ''\" >\n      <ion-toolbar >\n        <ion-segment scrollable  color=\"secondary\">\n          <ion-segment-button *ngIf=\"this.pasos.length > 0\">\n            <ion-icon name=\"arrow-back\" style=\"font-size:25px;\"  (click)=\"volver()\"></ion-icon>\n          </ion-segment-button>\n\n          <ion-segment-button value=\"{{nodo.name}}\" *ngFor=\"let nodo of arbol;index as index\" (click)=\"seleccionaNodo(nodo,indice)\" (dblclick)=\"navegaNodo(nodo,index,true)\">\n            <ion-label color=\"blanco\">{{nodo.name}}</ion-label>\n          </ion-segment-button>\n          <ion-segment-button (click)=\"elegirPersonas()\">\n            <ion-icon name=\"add-circle-outline\"></ion-icon>\n          </ion-segment-button>\n        </ion-segment>\n      </ion-toolbar>\n      <h3 class=\"mensaje\">{{mensaje}}</h3>\n   </div>\n\n\n   <ion-button  class=\"ion-button\" [disabled]=\"!nodo\" *ngIf=\" usuariosAsignados.length == 0\" size=\"medium\" (click)=\"enviarEncuesta()\">Enviar encuesta</ion-button>\n   <ion-button  class=\"ion-button\" *ngIf=\" usuariosAsignados.length > 0\" size=\"medium\" (click)=\"enviarEncuestaAsignados()\">Enviar encuesta a usuarios asignados</ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/encuestas/encuestas-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/encuestas/encuestas-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: EncuestasPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EncuestasPageRoutingModule", function() { return EncuestasPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _encuestas_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./encuestas.page */ "./src/app/encuestas/encuestas.page.ts");




var routes = [
    {
        path: '',
        component: _encuestas_page__WEBPACK_IMPORTED_MODULE_3__["EncuestasPage"]
    },
    {
        path: 'pregunta',
        loadChildren: function () { return __webpack_require__.e(/*! import() | pregunta-pregunta-module */ "pregunta-pregunta-module").then(__webpack_require__.bind(null, /*! ./pregunta/pregunta.module */ "./src/app/encuestas/pregunta/pregunta.module.ts")).then(function (m) { return m.PreguntaPageModule; }); }
    },
    {
        path: 'importar',
        loadChildren: function () { return __webpack_require__.e(/*! import() | importar-importar-module */ "importar-importar-module").then(__webpack_require__.bind(null, /*! ./importar/importar.module */ "./src/app/encuestas/importar/importar.module.ts")).then(function (m) { return m.ImportarPageModule; }); }
    },
    {
        path: 'escojer',
        loadChildren: function () { return __webpack_require__.e(/*! import() | escojer-escojer-module */ "escojer-escojer-module").then(__webpack_require__.bind(null, /*! ./escojer/escojer.module */ "./src/app/encuestas/escojer/escojer.module.ts")).then(function (m) { return m.EscojerPageModule; }); }
    }
];
var EncuestasPageRoutingModule = /** @class */ (function () {
    function EncuestasPageRoutingModule() {
    }
    EncuestasPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], EncuestasPageRoutingModule);
    return EncuestasPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/encuestas/encuestas.module.ts":
/*!***********************************************!*\
  !*** ./src/app/encuestas/encuestas.module.ts ***!
  \***********************************************/
/*! exports provided: EncuestasPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EncuestasPageModule", function() { return EncuestasPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _encuestas_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./encuestas-routing.module */ "./src/app/encuestas/encuestas-routing.module.ts");
/* harmony import */ var _encuestas_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./encuestas.page */ "./src/app/encuestas/encuestas.page.ts");







var EncuestasPageModule = /** @class */ (function () {
    function EncuestasPageModule() {
    }
    EncuestasPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _encuestas_routing_module__WEBPACK_IMPORTED_MODULE_5__["EncuestasPageRoutingModule"]
            ],
            declarations: [_encuestas_page__WEBPACK_IMPORTED_MODULE_6__["EncuestasPage"]]
        })
    ], EncuestasPageModule);
    return EncuestasPageModule;
}());



/***/ }),

/***/ "./src/app/encuestas/encuestas.page.scss":
/*!***********************************************!*\
  !*** ./src/app/encuestas/encuestas.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background: #21ada1;\n  --color: white !important;\n  font-family: \"Roboto\";\n  text-align: center;\n}\n\n.contenedor-imagen {\n  background: #21ada1;\n  margin-bottom: 5%;\n}\n\n.imagen-evaluacion {\n  width: 20%;\n  margin-left: 40%;\n  margin-top: 5%;\n  margin-bottom: 5%;\n}\n\n.mensaje {\n  text-align: center;\n  margin-top: 5%;\n  margin-bottom: 10;\n  color: #21ada1;\n  font-style: bold;\n}\n\nion-item {\n  /*\n  --background: rgb(2,0,36);\n  background: linear-gradient(90deg, rgba(255,87,34,1) 0%, rgba(230,81,0,1) 54%);\n  */\n  --background-focused:#f5f5f5;\n  --background-hover:#f5f5f5;\n}\n\nion-content {\n  --background: white;\n  /*\n  --color:white!important;\n  --background: rgb(2,0,36);\n  --background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,68,121,0.5648148148148149) 0%, rgba(35,0,255,0.6643518518518519) 100%);\n  */\n}\n\nion-card {\n  --background: white;\n}\n\nion-fab {\n  --background: rgba(128,222,234,1);\n}\n\nion-fab-button {\n  --background: #03a9f4;\n  --background-activated: #03a9f4;\n  --background-hover: #03a9f4;\n  --color: white;\n}\n\n.ion-button {\n  --background: #03a9f4;\n  --background-activated: #03a9f4;\n  --background-hover: #03a9f4;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n\n.ion-button-indicador {\n  --background: #80deea;\n  --background-activated: #80deea;\n  --background-hover: #80deea;\n  width: 70% !important;\n  margin-left: 15% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jcmlzdG9waGVyb3JlbGxhbmEvRGVza3RvcC9jb3JlbGxhbmEvZXN0aWxvc29zL3NyYy9hcHAvZW5jdWVzdGFzL2VuY3Vlc3Rhcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2VuY3Vlc3Rhcy9lbmN1ZXN0YXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7OztHQUFBO0VBS0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNBRjs7QURHQTtFQUNFLG1CQUFBO0VBQ0QsaUJBQUE7QUNBRDs7QURHQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0FGOztBREdBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNBRjs7QURFQTtFQUFTOzs7R0FBQTtFQUlQLDRCQUFBO0VBQ0EsMEJBQUE7QUNFRjs7QURDQTtFQUNFLG1CQUFBO0VBQ0E7Ozs7R0FBQTtBQ01GOztBRENBO0VBQ0UsbUJBQUE7QUNFRjs7QURDQTtFQUNFLGlDQUFBO0FDRUY7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxjQUFBO0FDRUY7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDRUY7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9lbmN1ZXN0YXMvZW5jdWVzdGFzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFye1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG5cbiAgLS1iYWNrZ3JvdW5kOiAjMjFhZGExO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogJ1JvYm90byc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbmVkb3ItaW1hZ2Vue1xuICBiYWNrZ3JvdW5kOiAjMjFhZGExO1xuXHRtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1ldmFsdWFjaW9ue1xuICB3aWR0aDogMjAlO1xuICBtYXJnaW4tbGVmdDogNDAlO1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbi5tZW5zYWple1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7O1xuICBtYXJnaW4tdG9wOiA1JTtcbiAgbWFyZ2luLWJvdHRvbTogMTA7XG4gIGNvbG9yOiAjMjFhZGExO1xuICBmb250LXN0eWxlOiBib2xkO1xufVxuaW9uLWl0ZW17LypcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCByZ2JhKDI1NSw4NywzNCwxKSAwJSwgcmdiYSgyMzAsODEsMCwxKSA1NCUpO1xuICAqL1xuICAtLWJhY2tncm91bmQtZm9jdXNlZDojZjVmNWY1O1xuICAtLWJhY2tncm91bmQtaG92ZXI6I2Y1ZjVmNTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAvKlxuICAtLWNvbG9yOndoaXRlIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMiwwLDM2KTtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMiwwLDM2LDEpIDAlLCByZ2JhKDksNjgsMTIxLDAuNTY0ODE0ODE0ODE0ODE0OSkgMCUsIHJnYmEoMzUsMCwyNTUsMC42NjQzNTE4NTE4NTE4NTE5KSAxMDAlKTtcbiAgKi9cbn1cblxuaW9uLWNhcmR7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbmlvbi1mYWJ7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxMjgsMjIyLDIzNCwxKTtcbn1cblxuaW9uLWZhYi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogIzAzYTlmNDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzAzYTlmNDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDNhOWY0O1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogIzAzYTlmNDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzAzYTlmNDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDNhOWY0O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1idXR0b24taW5kaWNhZG9ye1xuICAtLWJhY2tncm91bmQ6ICM4MGRlZWE7XG4gIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICM4MGRlZWE7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjogIzgwZGVlYTtcbiAgd2lkdGg6IDcwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTUlICFpbXBvcnRhbnQ7XG59XG4iLCIudG9vbGJhciB7XG4gIC8qXG4gIC0tYmFja2dyb3VuZDogcmdiKDIsMCwzNik7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyNTUsODcsMzQsMSkgMCUsIHJnYmEoMjMwLDgxLDAsMSkgNTQlKTtcbiAgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjMjFhZGExO1xuICAtLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LWZhbWlseTogXCJSb2JvdG9cIjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVuZWRvci1pbWFnZW4ge1xuICBiYWNrZ3JvdW5kOiAjMjFhZGExO1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cblxuLmltYWdlbi1ldmFsdWFjaW9uIHtcbiAgd2lkdGg6IDIwJTtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDUlO1xufVxuXG4ubWVuc2FqZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogNSU7XG4gIG1hcmdpbi1ib3R0b206IDEwO1xuICBjb2xvcjogIzIxYWRhMTtcbiAgZm9udC1zdHlsZTogYm9sZDtcbn1cblxuaW9uLWl0ZW0ge1xuICAvKlxuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjU1LDg3LDM0LDEpIDAlLCByZ2JhKDIzMCw4MSwwLDEpIDU0JSk7XG4gICovXG4gIC0tYmFja2dyb3VuZC1mb2N1c2VkOiNmNWY1ZjU7XG4gIC0tYmFja2dyb3VuZC1ob3ZlcjojZjVmNWY1O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC8qXG4gIC0tY29sb3I6d2hpdGUhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHJnYigyLDAsMzYpO1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgyLDAsMzYsMSkgMCUsIHJnYmEoOSw2OCwxMjEsMC41NjQ4MTQ4MTQ4MTQ4MTQ5KSAwJSwgcmdiYSgzNSwwLDI1NSwwLjY2NDM1MTg1MTg1MTg1MTkpIDEwMCUpO1xuICAqL1xufVxuXG5pb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbmlvbi1mYWIge1xuICAtLWJhY2tncm91bmQ6IHJnYmEoMTI4LDIyMiwyMzQsMSk7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDNhOWY0O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMDNhOWY0O1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICMwM2E5ZjQ7XG4gIC0tY29sb3I6IHdoaXRlO1xufVxuXG4uaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzAzYTlmNDtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzAzYTlmNDtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDNhOWY0O1xuICB3aWR0aDogNzAlICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNSUgIWltcG9ydGFudDtcbn1cblxuLmlvbi1idXR0b24taW5kaWNhZG9yIHtcbiAgLS1iYWNrZ3JvdW5kOiAjODBkZWVhO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjODBkZWVhO1xuICAtLWJhY2tncm91bmQtaG92ZXI6ICM4MGRlZWE7XG4gIHdpZHRoOiA3MCUgIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IDE1JSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/encuestas/encuestas.page.ts":
/*!*********************************************!*\
  !*** ./src/app/encuestas/encuestas.page.ts ***!
  \*********************************************/
/*! exports provided: EncuestasPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EncuestasPage", function() { return EncuestasPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pregunta/pregunta.page */ "./src/app/encuestas/pregunta/pregunta.page.ts");
/* harmony import */ var _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../_servicios/encuestas.service */ "./src/app/_servicios/encuestas.service.ts");
/* harmony import */ var _servicios_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../_servicios/user.service */ "./src/app/_servicios/user.service.ts");
/* harmony import */ var _escojer_escojer_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./escojer/escojer.page */ "./src/app/encuestas/escojer/escojer.page.ts");







var EncuestasPage = /** @class */ (function () {
    function EncuestasPage(toastController, alertController, eService, userService, modalCtrl) {
        this.toastController = toastController;
        this.alertController = alertController;
        this.eService = eService;
        this.userService = userService;
        this.modalCtrl = modalCtrl;
        this.encuesta = { titulo: '', preguntas: [], id: '', fecha: new Date() };
        this.verAgregar = false;
        this.activos = [];
        this.usuarios = [];
        this.mensaje = "";
        this.sucursal = "";
        this.indice = 0;
        this.puntos = 0;
        this.pasos = [];
        this.encuestas = [];
        this.inputs = [];
        this.porcentaje = 0;
        this.jerarquia = [];
        this.arbol = [];
        this.count = 0;
        this.usuariosAsignados = [];
    }
    EncuestasPage.prototype.ngOnInit = function () {
        var _this = this;
        this.traerDatos(false);
        this.jerarquia = JSON.parse(sessionStorage.getItem('jerarquia'));
        var arbol = JSON.parse(sessionStorage.getItem('jerarquia')).toString();
        this.arbol = JSON.parse(arbol);
        console.log(this.arbol);
        this.userService.listar().subscribe(function (usuarios) {
            console.log(usuarios);
            _this.usuarios = usuarios;
        });
    };
    EncuestasPage.prototype.elegirPersonas = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _escojer_escojer_page__WEBPACK_IMPORTED_MODULE_6__["EscojerEncuestasPage"],
                            cssClass: 'modals',
                            componentProps: {
                                'usuarios': this.usuarios,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log(modal.data);
                                _this.usuariosAsignados = modal.data;
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EncuestasPage.prototype.abrirAyuda = function () {
        alert("Para listar encuestas selecciona ");
    };
    EncuestasPage.prototype.visualizar = function (encuesta, slide) {
        console.log(encuesta);
        this.encuesta = encuesta;
        slide.close();
    };
    EncuestasPage.prototype.redefinirEncuesta = function () {
        this.encuesta = { titulo: '', preguntas: [], id: "", fecha: new Date() };
    };
    EncuestasPage.prototype.abrirPreguntas = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _pregunta_pregunta_page__WEBPACK_IMPORTED_MODULE_3__["PreguntaEncuestaPage"],
                            cssClass: 'modals',
                            componentProps: {
                                'encuesta': this.encuesta,
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (modal) {
                            if (modal.data) {
                                console.log("preguntas conseguidas", modal.data);
                                var encuesta = modal.data;
                                _this.encuesta = encuesta;
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    EncuestasPage.prototype.getPreguntas = function (obj) {
        if (!obj) {
            return 0;
        }
        if (obj.length > 0) {
            return obj.length;
        }
    };
    EncuestasPage.prototype.traerDatos = function (evento) {
        var _this = this;
        this.eService.listar().subscribe(function (datos) {
            _this.encuestas = datos;
            console.log(_this.encuestas);
            if (evento) {
                evento.target.complete();
            }
        });
    };
    EncuestasPage.prototype.confirmar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Favor confirmar!',
                            message: 'Estas a punto de <br><strong>CREAR UNA ENCUESTA</strong>!!!',
                            buttons: [
                                {
                                    text: 'Cancelar',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function (blah) {
                                        console.log('Cancelado');
                                    }
                                }, {
                                    text: 'Okay',
                                    handler: function () {
                                        _this.guardarEncuesta();
                                        _this.verAgregar = false;
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EncuestasPage.prototype.guardarEncuesta = function () {
        //this.evaluacion.id = ""+(this.evaluaciones.length + 1);
        this.eService.insertar(this.encuesta).subscribe(function (data) {
            console.log(data);
        });
        this.encuesta = { titulo: '', preguntas: [], id: "", fecha: new Date() };
        this.traerDatos(false);
    };
    EncuestasPage.prototype.actualizarEncuesta = function () {
        this.eService.actualizar(this.encuesta.id, this.encuesta).subscribe(function (data) {
            console.log(data);
        });
        this.redefinirEncuesta();
    };
    EncuestasPage.prototype.volver = function () {
        console.log(this.pasos);
        this.pasos.pop();
        console.log(this.pasos);
        var arbol = JSON.parse(sessionStorage.getItem('jerarquia')).toString();
        this.arbol = JSON.parse(arbol);
        for (var i = 0; i < this.pasos.length; i++) {
            this.navegaNodo(this.arbol[this.pasos[i]], this.pasos[i], false);
        }
        this.nodo = undefined;
        this.mensaje = "Seleciona ";
    };
    EncuestasPage.prototype.seleccionaNodo = function (nodo, indice) {
        var _this = this;
        console.log("selecciona nodo");
        this.count++;
        setTimeout(function () {
            if (_this.count == 1) {
                _this.count = 0;
                console.log("hice click en selecciona", nodo);
                _this.mensaje = "Seleccionado " + nodo.name;
                _this.nodo = nodo;
                _this.sucursal = nodo.id;
            }
            if (_this.count > 1) {
                console.log("hice click en navega", nodo);
                _this.count = 0;
                _this.navegaNodo(nodo, indice, true);
            }
        }, 250);
    };
    EncuestasPage.prototype.navegaNodo = function (nodo, indice, aumentaConteo) {
        console.log(this.arbol);
        console.log(indice);
        if (this.arbol[indice].childrens.length > 0) {
            console.log("navegado");
            this.indice++;
            this.arbol = this.arbol[indice].childrens;
            if (aumentaConteo) {
                this.pasos.push(indice);
            }
            console.log("indice", this.pasos);
        }
        else {
            this.seleccionaNodo(nodo, indice);
        }
    };
    EncuestasPage.prototype.enviarEncuesta = function () {
        var _this = this;
        for (var i = 0; i < this.usuarios.length; i++) {
            var usuario = this.usuarios[i];
            var asignado = undefined;
            if (usuario.asignado && usuario.asignado.length > 0) {
                asignado = usuario.asignado[0];
                if (this.encontrarEnNodo(asignado, this.nodo)) {
                    console.log("este usuario existe en el nodo o subsecuentes", usuario);
                    usuario.password = undefined;
                    if (!usuario.encuestas) {
                        usuario.encuestas = [];
                    }
                    usuario.encuestas.push(this.encuesta);
                }
            }
        }
        var usuariosCambiados = [];
        var _loop_1 = function (i) {
            var usuario = this_1.usuarios[i];
            asignado = undefined;
            if (usuario.asignado && usuario.asignado.length > 0) {
                asignado = usuario.asignado[0];
                if (this_1.encontrarEnNodo(asignado, this_1.nodo)) {
                    usuariosCambiados.push(usuario);
                    usuario.password = undefined;
                    this_1.userService.actualizar(usuario.id, usuario).subscribe(function (data) {
                        console.log(usuario);
                        _this.mostrarToast();
                        _this.encuesta = { titulo: '', preguntas: [], id: '', fecha: new Date() };
                    });
                }
            }
        };
        var this_1 = this, asignado;
        for (var i = 0; i < this.usuarios.length; i++) {
            _loop_1(i);
        }
        console.log(usuariosCambiados);
    };
    EncuestasPage.prototype.enviarEncuestaAsignados = function () {
        var _this = this;
        for (var _i = 0, _a = this.usuariosAsignados; _i < _a.length; _i++) {
            var usuario = _a[_i];
            if (!usuario.encuestas) {
                usuario.encuestas = [];
            }
            usuario.encuestas.push(this.encuesta);
            usuario.password = undefined;
            this.userService.actualizar(usuario.id, usuario).subscribe(function (data) {
                console.log(usuario);
                _this.mostrarToast();
                _this.encuesta = { titulo: '', preguntas: [], id: '', fecha: new Date() };
            });
        }
    };
    EncuestasPage.prototype.encontrarEnNodo = function (asignado, nodo) {
        var quedanHijos = true;
        if (!nodo.childrens) {
            quedanHijos = false;
        }
        if (JSON.stringify(asignado) == JSON.stringify(nodo)) {
            return true;
        }
        else {
            console.log(nodo);
            if (!quedanHijos) {
                return false;
            }
            else {
                for (var i = 0; i < nodo.childrens.length; i++) {
                    var nuevoNodo = nodo.childrens[i];
                    if (JSON.stringify(asignado) == JSON.stringify(nuevoNodo)) {
                        return true;
                    }
                }
            }
            return false;
        }
    };
    EncuestasPage.prototype.mostrarToast = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: 'Las encuestas han sido asignadas',
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    EncuestasPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_4__["EncuestaService"] },
        { type: _servicios_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    EncuestasPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-encuestas',
            template: __webpack_require__(/*! raw-loader!./encuestas.page.html */ "./node_modules/raw-loader/index.js!./src/app/encuestas/encuestas.page.html"),
            styles: [__webpack_require__(/*! ./encuestas.page.scss */ "./src/app/encuestas/encuestas.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _servicios_encuestas_service__WEBPACK_IMPORTED_MODULE_4__["EncuestaService"],
            _servicios_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], EncuestasPage);
    return EncuestasPage;
}());



/***/ })

}]);
//# sourceMappingURL=encuestas-encuestas-module-es5.js.map